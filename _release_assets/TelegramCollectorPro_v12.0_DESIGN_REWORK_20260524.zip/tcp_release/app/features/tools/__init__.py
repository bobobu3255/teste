"""Ferramentas integradas do aplicativo."""
