"""Paramount Assist feature."""

