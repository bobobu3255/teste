#!/usr/bin/env python3
"""Painel visual para rodar verificacoes de manutencao da V11."""
from __future__ import annotations

import os
import subprocess
import sys
import time

from PyQt5.QtCore import QThread, pyqtSignal
from PyQt5.QtWidgets import QApplication, QFrame, QHBoxLayout, QLabel, QMessageBox, QPushButton, QTextEdit, QVBoxLayout

from app.core.paths import BASE_DIR


class MaintenanceCheckWorker(QThread):
    finished_check = pyqtSignal(bool, str)

    def __init__(self, mode: str = "quick", parent=None):
        super().__init__(parent)
        self.mode = mode

    def run(self):
        script = BASE_DIR / "scripts" / "maintenance" / "verify_all.py"
        if not script.exists():
            self.finished_check.emit(False, f"verify_all.py nao encontrado em:\n{script}")
            return

        command = [sys.executable, str(script)]
        if self.mode == "quick":
            command.append("--quick")

        env = os.environ.copy()
        env.setdefault("PYTHONDONTWRITEBYTECODE", "1")
        env.setdefault("PYTHONUTF8", "1")
        env.setdefault("PYTHONIOENCODING", "utf-8")
        env.setdefault("QT_QPA_PLATFORM", "offscreen")
        paths = [str(BASE_DIR), str(BASE_DIR / "venv" / "Lib" / "site-packages")]
        old_path = env.get("PYTHONPATH")
        env["PYTHONPATH"] = os.pathsep.join(paths + ([old_path] if old_path else []))

        startupinfo = None
        creationflags = 0
        if os.name == "nt":
            startupinfo = subprocess.STARTUPINFO()
            startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
            creationflags = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        started = time.perf_counter()
        try:
            proc = subprocess.run(
                command,
                cwd=str(BASE_DIR),
                env=env,
                capture_output=True,
                text=True,
                timeout=300,
                startupinfo=startupinfo,
                creationflags=creationflags,
            )
        except subprocess.TimeoutExpired:
            self.finished_check.emit(False, "Verificacao demorou demais e foi interrompida apos 5 minutos.")
            return
        except Exception as exc:
            self.finished_check.emit(False, f"Nao consegui iniciar a verificacao:\n{exc}")
            return

        elapsed = time.perf_counter() - started
        output = (proc.stdout or "").strip()
        error = (proc.stderr or "").strip()
        text = output
        if error:
            text = f"{text}\n\n[stderr]\n{error}" if text else error
        text = text or "Verificacao terminou sem saida."
        text = f"{text}\n\nTempo total visto pela interface: {elapsed:.1f}s"
        self.finished_check.emit(proc.returncode == 0, text)


class MaintenancePanel(QFrame):
    """Card de manutencao para a aba Config."""

    def __init__(self, parent=None):
        super().__init__(parent)
        self.worker = None
        self._build()

    def _build(self):
        self.setStyleSheet(
            "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.14);border-radius:16px;}"
        )
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 14)
        root.setSpacing(9)

        title = QLabel("Verificacao da V11")
        title.setStyleSheet("color:#e2e8f0;font-size:15px;font-weight:900;background:transparent;border:none;")
        root.addWidget(title)
        subtitle = QLabel("Rode os checks principais sem abrir terminal. O teste roda em segundo plano e nao altera dados.")
        subtitle.setWordWrap(True)
        subtitle.setStyleSheet("color:#64748b;font-size:11px;background:transparent;border:none;")
        root.addWidget(subtitle)

        actions = QHBoxLayout()
        self.quick_btn = QPushButton("Verificar rapido")
        self.quick_btn.setMinimumHeight(34)
        self.quick_btn.clicked.connect(lambda: self.run_check("quick"))
        actions.addWidget(self.quick_btn)

        self.full_btn = QPushButton("Verificar completo")
        self.full_btn.setMinimumHeight(34)
        self.full_btn.clicked.connect(lambda: self.run_check("full"))
        actions.addWidget(self.full_btn)

        self.copy_btn = QPushButton("Copiar resultado")
        self.copy_btn.setMinimumHeight(34)
        self.copy_btn.clicked.connect(self.copy_result)
        actions.addWidget(self.copy_btn)
        root.addLayout(actions)

        self.status_label = QLabel("Pronto para verificar.")
        self.status_label.setStyleSheet("color:#94a3b8;font-size:11px;background:transparent;border:none;")
        root.addWidget(self.status_label)

        self.output = QTextEdit()
        self.output.setReadOnly(True)
        self.output.setMinimumHeight(170)
        self.output.setPlaceholderText("O resultado dos checks aparece aqui...")
        self.output.setStyleSheet(
            "QTextEdit{background:#08111f;color:#e2e8f0;border:1px solid rgba(148,163,184,0.10);"
            "border-radius:12px;padding:10px;font-family:'Consolas','Cascadia Code',monospace;font-size:11px;}"
        )
        root.addWidget(self.output)

    def run_check(self, mode: str):
        if self.worker and self.worker.isRunning():
            QMessageBox.information(self, "Verificacao", "Ja existe uma verificacao em andamento.")
            return
        self.set_running(True)
        label = "rapida" if mode == "quick" else "completa"
        self.status_label.setText(f"Rodando verificacao {label}...")
        self.output.setPlainText(f"Iniciando verificacao {label}. Aguarde...")
        self.worker = MaintenanceCheckWorker(mode, self)
        self.worker.finished_check.connect(self.on_finished)
        self.worker.start()

    def on_finished(self, ok: bool, text: str):
        self.set_running(False)
        self.output.setPlainText(text)
        self.status_label.setText("Tudo OK." if ok else "Falha encontrada. Copie o resultado para corrigir.")
        self.status_label.setStyleSheet(
            "color:#10b981;font-size:11px;background:transparent;border:none;" if ok
            else "color:#ef4444;font-size:11px;background:transparent;border:none;"
        )

    def set_running(self, running: bool):
        self.quick_btn.setEnabled(not running)
        self.full_btn.setEnabled(not running)
        self.copy_btn.setEnabled(not running)

    def copy_result(self):
        text = self.output.toPlainText().strip()
        if not text:
            QMessageBox.information(self, "Verificacao", "Ainda nao tem resultado para copiar.")
            return
        QApplication.clipboard().setText(text)
        self.status_label.setText("Resultado copiado.")
        self.status_label.setStyleSheet("color:#38bdf8;font-size:11px;background:transparent;border:none;")
