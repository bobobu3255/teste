# Telegram Collector Pro v12.0 Preview

## Sobre

Aplicativo desktop profissional para coleta e gerenciamento de dados via Telegram, com ferramentas integradas de geração de cartões, endereços, formatação de contas e bots automatizados.

## Novidades da v12.0 Preview

- **Design Cyberpunk Neon** - Interface completamente remodelada com tema escuro premium, acentos em cyan/teal neon e efeitos de vidro fosco
- **Projeto Otimizado** - Remoção de arquivos desnecessários, código duplicado e módulos obsoletos
- **Performance** - Tema centralizado em módulo único, reduzindo redundância de estilos

- **V12 Core** - Estado central em SQLite, fila de tarefas, eventos, entidades e relatorio geral de saude.

## Funcionalidades

| Aba | Descrição |
|-----|-----------|
| Gerador de Pares | Gera pares Nome + CPF com filtros por idade e score |
| Ferramentas | Gerador de cartões, CEP, formatador, organizador, validador CPF/CNPJ |
| Navegador Seguro | Navegador com perfis isolados, fingerprint e proxy |
| Config. Perfis | Gerenciamento de favoritos, extensões e senhas padrão |
| Crunchyroll Bot | Bot automatizado para Crunchyroll (Node.js) |
| Crunchyroll Login | Bot de login automatizado para Crunchyroll |

## Requisitos

- **Python** 3.9+
- **PyQt5** 5.15+
- **Node.js** 18+ (apenas para bots Crunchyroll)

## Instalação

```bash
pip install -r requirements.txt
```

## Execução

```bash
python run.py
```

## Estrutura do Projeto

```
TelegramCollectorPro/
├── run.py                    # Ponto de entrada
├── main_app.py               # Aplicação principal (PyQt5)
├── theme.py                  # Tema visual centralizado
├── database.py               # Gerenciamento de banco de dados
├── collector.py              # Coletor de dados Telegram
├── config_manager.py         # Gerenciamento de configurações
├── settings.py               # Configurações globais
├── browser_manager.py        # Gerenciador de navegador
├── browser_widget.py         # Widget do navegador seguro
├── crunchyroll_widget.py     # Widget do bot Crunchyroll
├── crunchyroll_login_widget.py # Widget do bot login
├── extra_tools.py            # Ferramentas extras (validador, fake, backup)
├── generators/               # Geradores (cartão, endereço, fingerprint)
├── crunchyroll_bot/          # Bot Node.js Crunchyroll
├── crunchyroll_login_bot/    # Bot Node.js Login
├── browser_config/           # Configurações do navegador
├── browser_extensions/       # Extensões do navegador
└── ui/                       # Componentes de UI reutilizáveis
```

## Build (Executável Windows)

```bash
python build_exe.py
```

## Paleta de Cores (v12.0 Preview)

| Elemento | Cor |
|----------|-----|
| Background | `#0a0e1a` / `#111827` |
| Accent Primary | `#06b6d4` (Cyan) |
| Accent Light | `#22d3ee` |
| Text Primary | `#f1f5f9` |
| Text Secondary | `#94a3b8` |
| Success | `#10b981` |
| Danger | `#f43f5e` |
| Warning | `#f59e0b` |
