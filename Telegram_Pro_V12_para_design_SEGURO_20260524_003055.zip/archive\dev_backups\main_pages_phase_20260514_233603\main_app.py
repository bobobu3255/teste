#!/usr/bin/env python3
"""
Aplicação Principal - Coletor de Dados Telegram
Versão 11.0 - Interface Reorganizada + Acesso Rápido às Ferramentas
"""
import sys
import os
import asyncio
import json
import re
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QMessageBox, QDialog, QFormLayout, QLineEdit,
    QSpinBox, QCheckBox, QScrollArea, QTableWidget, QTableWidgetItem,
    QHeaderView, QProgressBar, QTabWidget, QGroupBox, QComboBox,
    QFileDialog, QStatusBar, QFrame, QListWidget, QSizePolicy,
    QListWidgetItem, QTextEdit, QSplitter, QRadioButton, QButtonGroup,
    QSystemTrayIcon, QMenu, QAction, QPlainTextEdit
)
from PyQt5.QtWidgets import QShortcut, QGridLayout
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer, QSettings
from PyQt5.QtGui import QFont, QIcon, QPalette, QColor, QPixmap, QPainter, QBrush, QLinearGradient, QPen, QKeySequence
import ctypes

from app.core.clipboard_service import set_clipboard_text
from app.core.error_service import install_crash_logger as core_install_crash_logger, log_exception
from database import DatabaseManager
from config_manager import ConfigManager
from settings import settings, BASE_DIR
from account_manager import GerenciadorContas
from card_generator import CardGenerator
from address_generator import AddressGenerator
from account_formatter import AccountFormatter
from data_organizer import DataOrganizer
from extra_tools import ValidadorWidget, GeradorFakeWidget, BuscaAvancadaWidget, DashboardWidget
from browser_widget import BrowserWidget
from notepad_widget import NotepadWidget
from performance_widget import PerformanceWidget
from data_pro_widget import DataProWidget
from text_corrector_widget import TextCorrectorWidget
from app_hub import (
    AppDashboardWidget, GeneralSettingsWidget, GlobalSearchDialog,
    load_app_settings,
)
from ai_assistant_widget import AIAssistantWidget

# Importar widget de configurações padrão de perfis
try:
    from profile_defaults_widget import ProfileDefaultsWidget
    PROFILE_DEFAULTS_AVAILABLE = True
except ImportError:
    PROFILE_DEFAULTS_AVAILABLE = False

# Importar widget do Bot Crunchyroll
try:
    from crunchyroll_widget import CrunchyrollWidget
    CRUNCHYROLL_AVAILABLE = True
except ImportError:
    CRUNCHYROLL_AVAILABLE = False


# Importar widget do Bot Crunchyroll LOGIN
try:
    from crunchyroll_login_widget import CrunchyrollLoginWidget
    CRUNCHYROLL_LOGIN_AVAILABLE = True
except ImportError:
    CRUNCHYROLL_LOGIN_AVAILABLE = False


# Importar temas do módulo centralizado
from theme import DARK_STYLE_PRO as DARK_STYLE, LIGHT_STYLE_PRO as LIGHT_STYLE
from app.ui.dialogs import (
    CodeInputDialog, ConfigDialog, DataViewDialog, GroupManagerDialog, PasswordInputDialog,
)
from app.core.worker_threads import (
    AddressGeneratorThread, CardGeneratorThread, CollectorThread,
)
from app.ui.shell_widgets import (
    AppStatusBar, CompactWidget, GLOBAL_QSS, HeaderBar, SidebarNav, TAB_TOP_QSS,
    create_app_icon, _set_clipboard_text_safe,
)
from app.features.tools.dialog import ToolsDialog



def install_crash_logger():
    """Guarda erros fatais em arquivo para diagnosticar fechamentos silenciosos."""
    core_install_crash_logger(BASE_DIR)







# ═══════════════════════════════════════════════════════════════
#  CONSTANTES DE DESIGN GLOBAL
# ═══════════════════════════════════════════════════════════════

# QSS global ultra-clean, substituindo o DARK_STYLE herdado












# ═══════════════════════════════════════════════════════════════
#  SIDEBAR NAVEGAÇÃO (substituindo QTabBar lateral)
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  HEADER BAR (faixa superior com título + controles)
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  STATUS BAR MELHORADA
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  MODO COMPACTO — widget flutuante moderno
# ═══════════════════════════════════════════════════════════════


# ═══════════════════════════════════════════════════════════════
#  SIMPLE APP — janela principal redesenhada
# ═══════════════════════════════════════════════════════════════
class SimpleApp(QMainWindow):
    """Janela principal — design lateral moderno com sidebar de ícones."""

    NORMAL_SIZE = (1280, 860)
    COMPACT_SIZE = (400, 600)

    # Títulos das abas para o header
    TAB_TITLES = {
        "inicio": "🏠  Painel Inicial",
        "gerador": "🎲  Gerador de Pares",
        "ferramentas": "🛠️  Ferramentas",
        "navegador": "🌐  Navegador Seguro",
        "ia": "🤖  IA Local",
        "crunchyroll": "🍦  Crunchyroll",
        "notas": "📝  Bloco de Notas",
        "config": "⚙️  Configurações",
    }

    def __init__(self):
        super().__init__()
        self.config_manager = ConfigManager()
        self.db = self._get_database()
        self.collector_thread = None
        self.current_pair = None
        self._address_gen = AddressGenerator()

        self.is_always_on_top = False
        self.is_fullscreen = False
        self.is_compact_mode = False
        self._force_quit = False
        self.settings = QSettings("TelegramCollector", "Pro")

        self.mostrar_nome = True
        self.mostrar_cpf = True
        self.mostrar_idade = True
        self.mostrar_data = True
        self.mostrar_telefone = True
        self.mostrar_score = True
        self.tab_titles = [
            self.TAB_TITLES["inicio"],
            self.TAB_TITLES["gerador"],
            self.TAB_TITLES["navegador"],
            self.TAB_TITLES["ia"],
        ]
        if CRUNCHYROLL_AVAILABLE:
            self.tab_titles.append(self.TAB_TITLES["crunchyroll"])
        self.tab_titles.append(self.TAB_TITLES["notas"])
        self.tab_titles.append(self.TAB_TITLES["config"])

        self._setup_window()
        self.init_ui()
        self._setup_tray()
        self.check_configuration()
        self._load_state()

    # ─── Janela ──────────────────────────────────────────────
    def _setup_window(self):
        self.setWindowTitle("Telegram Collector Pro  v11.0")
        self.setGeometry(80, 80, *self.NORMAL_SIZE)
        self.setMinimumSize(900, 600)
        self.setStyleSheet(GLOBAL_QSS)

        # Ícone
        self.app_icon = create_app_icon()
        self.setWindowIcon(self.app_icon)
        if sys.platform == "win32":
            try:
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    "TelegramCollector.Pro.v11.0"
                )
            except Exception:
                pass

    # ─── UI principal ─────────────────────────────────────────
    def init_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        root_lay = QVBoxLayout(root)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)
        root.setContentsMargins(0, 0, 0, 0)

        # ── Header
        self.header = HeaderBar()
        root_lay.addWidget(self.header)

        # ── Corpo: sidebar + stack (QSplitter para ser redimensionável)
        self.body_splitter = QSplitter(Qt.Horizontal)
        self.body_splitter.setStyleSheet(
            "QSplitter::handle{background:transparent;width:0px;}"
        )
        self.body_splitter.setChildrenCollapsible(False)
        self.body_splitter.setHandleWidth(0)

        self.sidebar = SidebarNav(show_crunchyroll=CRUNCHYROLL_AVAILABLE)
        self.sidebar.tab_changed.connect(self._on_nav)
        self.sidebar.tool_requested.connect(self.show_tools_tab)
        self.sidebar.pin_btn.clicked.connect(self.toggle_always_on_top)
        self.sidebar.fs_btn.clicked.connect(self.toggle_fullscreen)
        self.sidebar.compact_btn.clicked.connect(self.toggle_compact_mode)
        self.body_splitter.addWidget(self.sidebar)

        # Stack pages
        self.main_tabs = QTabWidget()
        self.main_tabs.setStyleSheet("QTabWidget::pane{border:none;background:transparent;} QTabBar{max-height:0;}")
        self.main_tabs.tabBar().hide()
        self.main_tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.body_splitter.addWidget(self.main_tabs)

        # Sidebar não encolhe, conteúdo pega todo o resto
        self.body_splitter.setStretchFactor(0, 0)
        self.body_splitter.setStretchFactor(1, 1)

        root_lay.addWidget(self.body_splitter, 1)

        # ── Status bar customizada
        self.status_bar = AppStatusBar()
        root_lay.addWidget(self.status_bar)

        # ── Atalhos globais
        QShortcut(QKeySequence("F11"),    self, self.toggle_fullscreen)
        QShortcut(QKeySequence("Escape"), self, self._exit_fullscreen)
        QShortcut(QKeySequence("Return"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Space"),  self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+G"), self, self.generate_pair)
        QShortcut(QKeySequence("Ctrl+C"), self, self._shortcut_copy)
        QShortcut(QKeySequence("Return"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+G"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+C"), self, self._shortcut_copy)

        # Constrói as páginas
        self._build_pages()
        self.open_page_by_name("Gerador")
        QTimer.singleShot(1200, self._run_startup_tasks)
        self.update_stats()

    def _on_nav(self, idx):
        if idx < 0 or idx >= self.main_tabs.count():
            return
        self.main_tabs.setCurrentIndex(idx)
        self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else "")

    def _page_index_by_name(self, name):
        target = name.lower()
        for i, title in enumerate(self.tab_titles):
            if target in title.lower():
                return i
        for i in range(self.main_tabs.count()):
            if target in self.main_tabs.tabText(i).lower():
                return i
        return -1

    def open_page_by_name(self, name):
        idx = self._page_index_by_name(name)
        if idx >= 0:
            self.main_tabs.setCurrentIndex(idx)
            self.sidebar.set_current(idx)
            self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else name)

    def open_notes_page(self):
        self.open_page_by_name("Notas")

    def open_global_search(self):
        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        GlobalSearchDialog(manager, self).exec_()

    def _run_startup_tasks(self):
        # Nao roda backup pesado na abertura: perfis de navegador podem ter muitos
        # arquivos e isso deixa o Windows marcar o app como "nao respondendo".
        self.status_bar.showMessage("✅ Pronto", 1500)

    # ─── Tray ────────────────────────────────────────────────
    def _setup_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray_icon = QSystemTrayIcon(self.app_icon, self)
        menu = QMenu()
        menu.addAction("Mostrar", self._show_normal)
        menu.addAction("Modo Compacto", self.toggle_compact_mode)
        menu.addSeparator()
        menu.addAction("Fixar no Topo", self.toggle_always_on_top)
        menu.addSeparator()
        menu.addAction("Sair", self.quit_application)
        self.tray_icon.setContextMenu(menu)
        self.tray_icon.activated.connect(lambda r: self._show_normal() if r == QSystemTrayIcon.DoubleClick else None)
        self.tray_icon.show()
        self.tray_icon.setToolTip("Telegram Collector Pro v11.0")

    def _show_normal(self):
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def quit_application(self):
        self._force_quit = True
        QApplication.setQuitOnLastWindowClosed(True)
        self._save_state()
        if hasattr(self, "tray_icon"):
            self.tray_icon.hide()
        QApplication.quit()

    # ─── Controles de janela ─────────────────────────────────
    def toggle_always_on_top(self):
        self.is_always_on_top = not self.is_always_on_top
        if self.is_always_on_top:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
            self.sidebar.pin_btn.setStyleSheet(self.sidebar.pin_btn.styleSheet().replace("#475569", "#f43f5e"))
            self.status_bar.showMessage("📌 Janela fixada no topo", 2500)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
            self.status_bar.showMessage("📌 Janela desfixada", 2500)
        self.show()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.is_fullscreen = False
            self.sidebar.set_collapsed(False)
            self.sidebar.fs_btn.setToolTip("  Tela cheia  [F11]  ")
            self.status_bar.showMessage("⛶ Modo janela", 2000)
        else:
            self._pre_fs_geometry = self.geometry()
            self.showFullScreen()
            self.is_fullscreen = True
            self.sidebar.set_collapsed(True)
            self.sidebar.fs_btn.setToolTip("  Sair da tela cheia  [F11 / Esc]  ")
            self.status_bar.showMessage("⛶ Tela cheia — F11 ou Esc para sair", 3000)

    def _exit_fullscreen(self):
        if self.isFullScreen():
            self.toggle_fullscreen()

    def toggle_compact_mode(self):
        if not hasattr(self, "_compact_widget"):
            self._compact_widget = CompactWidget(self.db, self._address_gen, self)

        if self.is_compact_mode:
            self._compact_widget.hide()
            self.is_compact_mode = False
            QApplication.setQuitOnLastWindowClosed(True)
            self._show_normal()
            self.status_bar.showMessage("🖥️ Modo normal", 2000)
        else:
            QApplication.setQuitOnLastWindowClosed(False)
            self.is_compact_mode = True
            self._restore_compact_pos(self._compact_widget)
            self._compact_widget.show()
            self._compact_widget.raise_()
            self.showMinimized()
            self.status_bar.showMessage("📱 Painel compacto ativo  •  arraste pelo cabeçalho", 3000)

    # ─── Persistência ────────────────────────────────────────
    def _save_state(self):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("alwaysOnTop", self.is_always_on_top)
        if hasattr(self, "_compact_widget") and self._compact_widget.isVisible():
            pos = self._compact_widget.pos()
            self.settings.setValue("compactX", pos.x())
            self.settings.setValue("compactY", pos.y())

    def _load_state(self):
        geo = self.settings.value("geometry")
        if geo:
            self.restoreGeometry(geo)
        if self.settings.value("alwaysOnTop", False, type=bool):
            self.toggle_always_on_top()

    def _restore_compact_pos(self, widget):
        """Restaura posição salva do painel compacto."""
        x = self.settings.value("compactX", type=int)
        y = self.settings.value("compactY", type=int)
        if x is not None and y is not None:
            screen = QApplication.primaryScreen().availableGeometry()
            # Garante que está dentro da tela
            x = max(0, min(x, screen.right() - widget.width()))
            y = max(0, min(y, screen.bottom() - widget.height()))
            widget.move(x, y)
        else:
            screen = QApplication.primaryScreen().availableGeometry()
            widget.move(screen.right() - widget.width() - 20, screen.top() + 60)

    # ─── Banco de dados ──────────────────────────────────────
    def _get_database(self):
        conta = self.config_manager.get_conta_ativa()
        if conta:
            return DatabaseManager(self.config_manager.get_caminho_banco(conta["id"]))
        return DatabaseManager()

    def refresh_database(self):
        self.db = self._get_database()
        if hasattr(self, "_compact_widget"):
            self._compact_widget.update_db(self.db)
        if hasattr(self, "data_pro_tab"):
            self.data_pro_tab.update_db(self.db)
        self.update_stats()

    def check_configuration(self):
        if not settings.is_configured:
            self.status_bar.showMessage(
                "⚙️ Telegram ainda não configurado. Use Config. quando for coletar.",
                5000,
            )

    # ═══════════════════════════════════════════════════════════
    #  CONSTRUÇÃO DAS PÁGINAS
    # ═══════════════════════════════════════════════════════════
    def _build_pages(self):
        self.main_tabs.addTab(self._build_inicio_page(), "Início")
        self.main_tabs.addTab(self._build_gerador_page(), "Gerador")
        self.main_tabs.addTab(self._build_navegador_page(), "Navegador")
        self.main_tabs.addTab(self._build_ai_page(), "IA Local")
        if CRUNCHYROLL_AVAILABLE:
            self.main_tabs.addTab(self._build_crunchyroll_page(), "Crunchyroll")
        self.main_tabs.addTab(self._build_notas_page(), "Notas")
        self.main_tabs.addTab(self._build_config_page(), "Config")
        self.main_tabs.addTab(self._build_ferramentas_page(), "Ferramentas")
        self.tab_titles.append(self.TAB_TITLES["ferramentas"])

    def _build_inicio_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.dashboard_page = AppDashboardWidget(
            db=self.db,
            browser_widget=getattr(self, "browser_widget", None),
            open_page=self.open_page_by_name,
            open_tool=self.show_tools_tab,
        )
        lay.addWidget(self.dashboard_page)
        return page

    # ── Página 1: Gerador de Pares ────────────────────────────
    def _build_gerador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")

        root_lay = QVBoxLayout(page)
        root_lay.setContentsMargins(10, 8, 10, 8)
        root_lay.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background: transparent;
                width: 6px;
            }
            QSplitter::handle:hover {
                background: rgba(6,182,212,0.25);
                border-radius: 3px;
            }
            QSplitter::handle:pressed {
                background: rgba(6,182,212,0.45);
            }
        """)
        splitter.setChildrenCollapsible(False)

        # === PAINEL ESQUERDO (scroll) ===
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:#07080f;width:5px;border-radius:2px;}"
            "QScrollBar::handle:vertical{background:#1a2540;border-radius:2px;min-height:20px;}"
            "QScrollBar::handle:vertical:hover{background:#06b6d4;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
        )

        left_widget = QWidget()
        left_widget.setStyleSheet("background:transparent;")
        left_lay = QVBoxLayout(left_widget)
        left_lay.setContentsMargins(0, 0, 6, 0)
        left_lay.setSpacing(6)

        sp_qss = ("QSpinBox{background:#0d1525;border:1px solid rgba(6,182,212,0.2);"
                  "border-radius:6px;color:#e2e8f0;padding:3px 6px;font-size:12px;min-width:52px;}"
                  "QSpinBox::up-button,QSpinBox::down-button{width:14px;border:none;background:transparent;}")
        cb_qss = ("QCheckBox{color:#94a3b8;font-size:12px;spacing:5px;}"
                  "QCheckBox::indicator{width:13px;height:13px;"
                  "border:1px solid rgba(6,182,212,0.3);border-radius:3px;background:#0d1525;}"
                  "QCheckBox::indicator:checked{background:#06b6d4;border-color:#06b6d4;}")
        sec_btn_qss = ("QPushButton{background:rgba(255,255,255,0.035);color:#64748b;"
                       "border:1px solid rgba(255,255,255,0.07);border-radius:6px;"
                       "font-size:11px;padding:5px 4px;}"
                       "QPushButton:hover{background:rgba(6,182,212,0.12);color:#94a3b8;"
                       "border-color:rgba(6,182,212,0.3);}")

        def sec_lbl(txt):
            l = QLabel(txt)
            l.setStyleSheet("color:#1e3a4a;font-size:10px;font-weight:700;letter-spacing:1px;"
                            "background:transparent;border:none;padding:2px 0 0 0;")
            return l

        def card(build_fn):
            f = QFrame()
            f.setStyleSheet("QFrame{background:#0d1525;border:1px solid rgba(6,182,212,0.09);border-radius:10px;}")
            f.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            lay = QVBoxLayout(f)
            lay.setContentsMargins(12, 10, 12, 10)
            lay.setSpacing(7)
            build_fn(lay)
            return f

        # CARD FILTROS
        def build_filters(lay):
            lay.addWidget(sec_lbl("FILTROS"))
            row = QHBoxLayout(); row.setSpacing(8)
            self.filtro_checkbox = QCheckBox("Idade")
            self.filtro_checkbox.setStyleSheet(cb_qss)
            self.filtro_checkbox.stateChanged.connect(self.toggle_filtro)
            self.idade_min_spin = QSpinBox()
            self.idade_min_spin.setRange(0,120); self.idade_min_spin.setValue(18)
            self.idade_min_spin.setEnabled(False); self.idade_min_spin.setStyleSheet(sp_qss)
            self.idade_max_spin = QSpinBox()
            self.idade_max_spin.setRange(0,120); self.idade_max_spin.setValue(65)
            self.idade_max_spin.setEnabled(False); self.idade_max_spin.setStyleSheet(sp_qss)
            s1 = QLabel("–"); s1.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_checkbox)
            row.addWidget(self.idade_min_spin)
            row.addWidget(s1)
            row.addWidget(self.idade_max_spin)
            row.addSpacing(12)
            self.filtro_score_checkbox = QCheckBox("Score")
            self.filtro_score_checkbox.setStyleSheet(cb_qss)
            self.filtro_score_checkbox.stateChanged.connect(self.toggle_filtro_score)
            self.score_min_spin = QSpinBox()
            self.score_min_spin.setRange(0,1000); self.score_min_spin.setValue(500)
            self.score_min_spin.setEnabled(False); self.score_min_spin.setStyleSheet(sp_qss)
            self.score_max_spin = QSpinBox()
            self.score_max_spin.setRange(0,1000); self.score_max_spin.setValue(1000)
            self.score_max_spin.setEnabled(False); self.score_max_spin.setStyleSheet(sp_qss)
            s2 = QLabel("–"); s2.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_score_checkbox)
            row.addWidget(self.score_min_spin)
            row.addWidget(s2)
            row.addWidget(self.score_max_spin)
            row.addStretch()
            lay.addLayout(row)
            disp = QHBoxLayout(); disp.setSpacing(10)
            lbl_e = QLabel("Exibir:"); lbl_e.setStyleSheet("color:#334155;font-size:11px;")
            disp.addWidget(lbl_e)
            for field, txt in [("nome","Nome"),("cpf","CPF"),("idade","Idade"),
                               ("data","Nasc."),("telefone","Tel."),("score","Score")]:
                cb = QCheckBox(txt); cb.setChecked(True); cb.setStyleSheet(cb_qss)
                cb.stateChanged.connect(lambda _, f=field: self.toggle_display(f))
                setattr(self, f"check_{field}", cb)
                disp.addWidget(cb)
            disp.addStretch()
            lay.addLayout(disp)
        left_lay.addWidget(card(build_filters))

        # CARD ACOES
        def build_acoes(lay):
            lay.addWidget(sec_lbl("AÇÕES"))
            mrow = QHBoxLayout(); mrow.setSpacing(8)
            self.generate_btn = QPushButton("🎲  GERAR PAR")
            self.generate_btn.setCursor(Qt.PointingHandCursor)
            self.generate_btn.setFixedHeight(40)
            self.generate_btn.setStyleSheet("""
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #059669,stop:1 #10b981);
                color:white;border:none;border-radius:8px;font-size:13px;font-weight:700;}
                QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #047857,stop:1 #059669);}
                QPushButton:disabled{background:#1a2540;color:#334155;}""")
            self.generate_btn.clicked.connect(self.generate_pair)
            cbtn = QPushButton("📋  COPIAR")
            cbtn.setCursor(Qt.PointingHandCursor)
            cbtn.setFixedHeight(40)
            cbtn.setStyleSheet("""
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0891b2,stop:1 #06b6d4);
                color:white;border:none;border-radius:8px;font-size:13px;font-weight:700;}
                QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0e7490,stop:1 #0891b2);}""")
            cbtn.clicked.connect(self.copy_result)
            mrow.addWidget(self.generate_btn, 3)
            mrow.addWidget(cbtn, 2)
            lay.addLayout(mrow)
            grid = QGridLayout(); grid.setSpacing(5)
            for i, (txt, fn) in enumerate([
                ("📥 Coletar", self.start_collection), ("📊 Ver Dados", self.show_data),
                ("💾 Exportar", self.export_data), ("📋 Grupos", self.show_groups_dialog),
                ("⚙️ Config.", self.show_config_dialog), ("📱 Contas", self.show_contas_dialog),
            ]):
                b = QPushButton(txt); b.setFixedHeight(28); b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(sec_btn_qss); b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.clicked.connect(fn)
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_acoes))

        # CARD RAPIDO
        def build_rapido(lay):
            lay.addWidget(sec_lbl("ACESSO RÁPIDO"))
            grid = QGridLayout(); grid.setSpacing(5)
            items = [("💳 Cartões",0,"#10b981"),("🏠 CEP",1,"#06b6d4"),
                     ("✅ CPF/CNPJ",4,"#8b5cf6"),("🎭 Fake",5,"#f59e0b"),
                     ("📧 Organizador",2,"#0ea5e9"),("⚡ Desempenho",6,"#fbbf24")]
            for i, (txt, ti, color) in enumerate(items):
                b = QPushButton(txt); b.setFixedHeight(27); b.setCursor(Qt.PointingHandCursor)
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.setStyleSheet(f"QPushButton{{background:rgba(6,182,212,0.05);color:{color};"
                               f"border:1px solid {color}28;border-radius:6px;font-size:11px;font-weight:600;}}"
                               f"QPushButton:hover{{background:{color}18;border-color:{color}55;}}")
                b.clicked.connect(lambda _, i=ti: self.show_tools_tab(i))
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_rapido))

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setStyleSheet("QProgressBar{background:#0d1525;border:none;border-radius:1px;}"
                                        "QProgressBar::chunk{background:#06b6d4;border-radius:1px;}")
        self.progress_bar.setTextVisible(False)
        left_lay.addWidget(self.progress_bar)

        self.stats_label = QLabel("—")
        self.stats_label.setAlignment(Qt.AlignCenter)
        self.stats_label.setStyleSheet("color:#1a3040;font-size:10px;background:transparent;border:none;")
        self.stats_label.setWordWrap(True)
        left_lay.addWidget(self.stats_label)
        left_lay.addStretch(1)

        left_scroll.setWidget(left_widget)
        splitter.addWidget(left_scroll)

        # === PAINEL DIREITO — RESULTADO ===
        right_widget = QWidget()
        right_widget.setStyleSheet("background:transparent;")
        right_lay = QVBoxLayout(right_widget)
        right_lay.setContentsMargins(6, 0, 0, 0)
        right_lay.setSpacing(6)
        right_lay.addWidget(sec_lbl("RESULTADO"))

        rc = QFrame()
        rc.setStyleSheet("QFrame{background:#0d1525;border:1px solid rgba(6,182,212,0.09);border-radius:10px;}")
        rc.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rc_lay = QVBoxLayout(rc)
        rc_lay.setContentsMargins(12, 10, 12, 10)
        rc_lay.setSpacing(7)

        field_qss = ("QLabel{color:#22d3ee;font-family:'Consolas','Cascadia Code',monospace;"
                     "font-size:13px;font-weight:500;background:#07080f;"
                     "border:1px solid rgba(6,182,212,0.09);border-radius:7px;"
                     "padding:8px 12px;}")
        cp_qss = ("QPushButton{background:rgba(6,182,212,0.07);border:1px solid rgba(6,182,212,0.15);"
                  "border-radius:6px;font-size:12px;color:#06b6d4;"
                  "min-width:28px;max-width:28px;min-height:28px;max-height:28px;}"
                  "QPushButton:hover{background:rgba(6,182,212,0.22);}")

        for icon, attr, label_txt in [
            ("👤","nome","Nome"), ("🆔","cpf","CPF"), ("🎂","idade","Idade"),
            ("📅","nasc","Nascimento"), ("📞","telefone","Telefone"), ("⭐","score","Score"),
        ]:
            row = QHBoxLayout(); row.setSpacing(8)
            lbl = QLabel(f"{icon}   {label_txt}: —")
            lbl.setStyleSheet(field_qss)
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            cp = QPushButton("⎘")
            cp.setStyleSheet(cp_qss); cp.setCursor(Qt.PointingHandCursor)
            cp.setToolTip(f"Copiar {label_txt}")
            cp.clicked.connect(lambda _, a=attr: self.copy_field(a))
            row.addWidget(lbl, 1); row.addWidget(cp)
            rc_lay.addLayout(row)
            setattr(self, f"{attr}_label", lbl)
        rc_lay.addStretch(1)

        right_lay.addWidget(rc, 1)
        splitter.addWidget(right_widget)

        splitter.setSizes([420, 580])
        splitter.setStretchFactor(0, 42)
        splitter.setStretchFactor(1, 58)
        root_lay.addWidget(splitter, 1)

        self.nome_label.setText("👤   Nome: —")
        self.cpf_label.setText("🆔   CPF: —")
        self.idade_label.setText("🎂   Idade: —")
        self.nasc_label.setText("📅   Nascimento: —")
        self.telefone_label.setText("📞   Telefone: —")
        self.score_label.setText("⭐   Score: —")

        return page

    # ── Página 2: Ferramentas ────────────────────────────────
    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 0;
            }
            QTabBar {
                background: #07080f;
                border-bottom: 1px solid rgba(6,182,212,0.08);
            }
            QTabBar::tab {
                background: transparent;
                color: #475569;
                padding: 7px 11px;
                margin-right: 1px;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                background: rgba(6,182,212,0.06);
                border-bottom: 2px solid #06b6d4;
                font-weight: 700;
            }
            QTabBar::tab:hover:!selected {
                color: #94a3b8;
                background: rgba(255,255,255,0.03);
            }
            QTabBar::scroller { width: 22px; }
            QTabBar QToolButton {
                background: #0d1525;
                border: 1px solid rgba(6,182,212,0.2);
                color: #06b6d4;
                border-radius: 4px;
                font-size: 12px;
            }
            QTabBar QToolButton:hover { background: rgba(6,182,212,0.18); }
        """)

        tools_helper = ToolsDialog(self)
        self.tools_tabs.addTab(tools_helper.create_card_generator_tab(), "💳 Cartões")
        self.tools_tabs.addTab(tools_helper.create_cep_generator_tab(), "🏠 CEP")
        self.tools_tabs.addTab(tools_helper.create_account_formatter_tab(), "📧 Organizador")
        self.tools_tabs.addTab(DataOrganizer(), "🗂️ Formatar")
        self.tools_tabs.addTab(ValidadorWidget(), "✅ CPF/CNPJ")
        self.tools_tabs.addTab(GeradorFakeWidget(), "🎭 Fake")
        self.tools_tabs.addTab(PerformanceWidget(), "⚡ Desempenho")
        self.data_pro_tab = DataProWidget(self.db)
        self.tools_tabs.addTab(self.data_pro_tab, "🧹 Dados Pro")
        self.tools_tabs.addTab(TextCorrectorWidget(), "✍️ Português")

        lay.addWidget(self.tools_tabs)
        return page

    # ── Página 3: Navegador ──────────────────────────────────
    def _build_navegador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)

        self.browser_tabs = QTabWidget()
        self.browser_tabs.setStyleSheet(TAB_TOP_QSS)
        self.browser_widget = BrowserWidget()
        if hasattr(self, "dashboard_page"):
            self.dashboard_page.browser_widget = self.browser_widget
            self.dashboard_page.browser_manager = self.browser_widget.browser_manager
        self.browser_tabs.addTab(self.browser_widget, "🌐 Navegador")
        if PROFILE_DEFAULTS_AVAILABLE:
            config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "browser_config")
            self.profile_defaults_tab = ProfileDefaultsWidget(config_dir)
            self.browser_tabs.addTab(self.profile_defaults_tab, "⚙️ Configurações")
        lay.addWidget(self.browser_tabs)
        return page

    def _build_ai_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.ai_assistant_tab = AIAssistantWidget()
        lay.addWidget(self.ai_assistant_tab)
        return page

    # ── Página 4: Crunchyroll ────────────────────────────────
    def _build_crunchyroll_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(8)

        quick = QFrame()
        quick.setStyleSheet(
            "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.12);border-radius:8px;}"
        )
        quick_lay = QHBoxLayout(quick)
        quick_lay.setContentsMargins(10, 8, 10, 8)
        quick_lay.setSpacing(8)
        title = QLabel("Crunchyroll")
        title.setStyleSheet("color:#e2e8f0;font-weight:900;font-size:14px;background:transparent;border:none;")
        quick_lay.addWidget(title)
        quick_lay.addStretch()

        back_btn = QPushButton("← Voltar")
        back_btn.setFixedHeight(32)
        back_btn.setToolTip("Voltar para o início do Crunchyroll")
        back_btn.clicked.connect(self._crunchyroll_back)
        quick_lay.addWidget(back_btn)

        for text, tab_name in [
            ("Contas", "Contas"),
            ("Cartões", "Cartões"),
            ("Resultados", "Resultados"),
            ("Verificador", "Verificador"),
        ]:
            btn = QPushButton(text)
            btn.setFixedHeight(32)
            btn.clicked.connect(lambda _, name=tab_name: self._open_crunchyroll_bot_tab(name))
            quick_lay.addWidget(btn)

        if CRUNCHYROLL_LOGIN_AVAILABLE:
            login_btn = QPushButton("Login/Auth")
            login_btn.setFixedHeight(32)
            login_btn.clicked.connect(self._open_crunchyroll_login_tab)
            quick_lay.addWidget(login_btn)

        refresh_btn = QPushButton("Atualizar resultados")
        refresh_btn.setFixedHeight(32)
        refresh_btn.clicked.connect(self._refresh_crunchyroll_results)
        quick_lay.addWidget(refresh_btn)
        lay.addWidget(quick)

        self.crunchy_tabs = QTabWidget()
        self.crunchy_tabs.setStyleSheet(TAB_TOP_QSS)
        self.crunchyroll_tab = CrunchyrollWidget()
        self.crunchy_tabs.addTab(self.crunchyroll_tab, "🍦 Bot Principal")
        if CRUNCHYROLL_LOGIN_AVAILABLE:
            self.crunchyroll_login_tab = CrunchyrollLoginWidget()
            self.crunchy_tabs.addTab(self.crunchyroll_login_tab, "🔐 Login/Auth")
        lay.addWidget(self.crunchy_tabs)
        return page

    def _open_crunchyroll_bot_tab(self, tab_name):
        if hasattr(self, "crunchy_tabs"):
            self.crunchy_tabs.setCurrentIndex(0)
        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if not inner_tabs:
            return
        target = tab_name.lower()
        for i in range(inner_tabs.count()):
            if target in inner_tabs.tabText(i).lower():
                inner_tabs.setCurrentIndex(i)
                break

    def _crunchyroll_back(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.currentIndex() != 0:
            self.crunchy_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Bot Principal", 2000)
            return

        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if inner_tabs and inner_tabs.currentIndex() != 0:
            inner_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Controle do Crunchyroll", 2000)
            return

        self.status_bar.showMessage("ℹ️ Você já está no início do Crunchyroll", 2000)

    def _open_crunchyroll_login_tab(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.count() > 1:
            self.crunchy_tabs.setCurrentIndex(1)

    def _refresh_crunchyroll_results(self):
        refreshed = False
        for widget_name in ("crunchyroll_tab", "crunchyroll_login_tab"):
            widget = getattr(self, widget_name, None)
            if widget and hasattr(widget, "load_results"):
                widget.load_results()
                refreshed = True
        if refreshed:
            self.status_bar.showMessage("✅ Resultados do Crunchyroll atualizados", 2500)

    # ── Página 5: Notas ──────────────────────────────────────
    def _build_notas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.notepad_tab = NotepadWidget()
        lay.addWidget(self.notepad_tab)
        return page

    def _build_config_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        self.general_settings_tab = GeneralSettingsWidget(manager)
        lay.addWidget(self.general_settings_tab)
        return page

    # ═══════════════════════════════════════════════════════════
    #  MÉTODOS DE NEGÓCIO (idênticos ao original)
    # ═══════════════════════════════════════════════════════════
    def _shortcut_generate(self):
        """Atalho Ctrl+G ou Enter: gera par apenas se na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            self.generate_pair()

    def _shortcut_copy(self):
        """Atalho Ctrl+C: copia resultado se na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador") and self.current_pair:
            self.copy_result()

    def statusBar(self):
        return self.status_bar

    def _shortcut_generate(self):
        """Enter/Space gera par apenas quando na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            self.generate_pair()

    def _shortcut_copy(self):
        """Ctrl+C copia resultado apenas quando na aba Gerador e sem seleção."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            focused = QApplication.focusWidget()
            # Só age se não houver widget de texto com foco
            if not isinstance(focused, (QLineEdit, QTextEdit, QPlainTextEdit)):
                self.copy_result()

    def toggle_filtro(self, state):
        enabled = state == Qt.Checked
        self.idade_min_spin.setEnabled(enabled)
        self.idade_max_spin.setEnabled(enabled)

    def toggle_filtro_score(self, state):
        enabled = state == Qt.Checked
        self.score_min_spin.setEnabled(enabled)
        self.score_max_spin.setEnabled(enabled)

    def toggle_display(self, field):
        mapping = {
            "nome": "mostrar_nome", "cpf": "mostrar_cpf",
            "idade": "mostrar_idade", "data": "mostrar_data",
            "telefone": "mostrar_telefone", "score": "mostrar_score",
        }
        if field in mapping:
            cb = getattr(self, f"check_{field}", None)
            if cb:
                setattr(self, mapping[field], cb.isChecked())
        self.update_field_visibility()
        if self.current_pair:
            self.display_pair(self.current_pair)

    def update_field_visibility(self):
        pairs = [
            ("nome_label", self.mostrar_nome),
            ("cpf_label", self.mostrar_cpf),
            ("idade_label", self.mostrar_idade),
            ("nasc_label", self.mostrar_data),
            ("telefone_label", self.mostrar_telefone),
            ("score_label", self.mostrar_score),
        ]
        for attr, vis in pairs:
            w = getattr(self, attr, None)
            if w:
                w.setVisible(vis)

    def update_stats(self):
        stats = self.db.get_stats()
        txt = (f"📊 {stats['total']}  ✅ {stats['complete']}  "
               f"📅 {stats.get('with_birth',0)}  📞 {stats['with_phone']}  ⭐ {stats['with_score']}")
        self.stats_label.setText(txt)
        self.header.set_stats(txt)

    def generate_pair(self):
        filters = {}
        if self.filtro_checkbox.isChecked():
            filters["idade_min"] = self.idade_min_spin.value()
            filters["idade_max"] = self.idade_max_spin.value()
        if self.filtro_score_checkbox.isChecked():
            filters["score_min"] = self.score_min_spin.value()
            filters["score_max"] = self.score_max_spin.value()
        pair = self.db.get_random_pair(filters)
        if pair:
            self.current_pair = pair
            self.display_pair(pair)
            self._flash_result_fields()
            self.status_bar.showMessage("✅ Par gerado com sucesso!", 1500)
        else:
            for attr in ["nome_label","cpf_label","idade_label","nasc_label","telefone_label","score_label"]:
                lbl = getattr(self, attr, None)
                if lbl: lbl.setText(lbl.text().split(":")[0] + ":  —")
            self.current_pair = None
            self.status_bar.showMessage("❌ Nenhum registro encontrado com os filtros aplicados", 3000)

    def _flash_result_fields(self):
        """Flash verde rápido nos campos de resultado para feedback visual."""
        flash_qss = ("QLabel{color:#10b981;font-family:'Consolas','Cascadia Code',monospace;"
                     "font-size:13px;font-weight:500;background:#071a10;"
                     "border:1px solid rgba(16,185,129,0.4);border-radius:7px;padding:8px 12px;}")
        normal_qss = ("QLabel{color:#22d3ee;font-family:'Consolas','Cascadia Code',monospace;"
                      "font-size:13px;font-weight:500;background:#07080f;"
                      "border:1px solid rgba(6,182,212,0.09);border-radius:7px;padding:8px 12px;}")
        labels = [getattr(self, a, None) for a in
                  ["nome_label","cpf_label","idade_label","nasc_label","telefone_label","score_label"]]
        labels = [l for l in labels if l]
        for l in labels:
            l.setStyleSheet(flash_qss)
        QTimer.singleShot(350, lambda: [l.setStyleSheet(normal_qss) for l in labels if l])

    def display_pair(self, pair):
        def _set(attr, prefix, key):
            lbl = getattr(self, f"{attr}_label", None)
            if lbl:
                val = pair.get(key, "")
                lbl.setText(f"{prefix}  {val}" if val else f"{prefix}  —")
        _set("nome",  "👤  Nome:", "nome")
        _set("cpf",   "🆔  CPF:", "cpf")
        idade_lbl = getattr(self, "idade_label", None)
        if idade_lbl:
            v = pair.get("idade")
            idade_lbl.setText(f"🎂  Idade:  {v} anos" if v else "🎂  Idade:  —")
        _set("nasc",  "📅  Nasc.:", "nascimento")
        _set("telefone", "📞  Tel.:", "telefone")
        _set("score", "⭐  Score:", "score")
        self.update_field_visibility()

    def copy_field(self, field):
        if not self.current_pair:
            self.status_bar.showMessage("⚠️ Nenhum dado para copiar", 2000)
            return
        key_map = {"nome":"nome","cpf":"cpf","idade":"idade","nasc":"nascimento",
                   "telefone":"telefone","score":"score"}
        key = key_map.get(field, field)
        val = self.current_pair.get(key)
        if val:
            _set_clipboard_text_safe(str(val))
            self.status_bar.showMessage(f"✅ {key.capitalize()} copiado!", 1500)
            # Flash verde no label copiado
            lbl_attr = f"{field}_label"
            lbl = getattr(self, lbl_attr, None)
            if lbl:
                orig = lbl.styleSheet()
                flash = orig.replace("#22d3ee", "#10b981").replace("#07080f", "#071a10").replace(
                    "rgba(6,182,212,0.09)", "rgba(16,185,129,0.35)")
                lbl.setStyleSheet(flash)
                QTimer.singleShot(400, lambda: lbl.setStyleSheet(orig))

    def copy_result(self):
        if not self.current_pair:
            self.status_bar.showMessage("⚠️ Nenhum dado para copiar", 2000)
            return
        p = self.current_pair
        lines = []
        if self.mostrar_nome and p.get("nome"): lines.append(f"👤 Nome: {p['nome']}")
        if self.mostrar_cpf and p.get("cpf"):   lines.append(f"🆔 CPF: {p['cpf']}")
        if self.mostrar_idade and p.get("idade"): lines.append(f"🎂 Idade: {p['idade']} anos")
        if self.mostrar_data and p.get("nascimento"): lines.append(f"📅 Nascimento: {p['nascimento']}")
        if self.mostrar_telefone and p.get("telefone"): lines.append(f"📞 Telefone: {p['telefone']}")
        if self.mostrar_score and p.get("score"): lines.append(f"⭐ Score: {p['score']}")
        if lines:
            _set_clipboard_text_safe("\n".join(lines))
            self.status_bar.showMessage("✅ Todos os dados copiados!", 2000)

    def show_tools(self):
        idx = self._page_index_by_name("Ferramentas")
        if idx < 0:
            return
        self.main_tabs.setCurrentIndex(idx)
        self.sidebar.set_current(idx)
        self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else "🛠️  Ferramentas")

    def show_tools_tab(self, tab_index):
        self.show_tools()
        if 0 <= tab_index < self.tools_tabs.count():
            self.tools_tabs.setCurrentIndex(tab_index)
        elif tab_index == 6:
            self.open_page_by_name("Config")

    def show_groups_dialog(self):
        GroupManagerDialog(self).exec_()

    def show_contas_dialog(self):
        GerenciadorContas(self).exec_()
        self.config_manager.load_config()
        self.refresh_database()

    def show_config_dialog(self):
        if ConfigDialog(self).exec_() == QDialog.Accepted:
            self.update_stats()

    def start_collection(self):
        config_manager = ConfigManager()
        conta_ativa = config_manager.get_conta_ativa()
        if not settings.is_configured and not conta_ativa:
            QMessageBox.warning(self, "Configuração", "Configure as credenciais primeiro!")
            self.show_config_dialog()
            return
        groups_file = BASE_DIR / "grupos.json"
        groups = [settings.default_group]
        if groups_file.exists():
            try:
                with open(groups_file, "r") as f:
                    groups = json.load(f)
            except (json.JSONDecodeError, IOError, PermissionError) as e:
                print(f"Aviso: {e}")
        if len(groups) > 1:
            reply = QMessageBox.question(self, "Coletar Dados",
                f"Você tem {len(groups)} grupos.\nGrupos: {', '.join(groups)}\n\nColetar de TODOS?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
            if reply == QMessageBox.Cancel: return
            if reply == QMessageBox.No: groups = [groups[0]]
        else:
            if QMessageBox.question(self, "Coletar Dados",
                "Receberá um código SMS.\nContinuar?",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.No:
                return
        # Padrao automatico: exige data de nascimento e ignora 60+ quando a
        # idade puder ser detectada. Score nao e obrigatorio.
        exigir_data = True
        filtrar_idosos = True
        idade_maxima = 59
        self.status_bar.showMessage(
            "Coleta automatica: exige data de nascimento, nao exige score e ignora 60+.",
            6000
        )
        self.progress_bar.setVisible(True); self.progress_bar.setRange(0,0)
        self.generate_btn.setEnabled(False)
        conta_id = conta_ativa["id"] if conta_ativa else None
        self.collector_thread = CollectorThread(
            groups=groups, filtrar_idosos=filtrar_idosos,
            idade_maxima=idade_maxima, exigir_data_nascimento=exigir_data,
            conta_id=conta_id)
        self.collector_thread.progress.connect(self.show_progress)
        self.collector_thread.error.connect(self.show_error)
        self.collector_thread.finished.connect(self.collection_finished)
        self.collector_thread.code_requested.connect(self.show_code_dialog)
        self.collector_thread.password_requested.connect(self.show_password_dialog)
        self.collector_thread.start()

    def show_code_dialog(self, phone):
        dlg = CodeInputDialog(phone, self)
        if dlg.exec_() == QDialog.Accepted and dlg.code:
            self.collector_thread.set_verification_code(dlg.code)
        else:
            self.show_error("Autenticação cancelada.")

    def show_password_dialog(self):
        dlg = PasswordInputDialog(self)
        if dlg.exec_() == QDialog.Accepted and dlg.password:
            self.collector_thread.set_password(dlg.password)
        else:
            self.show_error("Autenticação 2FA cancelada.")

    def show_progress(self, msg):
        self.status_bar.showMessage(msg)

    def show_error(self, err):
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        QMessageBox.critical(self, "Erro", f"Erro na coleta:\n{err}")

    def collection_finished(self, collected):
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        self.refresh_database()
        QMessageBox.information(self, "Sucesso", f"Coleta concluída!\n\n{collected} novos registros.")

    def show_data(self):
        DataViewDialog(self.db, self).exec_()

    def export_data(self):
        fp, _ = QFileDialog.getSaveFileName(self, "Salvar CSV", "dados_completo.csv", "CSV (*.csv)")
        if fp:
            if self.db.export_csv(fp, "completo"):
                QMessageBox.information(self, "Sucesso", f"Exportado:\n{fp}")
            else:
                QMessageBox.critical(self, "Erro", "Erro ao exportar")

    # ─── Eventos da janela ───────────────────────────────────
    def closeEvent(self, event):
        self._save_state()
        if (
            not getattr(self, "_force_quit", False)
            and hasattr(self, "_compact_widget")
            and self._compact_widget.isVisible()
        ):
            self.hide()
            event.ignore()
            return
        try:
            close_to_tray = bool(load_app_settings().get("close_to_tray", False))
        except Exception:
            close_to_tray = False
        if close_to_tray and hasattr(self, "tray_icon") and self.tray_icon.isVisible():
            self.hide()
            self.tray_icon.showMessage(
                "Telegram Collector Pro",
                "Minimizado para a bandeja. Use Sair no menu da bandeja para encerrar.",
                QSystemTrayIcon.Information,
                2000,
            )
            event.ignore()
            return
        if hasattr(self, "_compact_widget"):
            self._compact_widget.hide()
        if hasattr(self, "tray_icon"):
            self.tray_icon.hide()
        event.accept()
        self._force_quit = True
        QTimer.singleShot(0, QApplication.quit)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F11:
            self.toggle_fullscreen()
        else:
            super().keyPressEvent(event)


def main():
    install_crash_logger()
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setStyle('Fusion')
    
    # Aplicar paleta escura
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(10, 14, 26))
    palette.setColor(QPalette.WindowText, QColor(241, 245, 249))
    palette.setColor(QPalette.Base, QColor(17, 24, 39))
    palette.setColor(QPalette.AlternateBase, QColor(15, 23, 42))
    palette.setColor(QPalette.ToolTipBase, QColor(30, 41, 59))
    palette.setColor(QPalette.ToolTipText, QColor(241, 245, 249))
    palette.setColor(QPalette.Text, QColor(241, 245, 249))
    palette.setColor(QPalette.Button, QColor(8, 145, 178))
    palette.setColor(QPalette.ButtonText, QColor(241, 245, 249))
    palette.setColor(QPalette.BrightText, QColor(34, 211, 238))
    palette.setColor(QPalette.Highlight, QColor(6, 182, 212))
    palette.setColor(QPalette.HighlightedText, QColor(10, 14, 26))
    app.setPalette(palette)
    
    window = SimpleApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

