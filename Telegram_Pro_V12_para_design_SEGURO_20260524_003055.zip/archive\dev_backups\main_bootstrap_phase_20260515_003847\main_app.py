#!/usr/bin/env python3
"""
Aplicação Principal - Coletor de Dados Telegram
Versão 11.0 - Interface Reorganizada + Acesso Rápido às Ferramentas
"""
import sys

from PyQt5.QtGui import QColor, QPalette
from PyQt5.QtWidgets import QApplication, QMainWindow

from app.core.error_service import install_crash_logger as core_install_crash_logger
from app.ui.app_state import MainStateMixin
from app.ui.main_actions import MainActionsMixin
from app.ui.main_layout import MainLayoutMixin
from app.ui.main_pages import MainPagesMixin
from app.ui.window_controls import MainWindowControlsMixin
from settings import BASE_DIR

def install_crash_logger():
    """Guarda erros fatais em arquivo para diagnosticar fechamentos silenciosos."""
    core_install_crash_logger(BASE_DIR)


class SimpleApp(MainStateMixin, MainLayoutMixin, MainWindowControlsMixin, MainActionsMixin, MainPagesMixin, QMainWindow):
    """Janela principal — design lateral moderno com sidebar de ícones."""

    NORMAL_SIZE = (1280, 860)
    COMPACT_SIZE = (400, 600)

    # Títulos das abas para o header
    TAB_TITLES = {
        "inicio": "🏠  Painel Inicial",
        "gerador": "🎲  Gerador de Pares",
        "ferramentas": "🛠️  Ferramentas",
        "navegador": "🌐  Navegador Seguro",
        "ia": "🤖  IA Local",
        "crunchyroll": "🍦  Crunchyroll",
        "notas": "📝  Bloco de Notas",
        "config": "⚙️  Configurações",
    }

    def __init__(self):
        super().__init__()
        self.initialize_runtime_state()
        self._setup_window()
        self.init_ui()
        self._setup_tray()
        self.check_configuration()
        self._load_state()

    # ─── Janela ──────────────────────────────────────────────

    # ─── UI principal ─────────────────────────────────────────


    # ─── Tray ────────────────────────────────────────────────


    # ─── Controles de janela ─────────────────────────────────


    # ─── Persistência ────────────────────────────────────────


    # ─── Banco de dados ──────────────────────────────────────


def main():
    install_crash_logger()
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setStyle('Fusion')
    
    # Aplicar paleta escura
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(10, 14, 26))
    palette.setColor(QPalette.WindowText, QColor(241, 245, 249))
    palette.setColor(QPalette.Base, QColor(17, 24, 39))
    palette.setColor(QPalette.AlternateBase, QColor(15, 23, 42))
    palette.setColor(QPalette.ToolTipBase, QColor(30, 41, 59))
    palette.setColor(QPalette.ToolTipText, QColor(241, 245, 249))
    palette.setColor(QPalette.Text, QColor(241, 245, 249))
    palette.setColor(QPalette.Button, QColor(8, 145, 178))
    palette.setColor(QPalette.ButtonText, QColor(241, 245, 249))
    palette.setColor(QPalette.BrightText, QColor(34, 211, 238))
    palette.setColor(QPalette.Highlight, QColor(6, 182, 212))
    palette.setColor(QPalette.HighlightedText, QColor(10, 14, 26))
    app.setPalette(palette)
    
    window = SimpleApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

