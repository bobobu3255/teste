#!/usr/bin/env python3
"""Builder da pagina Ferramentas."""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTabWidget, QVBoxLayout, QWidget


class ToolsPageMixin:
    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 0;
            }
            QTabBar {
                background: #07080f;
                border-bottom: 1px solid rgba(6,182,212,0.08);
            }
            QTabBar::tab {
                background: transparent;
                color: #475569;
                padding: 7px 11px;
                margin-right: 1px;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                background: rgba(6,182,212,0.06);
                border-bottom: 2px solid #06b6d4;
                font-weight: 700;
            }
            QTabBar::tab:hover:!selected {
                color: #94a3b8;
                background: rgba(255,255,255,0.03);
            }
            QTabBar::scroller { width: 22px; }
            QTabBar QToolButton {
                background: #0d1525;
                border: 1px solid rgba(6,182,212,0.2);
                color: #06b6d4;
                border-radius: 4px;
                font-size: 12px;
            }
            QTabBar QToolButton:hover { background: rgba(6,182,212,0.18); }
        """)

        from app.features.tools.dialog import ToolsDialog
        from data_organizer import DataOrganizer
        from data_pro_widget import DataProWidget
        from extra_tools import GeradorFakeWidget, ValidadorWidget
        from performance_widget import PerformanceWidget
        from text_corrector_widget import TextCorrectorWidget

        tools_helper = ToolsDialog(self)
        self.tools_tabs.addTab(tools_helper.create_card_generator_tab(), "💳 Cartões")
        self.tools_tabs.addTab(tools_helper.create_cep_generator_tab(), "🏠 CEP")
        self.tools_tabs.addTab(tools_helper.create_account_formatter_tab(), "📧 Organizador")
        self.tools_tabs.addTab(DataOrganizer(), "🗂️ Formatar")
        self.tools_tabs.addTab(ValidadorWidget(), "✅ CPF/CNPJ")
        self.tools_tabs.addTab(GeradorFakeWidget(), "🎭 Fake")
        self.tools_tabs.addTab(PerformanceWidget(), "⚡ Desempenho")
        self.data_pro_tab = DataProWidget(self.db)
        self.tools_tabs.addTab(self.data_pro_tab, "🧹 Dados Pro")
        self.tools_tabs.addTab(TextCorrectorWidget(), "✍️ Português")

        lay.addWidget(self.tools_tabs)
        return page
