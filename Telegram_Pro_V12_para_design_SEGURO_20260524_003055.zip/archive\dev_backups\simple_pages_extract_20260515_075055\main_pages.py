#!/usr/bin/env python3
"""Builders de paginas da janela principal.

Este mixin mantem a construcao visual fora do main_app.py sem mudar o fluxo do SimpleApp.
"""

from PyQt5.QtWidgets import QVBoxLayout, QWidget

from app.ui.browser_page import BrowserPageMixin
from app.ui.crunchyroll_page import CRUNCHYROLL_AVAILABLE, CrunchyrollPageMixin
from app.ui.tools_page import ToolsPageMixin
class MainPagesMixin(CrunchyrollPageMixin, ToolsPageMixin, BrowserPageMixin):
    def _build_pages(self):
        self.main_tabs.addTab(self._build_inicio_page(), "Início")
        self.main_tabs.addTab(self._build_gerador_page(), "Gerador")
        self.main_tabs.addTab(self._build_navegador_page(), "Navegador")
        self.main_tabs.addTab(self._build_ai_page(), "IA Local")
        if CRUNCHYROLL_AVAILABLE:
            self.main_tabs.addTab(self._build_crunchyroll_page(), "Crunchyroll")
        self.main_tabs.addTab(self._build_notas_page(), "Notas")
        self.main_tabs.addTab(self._build_config_page(), "Config")
        self.main_tabs.addTab(self._build_ferramentas_page(), "Ferramentas")
        self.tab_titles.append(self.TAB_TITLES["ferramentas"])

    def _build_inicio_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import AppDashboardWidget

        self.dashboard_page = AppDashboardWidget(
            db=self.db,
            browser_widget=getattr(self, "browser_widget", None),
            open_page=self.open_page_by_name,
            open_tool=self.show_tools_tab,
        )
        lay.addWidget(self.dashboard_page)
        return page

    def _build_gerador_page(self):
        from app.ui.generator_page import build_generator_page

        return build_generator_page(self)

    def _build_ferramentas_page(self):
        return super()._build_ferramentas_page()


    def _build_ai_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from ai_assistant_widget import AIAssistantWidget

        self.ai_assistant_tab = AIAssistantWidget()
        lay.addWidget(self.ai_assistant_tab)
        return page


    def _build_notas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from notepad_widget import NotepadWidget

        self.notepad_tab = NotepadWidget()
        lay.addWidget(self.notepad_tab)
        return page

    def _build_config_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import GeneralSettingsWidget

        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        self.general_settings_tab = GeneralSettingsWidget(manager)
        lay.addWidget(self.general_settings_tab)
        return page
