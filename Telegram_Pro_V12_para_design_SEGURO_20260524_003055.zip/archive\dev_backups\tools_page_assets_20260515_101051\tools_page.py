#!/usr/bin/env python3
"""Builder da pagina Ferramentas."""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QFrame, QHBoxLayout, QLabel, QTabWidget, QVBoxLayout, QWidget

from app.ui.components import card_qss, label_qss


class ToolsPageMixin:
    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(14, 12, 14, 12)
        lay.setSpacing(12)

        self._tool_descriptions = []
        lay.addWidget(self._build_tools_header())

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setDocumentMode(True)
        self.tools_tabs.setStyleSheet(self._tools_tab_qss())

        from app.features.tools.dialog import ToolsDialog
        from data_organizer import DataOrganizer
        from data_pro_widget import DataProWidget
        from extra_tools import GeradorFakeWidget, ValidadorWidget
        from performance_widget import PerformanceWidget
        from text_corrector_widget import TextCorrectorWidget

        tools_helper = ToolsDialog(self)
        tools = [
            ("Cartoes", "Gere listas no formato numero, mes, ano e CVV.", tools_helper.create_card_generator_tab()),
            ("CEP", "Gere enderecos e copie campos separados com rapidez.", tools_helper.create_cep_generator_tab()),
            ("Organizador", "Organize contas em modelos prontos para uso.", tools_helper.create_account_formatter_tab()),
            ("Formatar", "Formate e limpe listas de dados em massa.", DataOrganizer()),
            ("CPF/CNPJ", "Valide e confira documentos brasileiros.", ValidadorWidget()),
            ("Fake", "Gere dados de teste para formularios e verificacoes.", GeradorFakeWidget()),
            ("Desempenho", "Monitore hardware e rode acoes seguras de sistema.", PerformanceWidget()),
            ("Dados Pro", "Analise qualidade, higiene e enriquecimento de registros.", DataProWidget(self.db)),
            ("Portugues", "Corrija, reescreva e traduza textos com modos de portugues.", TextCorrectorWidget()),
        ]

        self.data_pro_tab = tools[7][2]
        for name, description, widget in tools:
            self.tools_tabs.addTab(widget, name)
            self._tool_descriptions.append(description)

        self.tools_tabs.currentChanged.connect(self._update_tools_header)
        lay.addWidget(self.tools_tabs, 1)
        self._update_tools_header(0)
        return page

    def _build_tools_header(self):
        frame = QFrame()
        frame.setStyleSheet(card_qss("default", radius=10))
        layout = QHBoxLayout(frame)
        layout.setContentsMargins(14, 12, 14, 12)
        layout.setSpacing(12)

        title_box = QVBoxLayout()
        title_box.setSpacing(3)
        title = QLabel("Ferramentas")
        title.setStyleSheet(label_qss("title"))
        self.tools_context_label = QLabel("Escolha uma ferramenta para trabalhar com dados, texto, perfis e sistema.")
        self.tools_context_label.setWordWrap(True)
        self.tools_context_label.setStyleSheet(label_qss("subtitle"))
        title_box.addWidget(title)
        title_box.addWidget(self.tools_context_label)
        layout.addLayout(title_box, 1)

        self.tools_counter_label = QLabel("0 ferramentas")
        self.tools_counter_label.setAlignment(Qt.AlignCenter)
        self.tools_counter_label.setMinimumWidth(120)
        self.tools_counter_label.setStyleSheet(
            "QLabel{background:#08111f;color:#67e8f9;border:1px solid rgba(34,211,238,0.16);"
            "border-radius:10px;padding:10px;font-weight:900;}"
        )
        layout.addWidget(self.tools_counter_label)
        return frame

    def _update_tools_header(self, index):
        count = self.tools_tabs.count() if hasattr(self, "tools_tabs") else 0
        self.tools_counter_label.setText(f"{count} ferramentas")
        if 0 <= index < len(getattr(self, "_tool_descriptions", [])):
            name = self.tools_tabs.tabText(index)
            self.tools_context_label.setText(f"{name}: {self._tool_descriptions[index]}")

    def _tools_tab_qss(self):
        return """
            QTabWidget::pane {
                border: 1px solid rgba(34,211,238,0.10);
                border-radius: 12px;
                background: #05070d;
                margin-top: 8px;
            }
            QTabBar {
                background: #07080f;
            }
            QTabBar::tab {
                background: #101827;
                color: #94a3b8;
                min-height: 38px;
                min-width: 108px;
                padding: 8px 16px;
                margin-right: 6px;
                border: 1px solid rgba(148,163,184,0.12);
                border-top-left-radius: 10px;
                border-top-right-radius: 10px;
                font-size: 12px;
                font-weight: 800;
            }
            QTabBar::tab:selected {
                color: #67e8f9;
                background: #0b2c3a;
                border-color: rgba(34,211,238,0.42);
            }
            QTabBar::tab:hover:!selected {
                color: #e2e8f0;
                background: #111c2f;
            }
            QTabBar::scroller { width: 34px; }
            QTabBar QToolButton {
                background: #101827;
                border: 1px solid rgba(34,211,238,0.24);
                color: #67e8f9;
                border-radius: 8px;
                min-width: 28px;
                min-height: 28px;
            }
            QTabBar QToolButton:hover { background: rgba(34,211,238,0.16); }
        """
