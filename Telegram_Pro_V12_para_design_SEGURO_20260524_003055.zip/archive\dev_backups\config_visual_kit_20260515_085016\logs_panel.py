#!/usr/bin/env python3
"""Central de logs bonitos do hub do app."""
from __future__ import annotations

import json

from PyQt5.QtWidgets import QApplication, QHBoxLayout, QLabel, QListWidget, QMessageBox, QPushButton, QVBoxLayout, QWidget

from app.core.paths import CONFIG_DIR


def read_recent_logs(limit=30, only_errors=False):
    log_file = CONFIG_DIR / "browser_logs.jsonl"
    if not log_file.exists():
        return []
    lines = []
    try:
        raw = log_file.read_text(encoding="utf-8", errors="ignore").splitlines()[-200:]
        for line in reversed(raw):
            try:
                event = json.loads(line)
                msg = event.get("message") or event.get("details") or str(event)
                typ = event.get("event") or event.get("type") or "log"
                if only_errors and "erro" not in msg.lower() and "error" not in typ.lower() and "failed" not in msg.lower():
                    continue
                lines.append(f"{typ}: {friendly_error_text(msg)}")
                if len(lines) >= limit:
                    break
            except Exception:
                if not only_errors:
                    lines.append(line[:180])
    except Exception:
        return []
    return lines


def friendly_error_text(message):
    text = str(message)
    low = text.lower()
    if "403" in low or "forbidden" in low:
        return "Bloqueio 403: tente limpar o perfil, trocar proxy/rede, usar modo Streaming ou abrir em outro navegador."
    if "chrome nao encontrado" in low or "chrome não encontrado" in low:
        return "Chrome nao encontrado: instale Chrome/Edge/Firefox ou use o reparo do launcher."
    if "webdriver" in low or "selenium" in low:
        return "Erro do navegador automatizado: tente modo nativo ou reparar dependencias."
    return text[:220]


class PrettyLogsWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()
        self.refresh()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        top = QHBoxLayout()
        title = QLabel("Central de Logs")
        title.setStyleSheet("color:#e2e8f0;font-size:16px;font-weight:900;background:transparent;border:none;")
        top.addWidget(title)
        top.addStretch()
        refresh_btn = QPushButton("Atualizar")
        refresh_btn.clicked.connect(self.refresh)
        top.addWidget(refresh_btn)
        copy_btn = QPushButton("Copiar selecionado")
        copy_btn.clicked.connect(self.copy_selected)
        top.addWidget(copy_btn)
        fix_btn = QPushButton("Corrigir provavel")
        fix_btn.clicked.connect(self.show_fix_hint)
        top.addWidget(fix_btn)
        lay.addLayout(top)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)

    def refresh(self):
        self.list.clear()
        for line in read_recent_logs(limit=80, only_errors=False):
            self.list.addItem(line)

    def copy_selected(self):
        item = self.list.currentItem()
        if item:
            QApplication.clipboard().setText(item.text())

    def show_fix_hint(self):
        item = self.list.currentItem()
        text = item.text() if item else ""
        QMessageBox.information(self, "Correcao provavel", friendly_error_text(text) or "Selecione um log para ver a sugestao.")


