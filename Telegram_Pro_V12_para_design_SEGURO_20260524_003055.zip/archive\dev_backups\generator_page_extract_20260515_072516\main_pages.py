#!/usr/bin/env python3
"""Builders de paginas da janela principal.

Este mixin mantem a construcao visual fora do main_app.py sem mudar o fluxo do SimpleApp.
"""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QCheckBox, QFrame, QGridLayout, QHBoxLayout, QLabel, QProgressBar,
    QPushButton, QScrollArea, QSizePolicy, QSpinBox, QSplitter, QTabWidget,
    QVBoxLayout, QWidget,
)

from importlib.util import find_spec

from app.ui.components import PALETTE, button_qss, card_qss, label_qss
from app.ui.shell_widgets import TAB_TOP_QSS
from settings import BASE_DIR

PROFILE_DEFAULTS_AVAILABLE = find_spec("profile_defaults_widget") is not None
CRUNCHYROLL_AVAILABLE = find_spec("crunchyroll_widget") is not None
CRUNCHYROLL_LOGIN_AVAILABLE = find_spec("crunchyroll_login_widget") is not None


class MainPagesMixin:
    def _build_pages(self):
        self.main_tabs.addTab(self._build_inicio_page(), "Início")
        self.main_tabs.addTab(self._build_gerador_page(), "Gerador")
        self.main_tabs.addTab(self._build_navegador_page(), "Navegador")
        self.main_tabs.addTab(self._build_ai_page(), "IA Local")
        if CRUNCHYROLL_AVAILABLE:
            self.main_tabs.addTab(self._build_crunchyroll_page(), "Crunchyroll")
        self.main_tabs.addTab(self._build_notas_page(), "Notas")
        self.main_tabs.addTab(self._build_config_page(), "Config")
        self.main_tabs.addTab(self._build_ferramentas_page(), "Ferramentas")
        self.tab_titles.append(self.TAB_TITLES["ferramentas"])

    def _build_inicio_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import AppDashboardWidget

        self.dashboard_page = AppDashboardWidget(
            db=self.db,
            browser_widget=getattr(self, "browser_widget", None),
            open_page=self.open_page_by_name,
            open_tool=self.show_tools_tab,
        )
        lay.addWidget(self.dashboard_page)
        return page

    def _build_gerador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")

        root_lay = QVBoxLayout(page)
        root_lay.setContentsMargins(10, 8, 10, 8)
        root_lay.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background: transparent;
                width: 6px;
            }
            QSplitter::handle:hover {
                background: rgba(6,182,212,0.25);
                border-radius: 3px;
            }
            QSplitter::handle:pressed {
                background: rgba(6,182,212,0.45);
            }
        """)
        splitter.setChildrenCollapsible(False)

        # === PAINEL ESQUERDO (scroll) ===
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:#07080f;width:5px;border-radius:2px;}"
            "QScrollBar::handle:vertical{background:#1a2540;border-radius:2px;min-height:20px;}"
            "QScrollBar::handle:vertical:hover{background:#06b6d4;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
        )

        left_widget = QWidget()
        left_widget.setStyleSheet("background:transparent;")
        left_lay = QVBoxLayout(left_widget)
        left_lay.setContentsMargins(0, 0, 6, 0)
        left_lay.setSpacing(6)

        sp_qss = ("QSpinBox{background:#0d1525;border:1px solid rgba(6,182,212,0.2);"
                  "border-radius:6px;color:#e2e8f0;padding:3px 6px;font-size:12px;min-width:52px;}"
                  "QSpinBox::up-button,QSpinBox::down-button{width:14px;border:none;background:transparent;}")
        cb_qss = ("QCheckBox{color:#94a3b8;font-size:12px;spacing:5px;}"
                  "QCheckBox::indicator{width:13px;height:13px;"
                  "border:1px solid rgba(6,182,212,0.3);border-radius:3px;background:#0d1525;}"
                  "QCheckBox::indicator:checked{background:#06b6d4;border-color:#06b6d4;}")
        sec_btn_qss = button_qss("secondary", "sm")

        def sec_lbl(txt):
            l = QLabel(txt)
            l.setStyleSheet(label_qss("section") + " letter-spacing:1px; padding:2px 0 0 0;")
            return l

        def card(build_fn):
            f = QFrame()
            f.setStyleSheet(card_qss("default", radius=8))
            f.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            lay = QVBoxLayout(f)
            lay.setContentsMargins(12, 10, 12, 10)
            lay.setSpacing(7)
            build_fn(lay)
            return f

        # CARD FILTROS
        def build_filters(lay):
            lay.addWidget(sec_lbl("FILTROS"))
            row = QHBoxLayout(); row.setSpacing(8)
            self.filtro_checkbox = QCheckBox("Idade")
            self.filtro_checkbox.setStyleSheet(cb_qss)
            self.filtro_checkbox.stateChanged.connect(self.toggle_filtro)
            self.idade_min_spin = QSpinBox()
            self.idade_min_spin.setRange(0,120); self.idade_min_spin.setValue(18)
            self.idade_min_spin.setEnabled(False); self.idade_min_spin.setStyleSheet(sp_qss)
            self.idade_max_spin = QSpinBox()
            self.idade_max_spin.setRange(0,120); self.idade_max_spin.setValue(65)
            self.idade_max_spin.setEnabled(False); self.idade_max_spin.setStyleSheet(sp_qss)
            s1 = QLabel("–"); s1.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_checkbox)
            row.addWidget(self.idade_min_spin)
            row.addWidget(s1)
            row.addWidget(self.idade_max_spin)
            row.addSpacing(12)
            self.filtro_score_checkbox = QCheckBox("Score")
            self.filtro_score_checkbox.setStyleSheet(cb_qss)
            self.filtro_score_checkbox.stateChanged.connect(self.toggle_filtro_score)
            self.score_min_spin = QSpinBox()
            self.score_min_spin.setRange(0,1000); self.score_min_spin.setValue(500)
            self.score_min_spin.setEnabled(False); self.score_min_spin.setStyleSheet(sp_qss)
            self.score_max_spin = QSpinBox()
            self.score_max_spin.setRange(0,1000); self.score_max_spin.setValue(1000)
            self.score_max_spin.setEnabled(False); self.score_max_spin.setStyleSheet(sp_qss)
            s2 = QLabel("–"); s2.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_score_checkbox)
            row.addWidget(self.score_min_spin)
            row.addWidget(s2)
            row.addWidget(self.score_max_spin)
            row.addStretch()
            lay.addLayout(row)
            disp = QHBoxLayout(); disp.setSpacing(10)
            lbl_e = QLabel("Exibir:"); lbl_e.setStyleSheet(label_qss("muted") + f" color:{PALETTE.faint}; font-size:11px;")
            disp.addWidget(lbl_e)
            for field, txt in [("nome","Nome"),("cpf","CPF"),("idade","Idade"),
                               ("data","Nasc."),("telefone","Tel."),("score","Score")]:
                cb = QCheckBox(txt); cb.setChecked(True); cb.setStyleSheet(cb_qss)
                cb.stateChanged.connect(lambda _, f=field: self.toggle_display(f))
                setattr(self, f"check_{field}", cb)
                disp.addWidget(cb)
            disp.addStretch()
            lay.addLayout(disp)
        left_lay.addWidget(card(build_filters))

        # CARD ACOES
        def build_acoes(lay):
            lay.addWidget(sec_lbl("AÇÕES"))
            mrow = QHBoxLayout(); mrow.setSpacing(8)
            self.generate_btn = QPushButton("🎲  GERAR PAR")
            self.generate_btn.setCursor(Qt.PointingHandCursor)
            self.generate_btn.setFixedHeight(40)
            self.generate_btn.setStyleSheet(button_qss("success", "lg"))
            self.generate_btn.clicked.connect(self.generate_pair)
            cbtn = QPushButton("📋  COPIAR")
            cbtn.setCursor(Qt.PointingHandCursor)
            cbtn.setFixedHeight(40)
            cbtn.setStyleSheet(button_qss("primary", "lg"))
            cbtn.clicked.connect(self.copy_result)
            mrow.addWidget(self.generate_btn, 3)
            mrow.addWidget(cbtn, 2)
            lay.addLayout(mrow)
            grid = QGridLayout(); grid.setSpacing(5)
            for i, (txt, fn) in enumerate([
                ("📥 Coletar", self.start_collection), ("📊 Ver Dados", self.show_data),
                ("💾 Exportar", self.export_data), ("📋 Grupos", self.show_groups_dialog),
                ("⚙️ Config.", self.show_config_dialog), ("📱 Contas", self.show_contas_dialog),
            ]):
                b = QPushButton(txt); b.setFixedHeight(28); b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(sec_btn_qss); b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.clicked.connect(fn)
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_acoes))

        # CARD RAPIDO
        def build_rapido(lay):
            lay.addWidget(sec_lbl("ACESSO RÁPIDO"))
            grid = QGridLayout(); grid.setSpacing(5)
            items = [("💳 Cartões",0,"#10b981"),("🏠 CEP",1,"#06b6d4"),
                     ("✅ CPF/CNPJ",4,"#8b5cf6"),("🎭 Fake",5,"#f59e0b"),
                     ("📧 Organizador",2,"#0ea5e9"),("⚡ Desempenho",6,"#fbbf24")]
            for i, (txt, ti, color) in enumerate(items):
                b = QPushButton(txt); b.setFixedHeight(27); b.setCursor(Qt.PointingHandCursor)
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.setStyleSheet(f"QPushButton{{background:rgba(6,182,212,0.05);color:{color};"
                               f"border:1px solid {color}28;border-radius:6px;font-size:11px;font-weight:600;}}"
                               f"QPushButton:hover{{background:{color}18;border-color:{color}55;}}")
                b.clicked.connect(lambda _, i=ti: self.show_tools_tab(i))
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_rapido))

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setStyleSheet("QProgressBar{background:#0d1525;border:none;border-radius:1px;}"
                                        "QProgressBar::chunk{background:#06b6d4;border-radius:1px;}")
        self.progress_bar.setTextVisible(False)
        left_lay.addWidget(self.progress_bar)

        self.stats_label = QLabel("—")
        self.stats_label.setAlignment(Qt.AlignCenter)
        self.stats_label.setStyleSheet(label_qss("muted") + f" color:{PALETTE.faint}; font-size:10px;")
        self.stats_label.setWordWrap(True)
        left_lay.addWidget(self.stats_label)
        left_lay.addStretch(1)

        left_scroll.setWidget(left_widget)
        splitter.addWidget(left_scroll)

        # === PAINEL DIREITO — RESULTADO ===
        right_widget = QWidget()
        right_widget.setStyleSheet("background:transparent;")
        right_lay = QVBoxLayout(right_widget)
        right_lay.setContentsMargins(6, 0, 0, 0)
        right_lay.setSpacing(6)
        right_lay.addWidget(sec_lbl("RESULTADO"))

        rc = QFrame()
        rc.setStyleSheet(card_qss("default", radius=8))
        rc.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rc_lay = QVBoxLayout(rc)
        rc_lay.setContentsMargins(12, 10, 12, 10)
        rc_lay.setSpacing(7)

        field_qss = ("QLabel{color:#22d3ee;font-family:'Consolas','Cascadia Code',monospace;"
                     "font-size:13px;font-weight:500;background:#07080f;"
                     "border:1px solid rgba(6,182,212,0.09);border-radius:7px;"
                     "padding:8px 12px;}")
        cp_qss = ("QPushButton{background:rgba(6,182,212,0.07);border:1px solid rgba(6,182,212,0.15);"
                  "border-radius:6px;font-size:12px;color:#06b6d4;"
                  "min-width:28px;max-width:28px;min-height:28px;max-height:28px;}"
                  "QPushButton:hover{background:rgba(6,182,212,0.22);}")

        for icon, attr, label_txt in [
            ("👤","nome","Nome"), ("🆔","cpf","CPF"), ("🎂","idade","Idade"),
            ("📅","nasc","Nascimento"), ("📞","telefone","Telefone"), ("⭐","score","Score"),
        ]:
            row = QHBoxLayout(); row.setSpacing(8)
            lbl = QLabel(f"{icon}   {label_txt}: —")
            lbl.setStyleSheet(field_qss)
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            cp = QPushButton("⎘")
            cp.setStyleSheet(cp_qss); cp.setCursor(Qt.PointingHandCursor)
            cp.setToolTip(f"Copiar {label_txt}")
            cp.clicked.connect(lambda _, a=attr: self.copy_field(a))
            row.addWidget(lbl, 1); row.addWidget(cp)
            rc_lay.addLayout(row)
            setattr(self, f"{attr}_label", lbl)
        rc_lay.addStretch(1)

        right_lay.addWidget(rc, 1)
        splitter.addWidget(right_widget)

        splitter.setSizes([420, 580])
        splitter.setStretchFactor(0, 42)
        splitter.setStretchFactor(1, 58)
        root_lay.addWidget(splitter, 1)

        self.nome_label.setText("👤   Nome: —")
        self.cpf_label.setText("🆔   CPF: —")
        self.idade_label.setText("🎂   Idade: —")
        self.nasc_label.setText("📅   Nascimento: —")
        self.telefone_label.setText("📞   Telefone: —")
        self.score_label.setText("⭐   Score: —")

        return page

    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 0;
            }
            QTabBar {
                background: #07080f;
                border-bottom: 1px solid rgba(6,182,212,0.08);
            }
            QTabBar::tab {
                background: transparent;
                color: #475569;
                padding: 7px 11px;
                margin-right: 1px;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                background: rgba(6,182,212,0.06);
                border-bottom: 2px solid #06b6d4;
                font-weight: 700;
            }
            QTabBar::tab:hover:!selected {
                color: #94a3b8;
                background: rgba(255,255,255,0.03);
            }
            QTabBar::scroller { width: 22px; }
            QTabBar QToolButton {
                background: #0d1525;
                border: 1px solid rgba(6,182,212,0.2);
                color: #06b6d4;
                border-radius: 4px;
                font-size: 12px;
            }
            QTabBar QToolButton:hover { background: rgba(6,182,212,0.18); }
        """)

        from app.features.tools.dialog import ToolsDialog
        from data_organizer import DataOrganizer
        from data_pro_widget import DataProWidget
        from extra_tools import GeradorFakeWidget, ValidadorWidget
        from performance_widget import PerformanceWidget
        from text_corrector_widget import TextCorrectorWidget

        tools_helper = ToolsDialog(self)
        self.tools_tabs.addTab(tools_helper.create_card_generator_tab(), "💳 Cartões")
        self.tools_tabs.addTab(tools_helper.create_cep_generator_tab(), "🏠 CEP")
        self.tools_tabs.addTab(tools_helper.create_account_formatter_tab(), "📧 Organizador")
        self.tools_tabs.addTab(DataOrganizer(), "🗂️ Formatar")
        self.tools_tabs.addTab(ValidadorWidget(), "✅ CPF/CNPJ")
        self.tools_tabs.addTab(GeradorFakeWidget(), "🎭 Fake")
        self.tools_tabs.addTab(PerformanceWidget(), "⚡ Desempenho")
        self.data_pro_tab = DataProWidget(self.db)
        self.tools_tabs.addTab(self.data_pro_tab, "🧹 Dados Pro")
        self.tools_tabs.addTab(TextCorrectorWidget(), "✍️ Português")

        lay.addWidget(self.tools_tabs)
        return page

    def _build_navegador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)

        self.browser_tabs = QTabWidget()
        self.browser_tabs.setStyleSheet(TAB_TOP_QSS)
        from browser_widget import BrowserWidget

        self.browser_widget = BrowserWidget()
        if hasattr(self, "dashboard_page"):
            self.dashboard_page.browser_widget = self.browser_widget
            self.dashboard_page.browser_manager = self.browser_widget.browser_manager
        self.browser_tabs.addTab(self.browser_widget, "🌐 Navegador")
        if PROFILE_DEFAULTS_AVAILABLE:
            from profile_defaults_widget import ProfileDefaultsWidget

            config_dir = str(BASE_DIR / "browser_config")
            self.profile_defaults_tab = ProfileDefaultsWidget(config_dir)
            self.browser_tabs.addTab(self.profile_defaults_tab, "⚙️ Configurações")
        lay.addWidget(self.browser_tabs)
        return page

    def _build_ai_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from ai_assistant_widget import AIAssistantWidget

        self.ai_assistant_tab = AIAssistantWidget()
        lay.addWidget(self.ai_assistant_tab)
        return page

    def _build_crunchyroll_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(8)

        quick = QFrame()
        quick.setStyleSheet(
            "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.12);border-radius:8px;}"
        )
        quick_lay = QHBoxLayout(quick)
        quick_lay.setContentsMargins(10, 8, 10, 8)
        quick_lay.setSpacing(8)
        title = QLabel("Crunchyroll")
        title.setStyleSheet("color:#e2e8f0;font-weight:900;font-size:14px;background:transparent;border:none;")
        quick_lay.addWidget(title)
        quick_lay.addStretch()

        back_btn = QPushButton("← Voltar")
        back_btn.setFixedHeight(32)
        back_btn.setToolTip("Voltar para o início do Crunchyroll")
        back_btn.clicked.connect(self._crunchyroll_back)
        quick_lay.addWidget(back_btn)

        for text, tab_name in [
            ("Contas", "Contas"),
            ("Cartões", "Cartões"),
            ("Resultados", "Resultados"),
            ("Verificador", "Verificador"),
        ]:
            btn = QPushButton(text)
            btn.setFixedHeight(32)
            btn.clicked.connect(lambda _, name=tab_name: self._open_crunchyroll_bot_tab(name))
            quick_lay.addWidget(btn)

        if CRUNCHYROLL_LOGIN_AVAILABLE:
            login_btn = QPushButton("Login/Auth")
            login_btn.setFixedHeight(32)
            login_btn.clicked.connect(self._open_crunchyroll_login_tab)
            quick_lay.addWidget(login_btn)

        refresh_btn = QPushButton("Atualizar resultados")
        refresh_btn.setFixedHeight(32)
        refresh_btn.clicked.connect(self._refresh_crunchyroll_results)
        quick_lay.addWidget(refresh_btn)
        lay.addWidget(quick)

        self.crunchy_tabs = QTabWidget()
        self.crunchy_tabs.setStyleSheet(TAB_TOP_QSS)
        from crunchyroll_widget import CrunchyrollWidget

        self.crunchyroll_tab = CrunchyrollWidget()
        self.crunchy_tabs.addTab(self.crunchyroll_tab, "🍦 Bot Principal")
        if CRUNCHYROLL_LOGIN_AVAILABLE:
            from crunchyroll_login_widget import CrunchyrollLoginWidget

            self.crunchyroll_login_tab = CrunchyrollLoginWidget()
            self.crunchy_tabs.addTab(self.crunchyroll_login_tab, "🔐 Login/Auth")
        lay.addWidget(self.crunchy_tabs)
        return page

    def _open_crunchyroll_bot_tab(self, tab_name):
        if hasattr(self, "crunchy_tabs"):
            self.crunchy_tabs.setCurrentIndex(0)
        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if not inner_tabs:
            return
        target = tab_name.lower()
        for i in range(inner_tabs.count()):
            if target in inner_tabs.tabText(i).lower():
                inner_tabs.setCurrentIndex(i)
                break

    def _crunchyroll_back(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.currentIndex() != 0:
            self.crunchy_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Bot Principal", 2000)
            return

        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if inner_tabs and inner_tabs.currentIndex() != 0:
            inner_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Controle do Crunchyroll", 2000)
            return

        self.status_bar.showMessage("ℹ️ Você já está no início do Crunchyroll", 2000)

    def _open_crunchyroll_login_tab(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.count() > 1:
            self.crunchy_tabs.setCurrentIndex(1)

    def _refresh_crunchyroll_results(self):
        refreshed = False
        for widget_name in ("crunchyroll_tab", "crunchyroll_login_tab"):
            widget = getattr(self, widget_name, None)
            if widget and hasattr(widget, "load_results"):
                widget.load_results()
                refreshed = True
        if refreshed:
            self.status_bar.showMessage("✅ Resultados do Crunchyroll atualizados", 2500)

    def _build_notas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from notepad_widget import NotepadWidget

        self.notepad_tab = NotepadWidget()
        lay.addWidget(self.notepad_tab)
        return page

    def _build_config_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import GeneralSettingsWidget

        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        self.general_settings_tab = GeneralSettingsWidget(manager)
        lay.addWidget(self.general_settings_tab)
        return page
