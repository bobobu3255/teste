#!/usr/bin/env python3
"""Compatibilidade para o hub geral do app."""
from app.features.app_hub.widget import *  # noqa: F401,F403
