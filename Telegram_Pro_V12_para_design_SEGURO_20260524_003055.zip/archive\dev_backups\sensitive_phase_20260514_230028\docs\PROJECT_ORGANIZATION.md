﻿# Organizacao Segura Da V11

Este documento marca a base de organizacao do Telegram Pro V11 sem mudar o comportamento atual do app.

## O Que Foi Feito Agora

- `app/core/paths.py` centraliza caminhos importantes do projeto.
- `app/core/config_manager.py` guarda a configuracao de contas e grupos Telegram.
- `app/core/exceptions.py` guarda a hierarquia de excecoes customizadas.
- `app/core/logger_manager.py` guarda o logger legado centralizado.
- `app/core/workers.py` guarda workers Qt reutilizaveis.
- `app/ui/app_theme.py` guarda o tema principal da interface.
- `app/features/registry.py` documenta as ferramentas ativas sem importar a interface real.
- `app/features/extra_tools/` guarda CPF/CNPJ, Fake, Busca e Dashboard antigos.
- `app/features/data_pro/` guarda a ferramenta Dados Pro.
- `app/features/text_corrector/` guarda a ferramenta Portugues.
- `app/features/profile_defaults/` guarda favoritos, extensoes e senhas padrao dos perfis.
- `app/features/app_hub/` guarda painel inicial, busca global, logs e configuracoes gerais.
- `app/features/performance/` guarda a ferramenta Desempenho Pro.
- `app/features/data_organizer/` guarda a ferramenta de organizar/formatar dados.
- `app/features/account_manager/` guarda o gerenciador de contas e grupos Telegram.
- `app/services/account_formatter.py` guarda a logica de formatacao de contas.
- `app/services/address_generator.py` guarda a logica atual de geracao de enderecos.
- `app/services/address_reserve.py` guarda o banco local reserva de enderecos.
- `app/services/cloud_service.py` guarda a integracao opcional com cPanel/cloud.
- `app/services/profile_defaults_manager.py` guarda favoritos, extensoes e senhas padrao.
- `app/services/proxy_manager.py` guarda geracao e parse de proxies do navegador.
- `generators/` guarda geradores reutilizaveis como cartoes e fingerprint.
- `scripts/maintenance/health_check.py` verifica se os arquivos Python compilam e pode abrir a `SimpleApp` em modo de teste.
- `archive/dev_backups/` guarda snapshots antigos que antes ficavam soltos na raiz.

## Arquivos Ponte

Alguns arquivos continuam na raiz apenas para compatibilidade com imports antigos:

- `extra_tools.py`
- `data_pro_widget.py`
- `text_corrector_widget.py`
- `profile_defaults_widget.py`
- `app_hub.py`
- `performance_widget.py`
- `data_organizer.py`
- `account_manager.py`
- `config_manager.py`
- `exceptions.py`
- `logger_manager.py`
- `workers.py`
- `theme.py`
- `account_formatter.py`
- `address_generator.py`
- `address_reserve.py`
- `cloud_service.py`
- `profile_defaults_manager.py`
- `proxy_manager.py`
- `card_generator.py`
- `fingerprint_generator.py`

Eles importam as classes reais dos pacotes em `app/features/`.

## Arquivos Que Continuam Na Raiz Por Seguranca

Estes arquivos ainda sao os pontos principais do app e nao devem ser movidos de uma vez:

- `main_app.py`
- `browser_widget.py`
- `browser_manager.py`
- `notepad_widget.py`
- `crunchyroll_widget.py`
- `crunchyroll_login_widget.py`
- `ai_assistant_widget.py`

Tambem nao mover agora:

- `browser_profiles/`
- `browser_config/`
- `IA_Saidas/`
- `dados.db`
- `notepad_session.json`
- `notepad_snippets.json`
- pastas de bots e dados reais

## Plano Profissional De Organizacao

1. Manter a V11 funcionando exatamente como esta.
2. Centralizar caminhos, logs e configuracoes compartilhadas em `app/core`.
3. Criar registros leves em `app/features` antes de mover qualquer ferramenta.
4. Extrair uma ferramenta por vez para pacotes menores, sempre testando depois.
5. Criar componentes visuais reutilizaveis para botoes, cards, abas e formularios.
6. So depois disso reduzir o tamanho do `main_app.py`.

## Regra De Ouro

Nada de mover modulo grande sem teste. Primeiro documenta, cria ponte segura, testa, e so depois migra uma parte pequena.



