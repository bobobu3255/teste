"""Dashboard, busca global, logs e configuracoes gerais."""
from .widget import (  # noqa: F401
    AppDashboardWidget,
    BackupWorker,
    GeneralSettingsWidget,
    GlobalSearchDialog,
    PrettyLogsWidget,
    load_app_settings,
    maybe_run_daily_backup,
    read_recent_logs,
    save_app_settings,
)
