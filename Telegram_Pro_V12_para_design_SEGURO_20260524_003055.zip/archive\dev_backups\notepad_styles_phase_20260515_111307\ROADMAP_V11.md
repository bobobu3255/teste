# Roadmap Seguro Da V11

Este plano existe para melhorar a V11 sem repetir o erro de reescrever tudo de uma vez.

## Estado Atual

- Base principal reorganizada em `app/core`, `app/ui`, `app/features` e `app/services`.
- Pontes antigas mantidas para nao quebrar imports existentes.
- Checks de manutencao criados para testar estrutura, UI, ferramentas, imports e dividas visuais.
- Kit visual compartilhado iniciado em `app/ui/components.py`.
- Ferramentas internas come?aram a receber estilos centralizados em `app/features/tools/styles.py`.
- Desempenho Pro comecou a migrar estilos para `app/features/performance/styles.py`.

## Fases Restantes Estimadas

1. Polimento visual por ferramenta: corrigir botoes, cards, espacamentos e telas poluidas uma por vez.
2. Otimizacao de travamentos: remover operacoes pesadas do thread principal e melhorar exclusao/refresh de listas.
3. Inteligencia local: fortalecer IA, criacao de arquivos, leitura de anexos e acoes assistidas com seguranca.
4. Navegador Seguro: limpar interface, melhorar preenchimento automatico, detector de erro e perfis arquivados.
5. Ferramentas especificas: Cartoes, CEP, Desempenho, Notas e Crunchyroll com passagens focadas.
6. Empacotamento e launcher: abrir sem CMD, reparar dependencias e preparar uso em pendrive/PC novo.
7. QA final: bateria completa, revisao visual, backup e documentacao simples para uso.

## Criterio De Qualidade

Cada fase deve ter backup, mudanca pequena, teste rapido e, quando possivel, `verify_all.py` completo.
