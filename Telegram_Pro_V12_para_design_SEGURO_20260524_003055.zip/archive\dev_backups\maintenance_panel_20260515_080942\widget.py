"""
Hub geral do app: dashboard, busca global, logs bonitos, configuracoes e backup.
"""
import json
import os
import shutil
import subprocess
import zipfile
from datetime import datetime
from pathlib import Path

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDialog, QFileDialog, QFrame,
    QGridLayout, QHBoxLayout, QLabel, QLineEdit, QListWidget, QListWidgetItem,
    QMessageBox, QPushButton, QScrollArea, QSpinBox, QTextEdit, QVBoxLayout,
    QWidget,
)

from browser_manager import BrowserManager
from app.core.paths import BASE_DIR, CONFIG_DIR


SETTINGS_FILE = CONFIG_DIR / "app_general_settings.json"
LAST_BACKUP_FILE = CONFIG_DIR / "last_auto_backup.txt"


class BackupWorker(QThread):
    finished_backup = pyqtSignal(bool, str)

    def run(self):
        try:
            manager = BrowserManager()
            path = manager.create_browser_backup()
            if path:
                self.finished_backup.emit(True, str(path))
            else:
                self.finished_backup.emit(False, "Nao foi possivel criar o backup.")
        except Exception as exc:
            self.finished_backup.emit(False, str(exc))


def _load_json(path, default):
    try:
        if Path(path).exists():
            with open(path, "r", encoding="utf-8") as f:
                return json.load(f)
    except Exception:
        pass
    return default


def _save_json(path, data):
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)


def load_app_settings():
    data = _load_json(SETTINGS_FILE, {})
    defaults = {
        "theme": "Escuro profissional",
        "ui_scale": 100,
        "compact_mode": False,
        "data_folder": str(BASE_DIR),
        "auto_backup": True,
        "workspace": "Padrao",
    }
    defaults.update(data if isinstance(data, dict) else {})
    return defaults


def save_app_settings(data):
    _save_json(SETTINGS_FILE, data)


def maybe_run_daily_backup(browser_manager=None):
    settings = load_app_settings()
    if not settings.get("auto_backup", True):
        return None
    today = datetime.now().strftime("%Y-%m-%d")
    if LAST_BACKUP_FILE.exists() and LAST_BACKUP_FILE.read_text(encoding="utf-8").strip() == today:
        return None
    manager = browser_manager or BrowserManager()
    backup_path = manager.create_browser_backup()
    LAST_BACKUP_FILE.parent.mkdir(parents=True, exist_ok=True)
    LAST_BACKUP_FILE.write_text(today, encoding="utf-8")
    return backup_path


def _card(title, value, subtitle="", color="#22d3ee"):
    frame = QFrame()
    frame.setStyleSheet(
        "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.12);"
        "border-radius:8px;}"
    )
    lay = QVBoxLayout(frame)
    lay.setContentsMargins(12, 10, 12, 10)
    lay.setSpacing(4)
    t = QLabel(title)
    t.setStyleSheet("color:#94a3b8;font-size:11px;font-weight:700;background:transparent;border:none;")
    v = QLabel(str(value))
    v.setStyleSheet(f"color:{color};font-size:22px;font-weight:900;background:transparent;border:none;")
    s = QLabel(subtitle)
    s.setWordWrap(True)
    s.setStyleSheet("color:#64748b;font-size:10px;background:transparent;border:none;")
    lay.addWidget(t)
    lay.addWidget(v)
    lay.addWidget(s)
    return frame


class AppDashboardWidget(QWidget):
    """Dashboard inicial real, com numeros e atalhos."""

    def __init__(self, db=None, browser_widget=None, open_page=None, open_tool=None, parent=None):
        super().__init__(parent)
        self.db = db
        self.browser_widget = browser_widget
        self.open_page = open_page
        self.open_tool = open_tool
        self.browser_manager = getattr(browser_widget, "browser_manager", None) or BrowserManager()
        self._build()
        self.refresh()

    def _build(self):
        root = QVBoxLayout(self)
        root.setContentsMargins(14, 12, 14, 12)
        root.setSpacing(10)

        top = QHBoxLayout()
        title = QLabel("Painel Inicial")
        title.setStyleSheet("color:#e2e8f0;font-size:18px;font-weight:900;background:transparent;border:none;")
        top.addWidget(title)
        top.addStretch()
        refresh_btn = QPushButton("Atualizar")
        refresh_btn.clicked.connect(self.refresh)
        top.addWidget(refresh_btn)
        root.addLayout(top)

        self.cards_grid = QGridLayout()
        self.cards_grid.setSpacing(8)
        root.addLayout(self.cards_grid)

        shortcut_row = QHBoxLayout()
        shortcuts = [
            ("Notas", lambda: self._open("Notas")),
            ("Navegador", lambda: self._open("Navegador")),
            ("IA Local", lambda: self._open("IA Local")),
            ("Ferramentas", lambda: self._open("Ferramentas")),
            ("Backup", lambda: self._open("Config")),
            ("Busca global", self.open_global_search),
        ]
        for text, fn in shortcuts:
            btn = QPushButton(text)
            btn.setFixedHeight(34)
            btn.clicked.connect(fn)
            shortcut_row.addWidget(btn)
        root.addLayout(shortcut_row)

        lists = QHBoxLayout()
        self.recent_profiles = QListWidget()
        self.recent_profiles.setMinimumHeight(170)
        self.recent_profiles.setStyleSheet("QListWidget{background:#0b1626;border-radius:8px;}")
        self.recent_errors = QListWidget()
        self.recent_errors.setMinimumHeight(170)
        self.recent_errors.setStyleSheet("QListWidget{background:#0b1626;border-radius:8px;}")
        lists.addWidget(self._panel("Ultimos perfis usados", self.recent_profiles), 1)
        lists.addWidget(self._panel("Erros recentes", self.recent_errors), 1)
        root.addLayout(lists, 1)

    def _panel(self, title, widget):
        frame = QFrame()
        frame.setStyleSheet("QFrame{background:#08111f;border:1px solid rgba(34,211,238,0.10);border-radius:8px;}")
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(10, 8, 10, 10)
        lbl = QLabel(title)
        lbl.setStyleSheet("color:#67e8f9;font-weight:800;background:transparent;border:none;")
        lay.addWidget(lbl)
        lay.addWidget(widget)
        return frame

    def _clear_cards(self):
        while self.cards_grid.count():
            item = self.cards_grid.takeAt(0)
            widget = item.widget()
            if widget:
                widget.setParent(None)

    def refresh(self):
        profiles = list(getattr(self.browser_manager, "profiles", {}).values())
        open_count = len(self.browser_manager.get_active_browsers()) if hasattr(self.browser_manager, "get_active_browsers") else 0
        tasks = _load_json(CONFIG_DIR / "browser_tasks.json", [])
        if isinstance(tasks, dict):
            tasks = tasks.get("tasks") or tasks.get("items") or []
        tasks = [t for t in tasks if isinstance(t, dict)] if isinstance(tasks, list) else []
        pending_tasks = len([t for t in tasks if not t.get("done")])
        accounts = _load_json(CONFIG_DIR / "browser_accounts.json", [])
        if isinstance(accounts, dict):
            accounts = accounts.get("accounts") or accounts.get("items") or []
        accounts = [a for a in accounts if isinstance(a, dict)] if isinstance(accounts, list) else []
        backups_dir = BASE_DIR / "browser_backups"
        backup_count = len(list(backups_dir.glob("*.zip"))) if backups_dir.exists() else 0
        stats_total = 0
        try:
            stats_total = self.db.get_stats().get("total", 0) if self.db else 0
        except Exception:
            stats_total = 0

        self._clear_cards()
        cards = [
            ("Perfis", len(profiles), "total no navegador", "#22d3ee"),
            ("Abertos", open_count, "navegadores ativos", "#10b981"),
            ("Tarefas", pending_tasks, "pendentes", "#f59e0b"),
            ("Contas", len(accounts), "salvas", "#a78bfa"),
            ("Backups", backup_count, "arquivos zip", "#38bdf8"),
            ("Base", stats_total, "registros do gerador", "#34d399"),
        ]
        for i, data in enumerate(cards):
            self.cards_grid.addWidget(_card(*data), i // 3, i % 3)

        self.recent_profiles.clear()
        profiles.sort(key=lambda p: getattr(p, "last_used", "") or "", reverse=True)
        for p in profiles[:8]:
            tags = ", ".join(getattr(p, "tags", []) or []) or "sem tags"
            self.recent_profiles.addItem(f"{p.name}  |  {tags}")

        self.recent_errors.clear()
        for item in read_recent_logs(limit=8, only_errors=True):
            self.recent_errors.addItem(item)

    def _open(self, name):
        if self.open_page:
            self.open_page(name)

    def _tool(self, index):
        if self.open_tool:
            self.open_tool(index)

    def open_global_search(self):
        dialog = GlobalSearchDialog(self.browser_manager, self)
        dialog.exec_()


class GlobalSearchDialog(QDialog):
    """Busca em perfis, contas, tarefas, favoritos, logs e notas."""

    def __init__(self, browser_manager=None, parent=None):
        super().__init__(parent)
        self.browser_manager = browser_manager or BrowserManager()
        self.setWindowTitle("Busca global")
        self.resize(760, 520)
        self._records = self._collect_records()
        self._build()
        self.search_input.setFocus()

    def _build(self):
        lay = QVBoxLayout(self)
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("Pesquisar perfil, nota, conta, email, senha, ferramenta, log ou favorito...")
        self.search_input.textChanged.connect(self._filter)
        lay.addWidget(self.search_input)
        self.results = QListWidget()
        lay.addWidget(self.results, 1)
        close_btn = QPushButton("Fechar")
        close_btn.clicked.connect(self.accept)
        lay.addWidget(close_btn)
        self._filter("")

    def _collect_records(self):
        records = []
        for p in getattr(self.browser_manager, "profiles", {}).values():
            text = " ".join([
                getattr(p, "name", ""), getattr(p, "id", ""), getattr(p, "notes", ""),
                ", ".join(getattr(p, "tags", []) or []), getattr(p, "proxy", "") or "",
            ])
            records.append(("Perfil", text, f"{p.name} | {p.id}"))
        for file_name, label, keys in [
            ("browser_accounts.json", "Conta", ["name", "email", "site", "status", "notes"]),
            ("browser_tasks.json", "Tarefa", ["title", "profile_name", "account_name", "notes"]),
            ("default_favorites.json", "Favorito", ["name", "url", "folder"]),
        ]:
            data = _load_json(CONFIG_DIR / file_name, [])
            if isinstance(data, dict):
                data = data.get("items") or data.get("favorites") or []
            for row in data if isinstance(data, list) else []:
                text = " ".join(str(row.get(k, "")) for k in keys if isinstance(row, dict))
                records.append((label, text, text[:120]))
        notes_data = _load_json(BASE_DIR / "notepad_session.json", {})
        records.append(("Notas", json.dumps(notes_data, ensure_ascii=False), "Sessao do bloco de notas"))
        for line in read_recent_logs(limit=80, only_errors=False):
            records.append(("Log", line, line[:140]))
        return records

    def _filter(self, text):
        q = text.strip().lower()
        self.results.clear()
        for kind, haystack, display in self._records:
            if not q or q in haystack.lower():
                self.results.addItem(f"{kind}: {display}")


def read_recent_logs(limit=30, only_errors=False):
    log_file = CONFIG_DIR / "browser_logs.jsonl"
    if not log_file.exists():
        return []
    lines = []
    try:
        raw = log_file.read_text(encoding="utf-8", errors="ignore").splitlines()[-200:]
        for line in reversed(raw):
            try:
                event = json.loads(line)
                msg = event.get("message") or event.get("details") or str(event)
                typ = event.get("event") or event.get("type") or "log"
                if only_errors and "erro" not in msg.lower() and "error" not in typ.lower() and "failed" not in msg.lower():
                    continue
                lines.append(f"{typ}: {friendly_error_text(msg)}")
                if len(lines) >= limit:
                    break
            except Exception:
                if not only_errors:
                    lines.append(line[:180])
    except Exception:
        return []
    return lines


def friendly_error_text(message):
    text = str(message)
    low = text.lower()
    if "403" in low or "forbidden" in low:
        return "Bloqueio 403: tente limpar o perfil, trocar proxy/rede, usar modo Streaming ou abrir em outro navegador."
    if "chrome nao encontrado" in low or "chrome não encontrado" in low:
        return "Chrome nao encontrado: instale Chrome/Edge/Firefox ou use o reparo do launcher."
    if "webdriver" in low or "selenium" in low:
        return "Erro do navegador automatizado: tente modo nativo ou reparar dependencias."
    return text[:220]


class PrettyLogsWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self._build()
        self.refresh()

    def _build(self):
        lay = QVBoxLayout(self)
        lay.setContentsMargins(12, 10, 12, 10)
        top = QHBoxLayout()
        title = QLabel("Central de Logs")
        title.setStyleSheet("color:#e2e8f0;font-size:16px;font-weight:900;background:transparent;border:none;")
        top.addWidget(title)
        top.addStretch()
        refresh_btn = QPushButton("Atualizar")
        refresh_btn.clicked.connect(self.refresh)
        top.addWidget(refresh_btn)
        copy_btn = QPushButton("Copiar selecionado")
        copy_btn.clicked.connect(self.copy_selected)
        top.addWidget(copy_btn)
        fix_btn = QPushButton("Corrigir provavel")
        fix_btn.clicked.connect(self.show_fix_hint)
        top.addWidget(fix_btn)
        lay.addLayout(top)
        self.list = QListWidget()
        lay.addWidget(self.list, 1)

    def refresh(self):
        self.list.clear()
        for line in read_recent_logs(limit=80, only_errors=False):
            self.list.addItem(line)

    def copy_selected(self):
        item = self.list.currentItem()
        if item:
            QApplication.clipboard().setText(item.text())

    def show_fix_hint(self):
        item = self.list.currentItem()
        text = item.text() if item else ""
        QMessageBox.information(self, "Correcao provavel", friendly_error_text(text) or "Selecione um log para ver a sugestao.")


class GeneralSettingsWidget(QWidget):
    def __init__(self, browser_manager=None, parent=None):
        super().__init__(parent)
        self.browser_manager = browser_manager or BrowserManager()
        self.settings = load_app_settings()
        self._build()

    def _build(self):
        scroll = QScrollArea(self)
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        root = QVBoxLayout(self)
        root.setContentsMargins(0, 0, 0, 0)
        root.addWidget(scroll)

        body = QWidget()
        body_lay = QVBoxLayout(body)
        body_lay.setContentsMargins(18, 14, 18, 14)
        body_lay.setSpacing(12)

        title = QLabel("Configuracoes Gerais")
        title.setStyleSheet("color:#f8fafc;font-size:22px;font-weight:900;background:transparent;border:none;")
        body_lay.addWidget(title)
        subtitle = QLabel("Ajustes do app, backup, IA local e manutencao em um lugar so.")
        subtitle.setStyleSheet("color:#64748b;font-size:12px;background:transparent;border:none;")
        body_lay.addWidget(subtitle)

        app_card = self._section_card("Aparencia e Workspace", "Como o projeto deve parecer e organizar campanhas.")
        self.workspace_input = QLineEdit(self.settings.get("workspace", "Padrao"))
        app_card.layout().addWidget(self._row("Workspace/campanha", self.workspace_input))

        self.theme_combo = QComboBox()
        self.theme_combo.addItems(["Escuro profissional", "Claro", "Compacto escuro"])
        self.theme_combo.setCurrentText(self.settings.get("theme", "Escuro profissional"))
        app_card.layout().addWidget(self._row("Tema", self.theme_combo))

        self.scale_spin = QSpinBox()
        self.scale_spin.setRange(80, 130)
        self.scale_spin.setSuffix("%")
        self.scale_spin.setValue(int(self.settings.get("ui_scale", 100)))
        app_card.layout().addWidget(self._row("Tamanho da interface", self.scale_spin))
        body_lay.addWidget(app_card)

        window_card = self._section_card("Janela e comportamento", "Controle como o app abre, fecha e usa o painel compacto.")
        self.compact_check = QCheckBox("Iniciar preferindo modo compacto")
        self.compact_check.setChecked(bool(self.settings.get("compact_mode", False)))
        window_card.layout().addWidget(self._check_row(self.compact_check, "Abre o painel flutuante como preferencia."))

        self.close_to_tray_check = QCheckBox("Fechar no X minimiza para bandeja")
        self.close_to_tray_check.setChecked(bool(self.settings.get("close_to_tray", False)))
        window_card.layout().addWidget(self._check_row(self.close_to_tray_check, "Desmarcado fecha o projeto de verdade."))

        self.backup_check = QCheckBox("Backup automatico diario local")
        self.backup_check.setChecked(bool(self.settings.get("auto_backup", True)))
        window_card.layout().addWidget(self._check_row(self.backup_check, "Mantido como preferencia; backup pesado nao roda na abertura."))
        body_lay.addWidget(window_card)

        data_card = self._section_card("Dados e Backup", "Pasta de dados, backup inteligente e restauracao.")
        data_row = QHBoxLayout()
        self.data_folder = QLineEdit(self.settings.get("data_folder", str(BASE_DIR)))
        browse_btn = QPushButton("Escolher pasta")
        browse_btn.clicked.connect(self.choose_data_folder)
        data_row.addWidget(self.data_folder, 1)
        data_row.addWidget(browse_btn)
        data_card.layout().addWidget(self._row("Pasta de dados", data_row))

        backup_actions = QHBoxLayout()
        self.backup_btn = QPushButton("Criar backup agora")
        self.backup_btn.clicked.connect(self.create_backup_now)
        backup_actions.addWidget(self.backup_btn)
        restore_btn = QPushButton("Restaurar backup")
        restore_btn.clicked.connect(self.restore_backup)
        backup_actions.addWidget(restore_btn)
        data_card.layout().addLayout(backup_actions)
        body_lay.addWidget(data_card)

        ai_card = self._section_card("IA Local", "Atalhos para configurar Ollama, LM Studio, GPT4All ou LocalAI.")
        self.ai_provider_combo = QComboBox()
        self.ai_provider_combo.addItems(["Ollama", "OpenAI Compatível", "llama.cpp"])
        self.ai_provider_combo.setCurrentText(self.settings.get("ai_provider", "Ollama"))
        ai_card.layout().addWidget(self._row("Motor preferido", self.ai_provider_combo))
        self.ai_model_input = QLineEdit(self.settings.get("ai_model", "llama3.2:3b"))
        ai_card.layout().addWidget(self._row("Modelo preferido", self.ai_model_input))
        ai_actions = QHBoxLayout()
        open_ai_btn = QPushButton("Abrir aba IA Local")
        open_ai_btn.clicked.connect(self._open_ai_page)
        ai_actions.addWidget(open_ai_btn)
        ai_actions.addStretch()
        ai_card.layout().addLayout(ai_actions)
        body_lay.addWidget(ai_card)

        maintenance_card = self._section_card("Manutencao", "Reparos rapidos quando algo parar de funcionar.")
        actions = QHBoxLayout()
        save_btn = QPushButton("Salvar configuracoes")
        save_btn.clicked.connect(self.save)
        actions.addWidget(save_btn)
        repair_btn = QPushButton("Reparar dependencias")
        repair_btn.clicked.connect(self.repair_dependencies)
        actions.addWidget(repair_btn)
        open_folder_btn = QPushButton("Abrir pasta do projeto")
        open_folder_btn.clicked.connect(self.open_project_folder)
        actions.addWidget(open_folder_btn)
        maintenance_card.layout().addLayout(actions)
        body_lay.addWidget(maintenance_card)

        self.logs = PrettyLogsWidget()
        body_lay.addWidget(self.logs, 1)
        scroll.setWidget(body)

    def _section_card(self, title, subtitle):
        frame = QFrame()
        frame.setStyleSheet(
            "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.14);border-radius:16px;}"
        )
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(14, 12, 14, 14)
        lay.setSpacing(9)
        title_lbl = QLabel(title)
        title_lbl.setStyleSheet("color:#e2e8f0;font-size:15px;font-weight:900;background:transparent;border:none;")
        sub_lbl = QLabel(subtitle)
        sub_lbl.setWordWrap(True)
        sub_lbl.setStyleSheet("color:#64748b;font-size:11px;background:transparent;border:none;")
        lay.addWidget(title_lbl)
        lay.addWidget(sub_lbl)
        return frame

    def _row(self, label, widget_or_layout):
        frame = QFrame()
        frame.setStyleSheet("QFrame{background:#08111f;border:1px solid rgba(148,163,184,0.10);border-radius:12px;}")
        lay = QHBoxLayout(frame)
        lay.setContentsMargins(12, 9, 12, 9)
        lbl = QLabel(label)
        lbl.setMinimumWidth(160)
        lbl.setStyleSheet("color:#94a3b8;font-weight:700;background:transparent;border:none;")
        lay.addWidget(lbl)
        if isinstance(widget_or_layout, QHBoxLayout):
            lay.addLayout(widget_or_layout, 1)
        else:
            lay.addWidget(widget_or_layout, 1)
        return frame

    def _check_row(self, checkbox, hint):
        frame = QFrame()
        frame.setStyleSheet("QFrame{background:#08111f;border:1px solid rgba(148,163,184,0.10);border-radius:12px;}")
        lay = QVBoxLayout(frame)
        lay.setContentsMargins(12, 9, 12, 9)
        checkbox.setStyleSheet("color:#e2e8f0;font-weight:700;background:transparent;border:none;")
        lay.addWidget(checkbox)
        label = QLabel(hint)
        label.setWordWrap(True)
        label.setStyleSheet("color:#64748b;font-size:11px;background:transparent;border:none;")
        lay.addWidget(label)
        return frame

    def choose_data_folder(self):
        folder = QFileDialog.getExistingDirectory(self, "Pasta de dados", self.data_folder.text())
        if folder:
            self.data_folder.setText(folder)

    def save(self):
        data = {
            "workspace": self.workspace_input.text().strip() or "Padrao",
            "theme": self.theme_combo.currentText(),
            "ui_scale": self.scale_spin.value(),
            "compact_mode": self.compact_check.isChecked(),
            "close_to_tray": self.close_to_tray_check.isChecked(),
            "auto_backup": self.backup_check.isChecked(),
            "data_folder": self.data_folder.text().strip() or str(BASE_DIR),
            "ai_provider": self.ai_provider_combo.currentText(),
            "ai_model": self.ai_model_input.text().strip() or "llama3.2:3b",
        }
        save_app_settings(data)
        QMessageBox.information(self, "Configuracoes", "Configuracoes salvas.")

    def _open_ai_page(self):
        parent = self.window()
        if parent and hasattr(parent, "open_page_by_name"):
            parent.open_page_by_name("IA Local")

    def open_project_folder(self):
        try:
            if os.name == "nt":
                os.startfile(str(BASE_DIR))
            else:
                subprocess.Popen(["xdg-open", str(BASE_DIR)])
        except Exception as exc:
            QMessageBox.warning(self, "Pasta do projeto", f"Nao foi possivel abrir a pasta:\n{exc}")

    def create_backup_now(self):
        if hasattr(self, "_backup_worker") and self._backup_worker.isRunning():
            QMessageBox.information(self, "Backup", "Backup ja esta em andamento.")
            return
        self.backup_btn.setEnabled(False)
        self.backup_btn.setText("Criando backup...")
        self._backup_worker = BackupWorker(self)
        self._backup_worker.finished_backup.connect(self._on_backup_finished)
        self._backup_worker.start()

    def _on_backup_finished(self, ok, message):
        self.backup_btn.setEnabled(True)
        self.backup_btn.setText("Criar backup agora")
        if ok:
            LAST_BACKUP_FILE.parent.mkdir(parents=True, exist_ok=True)
            LAST_BACKUP_FILE.write_text(datetime.now().strftime("%Y-%m-%d"), encoding="utf-8")
            QMessageBox.information(self, "Backup", f"Backup criado:\n{message}")
        else:
            QMessageBox.warning(self, "Backup", f"Nao foi possivel criar o backup:\n{message}")

    def restore_backup(self):
        file_path, _ = QFileDialog.getOpenFileName(self, "Restaurar backup", str(BASE_DIR), "Backups (*.zip)")
        if not file_path:
            return
        reply = QMessageBox.question(
            self,
            "Restaurar backup",
            "Isso vai restaurar arquivos do backup sobre a pasta do projeto. Continuar?",
            QMessageBox.Yes | QMessageBox.No,
        )
        if reply != QMessageBox.Yes:
            return
        try:
            with zipfile.ZipFile(file_path, "r") as zf:
                zf.extractall(BASE_DIR)
            QMessageBox.information(self, "Backup", "Backup restaurado. Reinicie o projeto para recarregar tudo.")
        except Exception as exc:
            QMessageBox.critical(self, "Backup", f"Erro ao restaurar backup:\n{exc}")

    def repair_dependencies(self):
        installer = BASE_DIR / "INSTALAR_TUDO.bat"
        if not installer.exists():
            QMessageBox.warning(self, "Reparo", "INSTALAR_TUDO.bat nao encontrado.")
            return
        try:
            subprocess.Popen(["cmd", "/c", "start", "/min", str(installer)], cwd=str(BASE_DIR))
            QMessageBox.information(self, "Reparo", "Reparo iniciado minimizado.")
        except Exception as exc:
            QMessageBox.critical(self, "Reparo", f"Nao foi possivel iniciar o reparo:\n{exc}")
