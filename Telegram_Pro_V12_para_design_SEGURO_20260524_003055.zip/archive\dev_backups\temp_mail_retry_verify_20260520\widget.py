#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Gerador de contas temporarias Mail.tm em lote."""

from __future__ import annotations

import json
import random
import string
import time
import urllib.error
import urllib.request
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional

from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtWidgets import (
    QApplication,
    QFileDialog,
    QFrame,
    QGridLayout,
    QHBoxLayout,
    QHeaderView,
    QLabel,
    QLineEdit,
    QMessageBox,
    QPushButton,
    QSpinBox,
    QTableWidget,
    QTableWidgetItem,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from app.core.paths import APP_DATA_DIR


DATA_FILE = APP_DATA_DIR / "temp_mail_accounts.json"
API_BASE = "https://api.mail.tm"
API_ATTRIBUTION = "Mail.tm"


def _now() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def _safe_read_json(path: Path, default):
    try:
        if path.exists():
            return json.loads(path.read_text(encoding="utf-8"))
    except Exception:
        pass
    return default


def _safe_write_json(path: Path, data) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding="utf-8")


def _rand_text(length: int = 10) -> str:
    alphabet = string.ascii_lowercase + string.digits
    return "".join(random.choice(alphabet) for _ in range(length))


def _make_password() -> str:
    alphabet = string.ascii_letters + string.digits
    return "".join(random.choice(alphabet) for _ in range(14))


class MailTmClient:
    def request(self, method: str, path: str, payload: Optional[dict] = None, token: str = ""):
        data = None if payload is None else json.dumps(payload).encode("utf-8")
        headers = {
            "Content-Type": "application/json",
            "User-Agent": "TelegramPro-TempMail/1.0",
        }
        if token:
            headers["Authorization"] = f"Bearer {token}"
        req = urllib.request.Request(f"{API_BASE}{path}", data=data, headers=headers, method=method)
        with urllib.request.urlopen(req, timeout=25) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw) if raw else {}

    def domains(self) -> List[str]:
        data = self.request("GET", "/domains")
        items = data.get("hydra:member") or data.get("domains") or []
        domains = []
        for item in items:
            if item.get("isActive", True) and item.get("domain"):
                domains.append(item["domain"])
        return domains

    def create_account(self, address: str, password: str) -> dict:
        return self.request("POST", "/accounts", {"address": address, "password": password})

    def token(self, address: str, password: str) -> str:
        data = self.request("POST", "/token", {"address": address, "password": password})
        return data.get("token", "")

    def messages(self, token: str) -> List[dict]:
        data = self.request("GET", "/messages", token=token)
        return data.get("hydra:member") or data.get("messages") or []


class TempMailBatchWorker(QThread):
    progress = pyqtSignal(dict)
    finished_batch = pyqtSignal(list, str)

    def __init__(self, count: int, fixed_password: str, prefix: str, existing: set[str], parent=None):
        super().__init__(parent)
        self.count = max(1, min(50, int(count)))
        self.fixed_password = fixed_password.strip()
        self.prefix = "".join(ch for ch in prefix.strip().lower() if ch.isalnum())[:18]
        self.existing = set(existing)
        self._stop = False

    def stop(self):
        self._stop = True

    def run(self):
        client = MailTmClient()
        created = []
        try:
            domains = client.domains()
            if not domains:
                self.finished_batch.emit([], "Nenhum dominio ativo retornado pelo Mail.tm.")
                return
            domain = domains[0]
            for index in range(self.count):
                if self._stop:
                    break
                address = self._unique_address(domain)
                password = self.fixed_password or _make_password()
                account = {
                    "email": address,
                    "password": password,
                    "domain": domain,
                    "created_at": _now(),
                    "status": "criando",
                    "token": "",
                    "source": API_ATTRIBUTION,
                }
                try:
                    client.create_account(address, password)
                    # Mail.tm limita requisicoes; uma pausa curta evita erro 429 em lote grande.
                    time.sleep(0.45)
                    token = client.token(address, password)
                    account["token"] = token
                    account["status"] = "ok" if token else "sem token"
                except urllib.error.HTTPError as exc:
                    if exc.code == 429:
                        time.sleep(2.5)
                    account["status"] = f"erro HTTP {exc.code}"
                    account["error"] = exc.read().decode("utf-8", errors="replace")[:300] if exc.fp else ""
                except Exception as exc:
                    account["status"] = "erro"
                    account["error"] = str(exc)[:300]
                created.append(account)
                self.progress.emit({"index": index + 1, "total": self.count, "account": account})
                time.sleep(0.35)
            self.finished_batch.emit(created, "" if created else "Nenhuma conta foi criada.")
        except Exception as exc:
            self.finished_batch.emit(created, str(exc))

    def _unique_address(self, domain: str) -> str:
        for _ in range(1000):
            local = f"{self.prefix or 'tmp'}{_rand_text(10)}"
            address = f"{local}@{domain}"
            if address not in self.existing:
                self.existing.add(address)
                return address
        return f"{self.prefix or 'tmp'}{int(time.time())}{random.randint(1000,9999)}@{domain}"


class TempMailInboxWorker(QThread):
    result = pyqtSignal(list, str)

    def __init__(self, email: str, password: str, token: str = "", parent=None):
        super().__init__(parent)
        self.email = email
        self.password = password
        self.token = token

    def run(self):
        try:
            client = MailTmClient()
            token = self.token or client.token(self.email, self.password)
            if not token:
                self.result.emit([], "Nao consegui autenticar essa conta.")
                return
            messages = client.messages(token)
            self.result.emit(messages, "")
        except Exception as exc:
            self.result.emit([], str(exc))


class TempMailWidget(QWidget):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.accounts: List[Dict] = _safe_read_json(DATA_FILE, [])
        self.worker: Optional[TempMailBatchWorker] = None
        self.inbox_worker: Optional[TempMailInboxWorker] = None
        self._build_ui()
        self.refresh_table()

    def _build_ui(self):
        self.setStyleSheet(self._qss())
        root = QVBoxLayout(self)
        root.setContentsMargins(18, 16, 18, 16)
        root.setSpacing(12)

        hero = QFrame()
        hero.setObjectName("Hero")
        hero_lay = QHBoxLayout(hero)
        hero_lay.setContentsMargins(18, 14, 18, 14)
        title_box = QVBoxLayout()
        title = QLabel("Email Temp")
        title.setObjectName("Title")
        subtitle = QLabel("Gere contas Mail.tm em lote, salve email:senha e consulte a caixa selecionada.")
        subtitle.setObjectName("Subtitle")
        title_box.addWidget(title)
        title_box.addWidget(subtitle)
        hero_lay.addLayout(title_box, 1)
        self.status_badge = QLabel("Pronto")
        self.status_badge.setObjectName("Badge")
        self.status_badge.setAlignment(Qt.AlignCenter)
        hero_lay.addWidget(self.status_badge)
        root.addWidget(hero)

        body = QHBoxLayout()
        body.setSpacing(12)
        root.addLayout(body, 1)

        controls = QFrame()
        controls.setObjectName("Card")
        controls.setFixedWidth(360)
        c = QVBoxLayout(controls)
        c.setContentsMargins(16, 14, 16, 14)
        c.setSpacing(10)
        h = QLabel("Gerar lote")
        h.setObjectName("Section")
        c.addWidget(h)

        c.addWidget(QLabel("Quantidade"))
        self.count_spin = QSpinBox()
        self.count_spin.setRange(1, 50)
        self.count_spin.setValue(50)
        c.addWidget(self.count_spin)

        c.addWidget(QLabel("Senha fixa opcional"))
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Vazio = senha aleatoria por conta")
        c.addWidget(self.password_input)

        c.addWidget(QLabel("Prefixo opcional"))
        self.prefix_input = QLineEdit()
        self.prefix_input.setPlaceholderText("Ex: teste, amazon, conta")
        c.addWidget(self.prefix_input)

        self.progress_label = QLabel("Nenhuma geracao em andamento.")
        self.progress_label.setObjectName("Hint")
        self.progress_label.setWordWrap(True)
        c.addWidget(self.progress_label)

        generate_btn = QPushButton("Gerar lote")
        generate_btn.setObjectName("Primary")
        generate_btn.clicked.connect(self.start_batch)
        c.addWidget(generate_btn)

        stop_btn = QPushButton("Parar")
        stop_btn.clicked.connect(self.stop_batch)
        c.addWidget(stop_btn)

        copy_btn = QPushButton("Copiar todos email:senha")
        copy_btn.clicked.connect(self.copy_all)
        c.addWidget(copy_btn)

        export_btn = QPushButton("Exportar TXT")
        export_btn.clicked.connect(self.export_txt)
        c.addWidget(export_btn)

        delete_btn = QPushButton("Remover selecionado")
        delete_btn.setObjectName("Danger")
        delete_btn.clicked.connect(self.delete_selected)
        c.addWidget(delete_btn)
        c.addStretch(1)
        c.addWidget(QLabel("Uso permitido: testes, contas proprias e recebimento temporario. Respeite limites e regras do Mail.tm."))
        body.addWidget(controls)

        right = QVBoxLayout()
        right.setSpacing(10)
        body.addLayout(right, 1)

        summary = QFrame()
        summary.setObjectName("Card")
        s = QHBoxLayout(summary)
        s.setContentsMargins(14, 10, 14, 10)
        self.total_label = QLabel("0 contas")
        self.total_label.setObjectName("Metric")
        self.ok_label = QLabel("0 ok")
        self.ok_label.setObjectName("Metric")
        self.last_label = QLabel("ultimo: -")
        self.last_label.setObjectName("Metric")
        for widget in (self.total_label, self.ok_label, self.last_label):
            s.addWidget(widget)
        right.addWidget(summary)

        self.table = QTableWidget(0, 5)
        self.table.setHorizontalHeaderLabels(["Email", "Senha", "Dominio", "Status", "Criado"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        self.table.setSelectionBehavior(QTableWidget.SelectRows)
        self.table.setEditTriggers(QTableWidget.NoEditTriggers)
        self.table.cellDoubleClicked.connect(lambda *_: self.copy_selected())
        right.addWidget(self.table, 1)

        actions = QHBoxLayout()
        copy_selected_btn = QPushButton("Copiar selecionado")
        copy_selected_btn.clicked.connect(self.copy_selected)
        inbox_btn = QPushButton("Ver inbox")
        inbox_btn.clicked.connect(self.fetch_inbox)
        save_btn = QPushButton("Salvar agora")
        save_btn.clicked.connect(self.save_accounts)
        actions.addWidget(copy_selected_btn)
        actions.addWidget(inbox_btn)
        actions.addWidget(save_btn)
        right.addLayout(actions)

        self.inbox_view = QTextEdit()
        self.inbox_view.setReadOnly(True)
        self.inbox_view.setPlaceholderText("Selecione uma conta e clique em Ver inbox.")
        self.inbox_view.setFixedHeight(150)
        right.addWidget(self.inbox_view)

    def start_batch(self):
        if self.worker and self.worker.isRunning():
            self.set_status("Gerando...", pending=True)
            return
        existing = {acc.get("email", "") for acc in self.accounts}
        self.worker = TempMailBatchWorker(
            self.count_spin.value(),
            self.password_input.text(),
            self.prefix_input.text(),
            existing,
            self,
        )
        self.worker.progress.connect(self.on_progress)
        self.worker.finished_batch.connect(self.on_finished)
        self.worker.start()
        self.set_status("Gerando...", pending=True)
        self.progress_label.setText("Iniciando lote...")

    def stop_batch(self):
        if self.worker and self.worker.isRunning():
            self.worker.stop()
            self.progress_label.setText("Parando apos a conta atual...")

    def on_progress(self, payload: dict):
        account = payload.get("account") or {}
        self.progress_label.setText(f"{payload.get('index')}/{payload.get('total')} - {account.get('email', '')} - {account.get('status', '')}")
        if account.get("email"):
            self.accounts.append(account)
            self.save_accounts(silent=True)
            self.refresh_table()

    def on_finished(self, created: list, error: str):
        if error and not created:
            self.set_status("Erro", ok=False)
            self.progress_label.setText(error)
        else:
            self.set_status("Pronto", ok=True)
            self.progress_label.setText(f"Lote finalizado. Novas contas: {len(created)}")
        self.refresh_table()

    def refresh_table(self):
        self.table.setRowCount(0)
        for account in self.accounts:
            row = self.table.rowCount()
            self.table.insertRow(row)
            values = [
                account.get("email", ""),
                account.get("password", ""),
                account.get("domain", ""),
                account.get("status", ""),
                account.get("created_at", ""),
            ]
            for col, value in enumerate(values):
                item = QTableWidgetItem(str(value))
                item.setData(Qt.UserRole, account.get("email", ""))
                self.table.setItem(row, col, item)
        ok_count = sum(1 for acc in self.accounts if acc.get("status") == "ok")
        self.total_label.setText(f"{len(self.accounts)} contas")
        self.ok_label.setText(f"{ok_count} ok")
        self.last_label.setText(f"ultimo: {self.accounts[-1].get('email', '-') if self.accounts else '-'}")

    def selected_account(self) -> Optional[Dict]:
        row = self.table.currentRow()
        if row < 0:
            return None
        email_item = self.table.item(row, 0)
        email = email_item.text() if email_item else ""
        for account in self.accounts:
            if account.get("email") == email:
                return account
        return None

    def copy_selected(self):
        account = self.selected_account()
        if not account:
            QMessageBox.information(self, "Email Temp", "Selecione uma conta.")
            return
        text = f"{account.get('email', '')}:{account.get('password', '')}"
        QApplication.clipboard().setText(text)
        self.set_status("Copiado", ok=True)

    def copy_all(self):
        lines = [f"{a.get('email', '')}:{a.get('password', '')}" for a in self.accounts if a.get("email")]
        QApplication.clipboard().setText("\n".join(lines))
        self.set_status(f"{len(lines)} copiadas", ok=True)

    def export_txt(self):
        default = str(APP_DATA_DIR / "temp_mail_export.txt")
        path, _ = QFileDialog.getSaveFileName(self, "Exportar emails temporarios", default, "Texto (*.txt)")
        if not path:
            return
        lines = [f"{a.get('email', '')}:{a.get('password', '')}" for a in self.accounts if a.get("email")]
        Path(path).write_text("\n".join(lines), encoding="utf-8")
        self.set_status("Exportado", ok=True)

    def delete_selected(self):
        account = self.selected_account()
        if not account:
            QMessageBox.information(self, "Email Temp", "Selecione uma conta.")
            return
        email = account.get("email")
        self.accounts = [a for a in self.accounts if a.get("email") != email]
        self.save_accounts(silent=True)
        self.refresh_table()

    def fetch_inbox(self):
        account = self.selected_account()
        if not account:
            QMessageBox.information(self, "Email Temp", "Selecione uma conta.")
            return
        self.inbox_view.setPlainText("Buscando mensagens...")
        self.inbox_worker = TempMailInboxWorker(account.get("email", ""), account.get("password", ""), account.get("token", ""), self)
        self.inbox_worker.result.connect(self.on_inbox_result)
        self.inbox_worker.start()

    def on_inbox_result(self, messages: list, error: str):
        if error:
            self.inbox_view.setPlainText(error)
            return
        if not messages:
            self.inbox_view.setPlainText("Nenhuma mensagem encontrada.")
            return
        lines = []
        for msg in messages[:12]:
            lines.append(f"{msg.get('createdAt', '')} | {msg.get('from', {}).get('address', '')} | {msg.get('subject', '')}")
        self.inbox_view.setPlainText("\n".join(lines))

    def save_accounts(self, silent: bool = False):
        _safe_write_json(DATA_FILE, self.accounts)
        if not silent:
            self.set_status("Salvo", ok=True)

    def set_status(self, text: str, ok: bool = False, pending: bool = False):
        self.status_badge.setText(text[:40])
        self.status_badge.setProperty("state", "pending" if pending else ("ok" if ok else "normal"))
        self.status_badge.style().unpolish(self.status_badge)
        self.status_badge.style().polish(self.status_badge)

    @staticmethod
    def _qss():
        return """
        QWidget { background:#07080f; color:#e5f4ff; font-family: Segoe UI; font-size:12px; }
        QFrame#Hero, QFrame#Card { background:#0d1b2f; border:1px solid rgba(34,211,238,.18); border-radius:14px; }
        QLabel#Title { font-size:24px; font-weight:900; color:#f8fbff; }
        QLabel#Subtitle, QLabel#Hint { color:#8fb3d1; }
        QLabel#Section { color:#67e8f9; font-size:14px; font-weight:900; }
        QLabel#Metric { background:#07111f; border:1px solid rgba(34,211,238,.14); border-radius:10px; padding:10px; color:#67e8f9; font-weight:900; }
        QLabel#Badge { min-width:120px; min-height:42px; padding:8px 12px; border-radius:12px; font-weight:900; border:1px solid rgba(148,163,184,.2); background:#111827; color:#cbd5e1; }
        QLabel#Badge[state="ok"] { background:#052e25; color:#34d399; border-color:#10b981; }
        QLabel#Badge[state="pending"] { background:#172554; color:#93c5fd; border-color:#3b82f6; }
        QLineEdit, QTextEdit, QSpinBox { background:#091827; color:#f8fbff; border:1px solid rgba(34,211,238,.18); border-radius:9px; padding:9px; }
        QPushButton { background:#142338; color:#f8fbff; border:1px solid rgba(34,211,238,.18); border-radius:10px; min-height:36px; font-weight:800; }
        QPushButton:hover { background:#12324a; border-color:#22d3ee; }
        QPushButton#Primary { background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0891b2,stop:1 #10b981); border-color:#22d3ee; }
        QPushButton#Danger { background:#7f1d1d; border-color:#dc2626; }
        QTableWidget { background:#07111f; alternate-background-color:#0d1b2f; border:1px solid rgba(34,211,238,.16); border-radius:12px; gridline-color:#14324a; }
        QTableWidget::item:selected { background:#0e7490; color:#ffffff; }
        QHeaderView::section { background:#0b2638; color:#67e8f9; padding:8px; border:0; font-weight:900; }
        """
