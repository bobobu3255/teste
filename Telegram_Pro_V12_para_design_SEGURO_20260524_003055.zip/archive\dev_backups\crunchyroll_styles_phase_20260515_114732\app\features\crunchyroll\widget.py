﻿"""
Widget do Bot Crunchyroll para integraÃ§Ã£o com Telegram Collector
Permite iniciar e controlar o bot Crunchyroll diretamente da interface

VersÃ£o 9.2 - Melhorias:
- Console avanÃ§ado com filtros e cores
- ConfiguraÃ§Ã£o de Proxy PyProxy rotativa
- IP Ãºnico por conta criada
- Limite de 3 cartÃµes por conta
- RemoÃ§Ã£o automÃ¡tica de contas/cartÃµes apÃ³s teste
- Tratamento robusto de erros (bot nÃ£o para mais)
- Verificador de Assinatura corrigido
- BotÃ£o "Copiar email:senha" nos resultados
"""
import os
import sys
import subprocess
import json
import re
import shutil
from datetime import datetime
from pathlib import Path
from app.core.paths import BASE_DIR

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QPushButton, QLabel, 
    QTextEdit, QGroupBox, QFileDialog, QMessageBox, QLineEdit,
    QSpinBox, QCheckBox, QProgressBar, QTabWidget, QScrollArea,
    QFrame, QSplitter, QGridLayout, QComboBox, QPlainTextEdit, QApplication
)

from PyQt5.QtCore import Qt, QThread, pyqtSignal, QProcess, QTimer

from PyQt5.QtGui import QFont, QTextCursor, QColor, QTextCharFormat


def _resolve_command(*names):
    for name in names:
        path = shutil.which(name)
        if path:
            return path
    return names[0] if names else ""


def _hidden_subprocess_kwargs():
    if sys.platform != 'win32':
        return {}

    startupinfo = subprocess.STARTUPINFO()
    startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    return {
        'startupinfo': startupinfo,
        'creationflags': getattr(subprocess, 'CREATE_NO_WINDOW', 0),
    }


def _find_chrome_executable():
    candidates = []
    if sys.platform == 'win32':
        local = os.environ.get('LOCALAPPDATA', '')
        program_files = os.environ.get('ProgramFiles', r'C:\Program Files')
        program_files_x86 = os.environ.get('ProgramFiles(x86)', r'C:\Program Files (x86)')
        user_profile = os.environ.get('USERPROFILE', '')
        candidates.extend([
            os.path.join(program_files, 'Google', 'Chrome', 'Application', 'chrome.exe'),
            os.path.join(program_files_x86, 'Google', 'Chrome', 'Application', 'chrome.exe'),
            os.path.join(local, 'Google', 'Chrome', 'Application', 'chrome.exe'),
            os.path.join(program_files, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
            os.path.join(program_files_x86, 'Microsoft', 'Edge', 'Application', 'msedge.exe'),
        ])
        if user_profile:
            cache_dir = os.path.join(user_profile, '.cache', 'puppeteer', 'chrome')
            if os.path.isdir(cache_dir):
                for root, _, files in os.walk(cache_dir):
                    if 'chrome.exe' in files:
                        candidates.append(os.path.join(root, 'chrome.exe'))
    else:
        for name in ('google-chrome', 'chromium', 'chromium-browser'):
            path = shutil.which(name)
            if path:
                candidates.append(path)

    for path in candidates:
        if path and os.path.exists(path):
            return path
    return ''


def _node_env():
    env = os.environ.copy()
    if sys.platform == 'win32':
        env['PYTHONIOENCODING'] = 'utf-8'
        env['PYTHONUTF8'] = '1'

    chrome_path = env.get('PUPPETEER_EXECUTABLE_PATH') or _find_chrome_executable()
    if chrome_path:
        env['PUPPETEER_EXECUTABLE_PATH'] = chrome_path
    return env


class InstallDependenciesThread(QThread):
    """Thread para instalar dependÃªncias do Node.js"""
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(bool, str)
    
    def __init__(self, bot_path, parent=None):
        super().__init__(parent)
        self.bot_path = bot_path
    
    def run(self):
        try:
            self.output_signal.emit("[INSTALAÃ‡ÃƒO] Iniciando instalaÃ§Ã£o das dependÃªncias...")
            self.output_signal.emit("[INSTALAÃ‡ÃƒO] Executando: npm install")
            
            env = _node_env()
            
            npm_cmd = _resolve_command('npm.cmd', 'npm') if sys.platform == 'win32' else _resolve_command('npm')
            
            process = subprocess.Popen(
                [npm_cmd, 'install'],
                cwd=self.bot_path,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                **_hidden_subprocess_kwargs()
            )
            
            while True:
                line = process.stdout.readline()
                if not line:
                    break
                
                try:
                    decoded_line = line.decode('utf-8', errors='replace').rstrip()
                except AttributeError:
                    decoded_line = line.rstrip() if isinstance(line, str) else str(line).rstrip()
                
                if decoded_line:
                    self.output_signal.emit(f"[NPM] {decoded_line}")
            
            process.stdout.close()
            return_code = process.wait()
            
            if return_code == 0:
                self.output_signal.emit("[INSTALAÃ‡ÃƒO] âœ… DependÃªncias instaladas com sucesso!")
                self.finished_signal.emit(True, "DependÃªncias instaladas com sucesso!")
            else:
                self.output_signal.emit(f"[INSTALAÃ‡ÃƒO] âŒ Erro na instalaÃ§Ã£o (cÃ³digo: {return_code})")
                self.finished_signal.emit(False, f"Erro na instalaÃ§Ã£o (cÃ³digo: {return_code})")
                
        except FileNotFoundError:
            self.output_signal.emit("[ERRO] npm nÃ£o encontrado! Instale o Node.js primeiro.")
            self.finished_signal.emit(False, "npm nÃ£o encontrado! Instale o Node.js primeiro.")
        except Exception as e:
            self.output_signal.emit(f"[ERRO] {str(e)}")
            self.finished_signal.emit(False, str(e))


class CrunchyrollBotThread(QThread):
    """Thread para executar o bot Crunchyroll"""
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int)
    error_signal = pyqtSignal(str)
    dependencies_missing = pyqtSignal()
    
    def __init__(self, bot_path, num_workers=3, proxy_config=None, parent=None):
        super().__init__(parent)
        self.bot_path = bot_path
        self.num_workers = num_workers
        self.proxy_config = proxy_config or {}
        self.process = None
        self._stop_requested = False
    
    def run(self):
        try:
            env = _node_env()
            
            # Configurar nÃºmero de workers
            env['NUM_WORKERS'] = str(self.num_workers)
            
            # Configurar proxy se habilitado
            if self.proxy_config.get('enabled'):
                env['PROXY_ENABLED'] = 'true'
                env['PROXY_HOST'] = self.proxy_config.get('host', '')
                env['PROXY_PORT'] = str(self.proxy_config.get('port', 0))
                env['PROXY_USERNAME'] = self.proxy_config.get('username', '')
                env['PROXY_PASSWORD'] = self.proxy_config.get('password', '')
                env['PROXY_TYPE'] = self.proxy_config.get('type', 'http')
                env['PROXY_COUNTRY'] = self.proxy_config.get('country', 'BR')
                env['PROXY_UNIQUE_IP'] = 'true'
                env['PROXY_FULL_STRING'] = self.proxy_config.get('full_string', '')
                self.output_signal.emit(f"[PROXY] Proxy configurado: {self.proxy_config.get('host')}:{self.proxy_config.get('port')}")
                self.output_signal.emit(f"[PROXY] PaÃ­s: {self.proxy_config.get('country')} | IP Ãºnico por conta: Ativado")
            
            # Verificar Node.js
            node_cmd = _resolve_command('node.exe', 'node') if sys.platform == 'win32' else _resolve_command('node')
            node_check = subprocess.run(
                [node_cmd, '--version'], 
                capture_output=True, 
                text=True, 
                encoding='utf-8',
                errors='replace',
                **_hidden_subprocess_kwargs()
            )
            if node_check.returncode != 0:
                self.error_signal.emit("Node.js nÃ£o encontrado! Instale o Node.js primeiro.")
                return
            
            self.output_signal.emit(f"[INFO] Node.js {node_check.stdout.strip()} encontrado")
            self.output_signal.emit(f"[INFO] Usando {self.num_workers} navegador(es) simultÃ¢neo(s)")
            if env.get('PUPPETEER_EXECUTABLE_PATH'):
                self.output_signal.emit(f"[INFO] Navegador: {env['PUPPETEER_EXECUTABLE_PATH']}")
            
            # Verificar node_modules
            node_modules_path = os.path.join(self.bot_path, 'node_modules')
            if not os.path.exists(node_modules_path):
                self.output_signal.emit("[AVISO] DependÃªncias nÃ£o instaladas!")
                self.output_signal.emit("[AVISO] Clique em 'Instalar DependÃªncias' primeiro.")
                self.dependencies_missing.emit()
                return

            puppeteer_check = subprocess.run(
                [node_cmd, '-e', "import puppeteer from 'puppeteer'; console.log(puppeteer.executablePath());"],
                cwd=self.bot_path,
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                env=env,
                **_hidden_subprocess_kwargs()
            )
            if puppeteer_check.returncode != 0:
                self.output_signal.emit("[AVISO] Puppeteer quebrado ou incompleto.")
                self.output_signal.emit(puppeteer_check.stderr.strip() or puppeteer_check.stdout.strip())
                self.dependencies_missing.emit()
                return
            
            self.output_signal.emit(f"[INFO] Iniciando bot em: {self.bot_path}")
            
            self.process = subprocess.Popen(
                [node_cmd, 'index.js'],
                cwd=self.bot_path,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                **_hidden_subprocess_kwargs()
            )
            
            while True:
                if self._stop_requested:
                    break
                
                line = self.process.stdout.readline()
                if not line:
                    break
                
                try:
                    decoded_line = line.decode('utf-8', errors='replace').rstrip()
                except AttributeError:
                    decoded_line = line.rstrip() if isinstance(line, str) else str(line).rstrip()
                
                if decoded_line:
                    self.output_signal.emit(decoded_line)
            
            self.process.stdout.close()
            return_code = self.process.wait()
            self.finished_signal.emit(return_code)
            
        except FileNotFoundError:
            self.error_signal.emit("Node.js nÃ£o encontrado! Instale o Node.js primeiro.")
        except Exception as e:
            self.error_signal.emit(f"Erro ao executar bot: {str(e)}")
    
    def stop(self):
        self._stop_requested = True
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()


class VerificadorThread(QThread):
    """Thread para executar o verificador de assinatura"""
    output_signal = pyqtSignal(str)
    finished_signal = pyqtSignal(int)
    error_signal = pyqtSignal(str)
    result_signal = pyqtSignal(dict)
    
    def __init__(self, bot_path, accounts, proxy_config=None, parent=None):
        super().__init__(parent)
        self.bot_path = bot_path
        self.accounts = accounts
        self.proxy_config = proxy_config or {}
        self.process = None
        self._stop_requested = False
    
    def run(self):
        try:
            env = _node_env()
            
            # Configurar proxy se habilitado
            if self.proxy_config.get('enabled'):
                env['PROXY_ENABLED'] = 'true'
                env['PROXY_HOST'] = self.proxy_config.get('host', '')
                env['PROXY_PORT'] = str(self.proxy_config.get('port', 0))
                env['PROXY_USERNAME'] = self.proxy_config.get('username', '')
                env['PROXY_PASSWORD'] = self.proxy_config.get('password', '')
                env['PROXY_FULL_STRING'] = self.proxy_config.get('full_string', '')
                self.output_signal.emit(f"[PROXY] Usando proxy: {self.proxy_config.get('host')}:{self.proxy_config.get('port')}")
            
            # Salvar contas para verificar
            verificar_path = os.path.join(self.bot_path, 'data', 'verificar.txt')
            os.makedirs(os.path.dirname(verificar_path), exist_ok=True)
            with open(verificar_path, 'w', encoding='utf-8') as f:
                f.write('\n'.join(self.accounts))
            
            self.output_signal.emit(f"[VERIFICADOR] Iniciando verificaÃ§Ã£o de {len(self.accounts)} conta(s)...")
            
            # Verificar Node.js
            node_cmd = _resolve_command('node.exe', 'node') if sys.platform == 'win32' else _resolve_command('node')
            node_check = subprocess.run(
                [node_cmd, '--version'],
                capture_output=True,
                text=True,
                encoding='utf-8',
                errors='replace',
                **_hidden_subprocess_kwargs()
            )
            if node_check.returncode != 0:
                self.error_signal.emit("Node.js nÃ£o encontrado! Instale o Node.js primeiro.")
                return

            node_modules_path = os.path.join(self.bot_path, 'node_modules')
            if not os.path.exists(node_modules_path):
                self.error_signal.emit("DependÃªncias do bot nÃ£o encontradas. Clique em 'Instalar DependÃªncias' no Crunchyroll.")
                return
            
            self.process = subprocess.Popen(
                [node_cmd, 'verificador.js'],
                cwd=self.bot_path,
                stdin=subprocess.PIPE,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                env=env,
                **_hidden_subprocess_kwargs()
            )
            
            while True:
                if self._stop_requested:
                    break
                
                line = self.process.stdout.readline()
                if not line:
                    break
                
                try:
                    decoded_line = line.decode('utf-8', errors='replace').rstrip()
                except AttributeError:
                    decoded_line = line.rstrip() if isinstance(line, str) else str(line).rstrip()
                
                if decoded_line:
                    self.output_signal.emit(decoded_line)
            
            self.process.stdout.close()
            return_code = self.process.wait()
            
            # Ler resultados
            results = self.read_results()
            self.result_signal.emit(results)
            self.finished_signal.emit(return_code)
            
        except FileNotFoundError:
            self.error_signal.emit("Node.js nÃ£o encontrado! Instale o Node.js primeiro.")
        except Exception as e:
            self.error_signal.emit(f"Erro ao executar verificador: {str(e)}")
    
    def read_results(self):
        """LÃª os resultados do verificador"""
        results = {
            'completed': [],
            'failed': [],
            'login_failed': [],
            'no_payment': [],
            'invalid_email': [],
            'rate_limited': []
        }
        
        data_path = os.path.join(self.bot_path, 'data')
        
        # Completed
        completed_path = os.path.join(data_path, 'verificador_completed.txt')
        if os.path.exists(completed_path):
            with open(completed_path, 'r', encoding='utf-8') as f:
                results['completed'] = [l.strip() for l in f.readlines() if l.strip()]
        
        # Failed
        failed_path = os.path.join(data_path, 'verificador_failed.txt')
        if os.path.exists(failed_path):
            with open(failed_path, 'r', encoding='utf-8') as f:
                results['failed'] = [l.strip() for l in f.readlines() if l.strip()]
        
        # Login Failed
        login_failed_path = os.path.join(data_path, 'verificador_login_failed.txt')
        if os.path.exists(login_failed_path):
            with open(login_failed_path, 'r', encoding='utf-8') as f:
                results['login_failed'] = [l.strip() for l in f.readlines() if l.strip()]
        
        # No Payment
        no_payment_path = os.path.join(data_path, 'verificador_no_payment.txt')
        if os.path.exists(no_payment_path):
            with open(no_payment_path, 'r', encoding='utf-8') as f:
                results['no_payment'] = [l.strip() for l in f.readlines() if l.strip()]

        invalid_email_path = os.path.join(data_path, 'verificador_invalid_email.txt')
        if os.path.exists(invalid_email_path):
            with open(invalid_email_path, 'r', encoding='utf-8') as f:
                results['invalid_email'] = [l.strip() for l in f.readlines() if l.strip()]

        rate_limited_path = os.path.join(data_path, 'verificador_rate_limited.txt')
        if os.path.exists(rate_limited_path):
            with open(rate_limited_path, 'r', encoding='utf-8') as f:
                results['rate_limited'] = [l.strip() for l in f.readlines() if l.strip()]
        
        return results
    
    def stop(self):
        self._stop_requested = True
        if self.process:
            self.process.terminate()
            try:
                self.process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self.process.kill()


class AdvancedConsole(QWidget):
    """Console avanÃ§ado com filtros, cores e funcionalidades extras
    
    OTIMIZAÃ‡Ã•ES v9.1:
    - Limite mÃ¡ximo de linhas para evitar acumulaÃ§Ã£o de memÃ³ria
    - Batch update para evitar travamentos
    - Limpeza automÃ¡tica quando atinge o limite
    """
    
    # Limite mÃ¡ximo de linhas no console (evita travamentos)
    MAX_LOG_ENTRIES = 1000
    # Quantidade de linhas a remover quando atinge o limite
    CLEANUP_BATCH_SIZE = 300
    # Intervalo mÃ­nimo entre atualizaÃ§Ãµes de UI (ms)
    MIN_UPDATE_INTERVAL = 50
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.log_entries = []
        self.filter_level = "ALL"
        self._pending_logs = []  # Buffer para batch updates
        self._last_update_time = 0
        self._update_timer = None
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        layout.setSpacing(8)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Barra de ferramentas do console
        toolbar = QHBoxLayout()
        
        # Filtro de nÃ­vel
        filter_label = QLabel("Filtro:")
        filter_label.setStyleSheet("color: #94a3b8; font-size: 12px;")
        toolbar.addWidget(filter_label)
        
        self.filter_combo = QComboBox()
        self.filter_combo.addItems(["Todos", "Info", "Sucesso", "Aviso", "Erro", "Conta", "CartÃ£o", "Proxy", "Verificador"])
        self.filter_combo.setStyleSheet("""
            QComboBox {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 4px;
                padding: 4px 8px;
                min-width: 100px;
            }
            QComboBox::drop-down {
                border: none;
            }
            QComboBox QAbstractItemView {
                background-color: #1e293b;
                color: #f1f5f9;
                selection-background-color: #06b6d4;
            }
        """)
        self.filter_combo.currentTextChanged.connect(self.apply_filter)
        toolbar.addWidget(self.filter_combo)
        
        # Checkbox auto-scroll
        self.auto_scroll_check = QCheckBox("Auto-scroll")
        self.auto_scroll_check.setChecked(True)
        self.auto_scroll_check.setStyleSheet("""
            QCheckBox {
                color: #94a3b8;
                font-size: 12px;
            }
            QCheckBox::indicator {
                width: 14px;
                height: 14px;
            }
            QCheckBox::indicator:unchecked {
                background-color: #1e293b;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 3px;
            }
            QCheckBox::indicator:checked {
                background-color: #059669;
                border: 1px solid #059669;
                border-radius: 3px;
            }
        """)
        toolbar.addWidget(self.auto_scroll_check)
        
        # Contador de linhas
        self.line_count_label = QLabel("Linhas: 0")
        self.line_count_label.setStyleSheet("color: #6e7681; font-size: 11px;")
        toolbar.addWidget(self.line_count_label)
        
        toolbar.addStretch()
        
        # BotÃ£o exportar
        export_btn = QPushButton("ðŸ“¥ Exportar")
        export_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                padding: 4px 12px;
                border-radius: 4px;
                border: 1px solid rgba(6,182,212,0.15);
                font-size: 11px;
            }
            QPushButton:hover { background-color: rgba(6,182,212,0.15); }
        """)
        export_btn.clicked.connect(self.export_log)
        toolbar.addWidget(export_btn)
        
        # BotÃ£o limpar
        clear_btn = QPushButton("ðŸ—‘ï¸ Limpar")
        clear_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                padding: 4px 12px;
                border-radius: 4px;
                border: 1px solid rgba(6,182,212,0.15);
                font-size: 11px;
            }
            QPushButton:hover { background-color: #da3633; color: white; }
        """)
        clear_btn.clicked.connect(self.clear_console)
        toolbar.addWidget(clear_btn)
        
        layout.addLayout(toolbar)
        
        # Console de texto
        self.console_text = QTextEdit()
        self.console_text.setReadOnly(True)
        self.console_text.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f1f5f9;
                font-family: 'Cascadia Code', 'Fira Code', 'Consolas', 'Monaco', monospace;
                font-size: 12px;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                padding: 10px;
                line-height: 1.4;
            }
            QScrollBar:vertical {
                background-color: #0a0e1a;
                width: 10px;
                border-radius: 5px;
            }
            QScrollBar::handle:vertical {
                background-color: rgba(6,182,212,0.15);
                border-radius: 5px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background-color: #484f58;
            }
        """)
        self.console_text.setMinimumHeight(300)
        layout.addWidget(self.console_text)
        
        # EstatÃ­sticas rÃ¡pidas
        stats_layout = QHBoxLayout()
        
        self.stats_info = QLabel("ðŸ“Š Info: 0")
        self.stats_success = QLabel("âœ… Sucesso: 0")
        self.stats_warning = QLabel("âš ï¸ Avisos: 0")
        self.stats_error = QLabel("âŒ Erros: 0")
        
        for label in [self.stats_info, self.stats_success, self.stats_warning, self.stats_error]:
            label.setStyleSheet("color: #6e7681; font-size: 11px; padding: 2px 8px;")
            stats_layout.addWidget(label)
        
        stats_layout.addStretch()
        layout.addLayout(stats_layout)
        
        self.setLayout(layout)
        
        # Contadores
        self.counts = {'info': 0, 'success': 0, 'warning': 0, 'error': 0}
    
    def append(self, text):
        """Adiciona texto ao console com formataÃ§Ã£o - OTIMIZADO v9.1
        
        OtimizaÃ§Ãµes:
        - Batch updates para evitar travamentos
        - Limite mÃ¡ximo de linhas com limpeza automÃ¡tica
        - Throttling de atualizaÃ§Ãµes de UI
        """
        import time
        
        timestamp = datetime.now().strftime("%H:%M:%S")
        
        # Determinar tipo e cor
        log_type, color = self.get_log_type_and_color(text)
        
        # Armazenar entrada
        entry = {
            'timestamp': timestamp,
            'text': text,
            'type': log_type,
            'color': color
        }
        self.log_entries.append(entry)
        
        # OTIMIZAÃ‡ÃƒO: Limpar entradas antigas se exceder o limite
        if len(self.log_entries) > self.MAX_LOG_ENTRIES:
            # Remover as entradas mais antigas
            entries_to_remove = self.CLEANUP_BATCH_SIZE
            self.log_entries = self.log_entries[entries_to_remove:]
            
            # Reconstruir o console (mais eficiente que remover linha por linha)
            self._rebuild_console()
        
        # Atualizar contadores
        if log_type == 'error':
            self.counts['error'] += 1
        elif log_type == 'success':
            self.counts['success'] += 1
        elif log_type == 'warning':
            self.counts['warning'] += 1
        else:
            self.counts['info'] += 1
        
        # OTIMIZAÃ‡ÃƒO: Throttle updates - nÃ£o atualizar UI muito frequentemente
        current_time = time.time() * 1000  # em ms
        time_since_last_update = current_time - self._last_update_time
        
        if time_since_last_update < self.MIN_UPDATE_INTERVAL:
            # Adicionar ao buffer e agendar atualizaÃ§Ã£o
            self._pending_logs.append(entry)
            if self._update_timer is None:
                self._update_timer = QTimer.singleShot(
                    self.MIN_UPDATE_INTERVAL, 
                    self._flush_pending_logs
                )
            return
        
        # Atualizar imediatamente
        self._last_update_time = current_time
        self._add_entry_to_console(entry)
        self.update_stats()
        self.line_count_label.setText(f"Linhas: {len(self.log_entries)}")
    
    def _add_entry_to_console(self, entry):
        """Adiciona uma entrada ao console de texto"""
        if self.should_show(entry['type']):
            formatted = f'<span style="color: #6e7681;">[{entry["timestamp"]}]</span> <span style="color: {entry["color"]};">{entry["text"]}</span><br>'
            self.console_text.insertHtml(formatted)
            
            if self.auto_scroll_check.isChecked():
                cursor = self.console_text.textCursor()
                cursor.movePosition(QTextCursor.End)
                self.console_text.setTextCursor(cursor)
    
    def _flush_pending_logs(self):
        """Processa logs pendentes em batch"""
        import time
        
        self._update_timer = None
        
        if not self._pending_logs:
            return
        
        # Processar todos os logs pendentes de uma vez
        # Desabilitar atualizaÃ§Ãµes visuais temporÃ¡rias para performance
        self.console_text.setUpdatesEnabled(False)
        
        try:
            for entry in self._pending_logs:
                self._add_entry_to_console(entry)
        finally:
            self.console_text.setUpdatesEnabled(True)
            self._pending_logs.clear()
        
        self._last_update_time = time.time() * 1000
        self.update_stats()
        self.line_count_label.setText(f"Linhas: {len(self.log_entries)}")
    
    def _rebuild_console(self):
        """ReconstrÃ³i o console apÃ³s limpeza de memÃ³ria - OTIMIZADO"""
        # Desabilitar atualizaÃ§Ãµes visuais para performance
        self.console_text.setUpdatesEnabled(False)
        
        try:
            self.console_text.clear()
            
            # Reconstruir apenas as entradas visÃ­veis (baseado no filtro)
            html_parts = []
            for entry in self.log_entries:
                if self.should_show(entry['type']):
                    html_parts.append(
                        f'<span style="color: #6e7681;">[{entry["timestamp"]}]</span> '
                        f'<span style="color: {entry["color"]};">{entry["text"]}</span><br>'
                    )
            
            # Inserir todo o HTML de uma vez (muito mais rÃ¡pido)
            if html_parts:
                self.console_text.insertHtml(''.join(html_parts))
            
            if self.auto_scroll_check.isChecked():
                cursor = self.console_text.textCursor()
                cursor.movePosition(QTextCursor.End)
                self.console_text.setTextCursor(cursor)
        finally:
            self.console_text.setUpdatesEnabled(True)
    
    def get_log_type_and_color(self, text):
        """Determina o tipo e cor do log"""
        text_lower = text.lower()
        
        if '[erro]' in text_lower or '[error]' in text_lower or 'error' in text_lower or 'falhou' in text_lower or 'falha' in text_lower or '[failed]' in text_lower:
            return 'error', '#f43f5e'
        elif '[ok]' in text_lower or '[sucesso]' in text_lower or 'success' in text_lower or 'aprovado' in text_lower or 'premium' in text_lower or '[completed]' in text_lower:
            return 'success', '#3fb950'
        elif '[aviso]' in text_lower or '[warn]' in text_lower or 'warning' in text_lower:
            return 'warning', '#d29922'
        elif '[proxy]' in text_lower or 'ip:' in text_lower:
            return 'proxy', '#a371f7'
        elif '[conta]' in text_lower or 'conta' in text_lower:
            return 'conta', '#79c0ff'
        elif '[cartao]' in text_lower or '[cartÃ£o]' in text_lower or 'cartao' in text_lower or 'cartÃ£o' in text_lower:
            return 'cartao', '#f0883e'
        elif '[verificador]' in text_lower or 'verificando' in text_lower or 'assinatura' in text_lower:
            return 'verificador', '#ff79c6'
        elif '[info]' in text_lower:
            return 'info', '#22d3ee'
        elif '[etapa]' in text_lower or '[step]' in text_lower:
            return 'step', '#a371f7'
        elif '[sistema]' in text_lower:
            return 'system', '#06b6d4'
        elif '[instalaÃ§Ã£o]' in text_lower or '[npm]' in text_lower:
            return 'install', '#0891b2'
        else:
            return 'default', '#f1f5f9'
    
    def should_show(self, log_type):
        """Verifica se o log deve ser exibido baseado no filtro"""
        filter_text = self.filter_combo.currentText()
        
        if filter_text == "Todos":
            return True
        elif filter_text == "Info":
            return log_type in ['info', 'default', 'system', 'install', 'step']
        elif filter_text == "Sucesso":
            return log_type == 'success'
        elif filter_text == "Aviso":
            return log_type == 'warning'
        elif filter_text == "Erro":
            return log_type == 'error'
        elif filter_text == "Conta":
            return log_type == 'conta'
        elif filter_text == "CartÃ£o":
            return log_type == 'cartao'
        elif filter_text == "Proxy":
            return log_type == 'proxy'
        elif filter_text == "Verificador":
            return log_type == 'verificador'
        
        return True
    
    def apply_filter(self):
        """Aplica o filtro atual ao console"""
        self.console_text.clear()
        
        for entry in self.log_entries:
            if self.should_show(entry['type']):
                formatted = f'<span style="color: #6e7681;">[{entry["timestamp"]}]</span> <span style="color: {entry["color"]};">{entry["text"]}</span><br>'
                self.console_text.insertHtml(formatted)
        
        if self.auto_scroll_check.isChecked():
            cursor = self.console_text.textCursor()
            cursor.movePosition(QTextCursor.End)
            self.console_text.setTextCursor(cursor)
    
    def update_stats(self):
        """Atualiza as estatÃ­sticas"""
        self.stats_info.setText(f"ðŸ“Š Info: {self.counts['info']}")
        self.stats_success.setText(f"âœ… Sucesso: {self.counts['success']}")
        self.stats_warning.setText(f"âš ï¸ Avisos: {self.counts['warning']}")
        self.stats_error.setText(f"âŒ Erros: {self.counts['error']}")
    
    def clear_console(self):
        """Limpa o console"""
        self.console_text.clear()
        self.log_entries.clear()
        self.counts = {'info': 0, 'success': 0, 'warning': 0, 'error': 0}
        self.update_stats()
        self.line_count_label.setText("Linhas: 0")
    
    def export_log(self):
        """Exporta o log para arquivo"""
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Exportar Log", 
            f"crunchyroll_log_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt",
            "Text Files (*.txt);;All Files (*)"
        )
        
        if filepath:
            with open(filepath, 'w', encoding='utf-8') as f:
                for entry in self.log_entries:
                    f.write(f"[{entry['timestamp']}] {entry['text']}\n")
            
            QMessageBox.information(self, "Sucesso", f"Log exportado para:\n{filepath}")


class CrunchyrollWidget(QWidget):
    """Widget principal do Bot Crunchyroll v9.2 - MELHORADO
    
    MELHORIAS v9.2:
    - AtualizaÃ§Ã£o automÃ¡tica de cartÃµes e contas a cada 1 minuto
    - Throttling de load_results para evitar chamadas excessivas
    - Limite de atualizaÃ§Ãµes de UI por segundo
    - Processamento em batch de logs
    - CorreÃ§Ãµes no sistema de fila
    """
    
    # Intervalo mÃ­nimo entre atualizaÃ§Ãµes de resultados (ms)
    RESULTS_UPDATE_INTERVAL = 2000
    
    # Intervalo de atualizaÃ§Ã£o automÃ¡tica (ms) - 1 minuto
    AUTO_REFRESH_INTERVAL = 60000
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.bot_thread = None
        self.install_thread = None
        self.verificador_thread = None
        self.bot_path = os.path.join(str(BASE_DIR), 'crunchyroll_bot')
        self.is_dark_theme = True
        self.dependencies_installed = False
        self.proxy_config = {
            'enabled': False,
            'host': '',
            'port': 0,
            'username': '',
            'password': '',
            'type': 'http',
            'country': 'BR',
            'full_string': ''
        }
        
        # OTIMIZAÃ‡ÃƒO: Controle de throttling para load_results
        self._last_results_update = 0
        self._results_update_pending = False
        self._results_update_timer = None
        
        # NOVO v9.2: Timer para atualizaÃ§Ã£o automÃ¡tica
        self._auto_refresh_timer = None
        self._auto_refresh_enabled = True
        
        self.init_ui()
        self.load_files()
        self.check_dependencies()
        self.load_proxy_config()
        
        # NOVO v9.2: Iniciar timer de atualizaÃ§Ã£o automÃ¡tica
        self._setup_auto_refresh_timer()
    
    def check_dependencies(self):
        """Verifica se as dependÃªncias estÃ£o instaladas"""
        node_modules_path = os.path.join(self.bot_path, 'node_modules')
        self.dependencies_installed = False
        if os.path.exists(node_modules_path):
            node_cmd = _resolve_command('node.exe', 'node') if sys.platform == 'win32' else _resolve_command('node')
            try:
                check = subprocess.run(
                    [node_cmd, '-e', "import puppeteer from 'puppeteer'; console.log(puppeteer.executablePath());"],
                    cwd=self.bot_path,
                    capture_output=True,
                    text=True,
                    encoding='utf-8',
                    errors='replace',
                    env=_node_env(),
                    **_hidden_subprocess_kwargs()
                )
                self.dependencies_installed = check.returncode == 0
            except Exception:
                self.dependencies_installed = False
        self.update_dependency_status()
    
    def update_dependency_status(self):
        """Atualiza o status das dependÃªncias na interface"""
        if self.dependencies_installed:
            self.deps_status_label.setText("âœ… DependÃªncias instaladas")
            self.deps_status_label.setStyleSheet("font-size: 13px; color: #10b981; padding: 5px;")
            self.install_deps_btn.setEnabled(False)
            self.install_deps_btn.setText("âœ… DependÃªncias OK")
        else:
            self.deps_status_label.setText("âš ï¸ DependÃªncias NÃƒO instaladas")
            self.deps_status_label.setStyleSheet("font-size: 13px; color: #f43f5e; padding: 5px;")
            self.install_deps_btn.setEnabled(True)
            self.install_deps_btn.setText("ðŸ“¦ Instalar DependÃªncias")
    
    def get_group_style(self):
        """Retorna o estilo padrÃ£o para GroupBox"""
        return """
            QGroupBox {
                font-size: 14px;
                font-weight: bold;
                color: #06b6d4;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                margin-top: 12px;
                padding-top: 12px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px;
            }
        """
    
    def lighten_color(self, hex_color, factor=0.2):
        """Clareia uma cor hexadecimal"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        r = min(255, int(r + (255 - r) * factor))
        g = min(255, int(g + (255 - g) * factor))
        b = min(255, int(b + (255 - b) * factor))
        return f'#{r:02x}{g:02x}{b:02x}'
    
    def darken_color(self, hex_color, factor=0.2):
        """Escurece uma cor hexadecimal"""
        hex_color = hex_color.lstrip('#')
        r = int(hex_color[0:2], 16)
        g = int(hex_color[2:4], 16)
        b = int(hex_color[4:6], 16)
        r = max(0, int(r * (1 - factor)))
        g = max(0, int(g * (1 - factor)))
        b = max(0, int(b * (1 - factor)))
        return f'#{r:02x}{g:02x}{b:02x}'
    
    def get_button_style(self, color):
        """Retorna estilo para botÃµes"""
        return f"""
            QPushButton {{
                background-color: {color};
                color: white;
                font-size: 13px;
                font-weight: bold;
                padding: 10px 20px;
                border-radius: 6px;
                border: none;
            }}
            QPushButton:hover {{ background-color: {self.lighten_color(color)}; }}
            QPushButton:pressed {{ background-color: {self.darken_color(color)}; }}
            QPushButton:disabled {{ background-color: #1e293b; color: #484f58; }}
        """
    
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(16)
        main_layout.setContentsMargins(16, 16, 16, 16)
        
        # === HEADER ===
        header = QLabel("ðŸŽ¬ Crunchyroll Bot v9.2")
        header.setStyleSheet("""
            QLabel {
                font-size: 24px;
                font-weight: bold;
                color: #06b6d4;
                padding: 10px;
            }
        """)
        header.setAlignment(Qt.AlignCenter)
        main_layout.addWidget(header)
        
        # === TABS ===
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                background: #111827;
            }
            QTabBar::tab {
                background: #1e293b;
                color: #94a3b8;
                padding: 10px 20px;
                border-top-left-radius: 8px;
                border-top-right-radius: 8px;
                margin-right: 2px;
            }
            QTabBar::tab:selected {
                background: #06b6d4;
                color: white;
            }
            QTabBar::tab:hover:!selected {
                background: rgba(6,182,212,0.15);
            }
        """)
        
        # Tab 1: Controle do Bot
        control_tab = self.create_control_tab()
        self.tabs.addTab(control_tab, "ðŸŽ® Controle")
        
        # Tab 2: Contas
        accounts_tab = self.create_accounts_tab()
        self.tabs.addTab(accounts_tab, "ðŸ“§ Contas")
        
        # Tab 3: CartÃµes
        cards_tab = self.create_cards_tab()
        self.tabs.addTab(cards_tab, "ðŸ’³ CartÃµes")
        
        # Tab 4: Proxy
        proxy_tab = self.create_proxy_tab()
        self.tabs.addTab(proxy_tab, "ðŸŒ Proxy")
        
        # Tab 5: Verificador de Assinatura
        verificador_tab = self.create_verificador_tab()
        self.tabs.addTab(verificador_tab, "ðŸ” Verificador")
        
        # Tab 6: Resultados
        results_tab = self.create_results_tab()
        self.tabs.addTab(results_tab, "ðŸ“Š Resultados")
        
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)
    
    def create_control_tab(self):
        """Cria a aba de controle do bot"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        # Status
        status_group = QGroupBox("ðŸ“Š Status")
        status_group.setStyleSheet(self.get_group_style())
        status_layout = QVBoxLayout()
        
        self.status_label = QLabel("â¸ï¸ Bot parado")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #94a3b8;")
        status_layout.addWidget(self.status_label)
        
        # EstatÃ­sticas
        stats_layout = QHBoxLayout()
        self.contas_label = QLabel("ðŸ“§ Contas: 0")
        self.cartoes_label = QLabel("ðŸ’³ CartÃµes: 0")
        self.premium_label = QLabel("âœ… Premium: 0")
        
        for label in [self.contas_label, self.cartoes_label, self.premium_label]:
            label.setStyleSheet("font-size: 13px; color: #94a3b8; padding: 5px;")
            stats_layout.addWidget(label)
        
        status_layout.addLayout(stats_layout)
        
        # Status das dependÃªncias
        self.deps_status_label = QLabel("â³ Verificando dependÃªncias...")
        self.deps_status_label.setStyleSheet("font-size: 13px; color: #94a3b8; padding: 5px;")
        status_layout.addWidget(self.deps_status_label)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # === CONFIGURAÃ‡ÃƒO DE NAVEGADORES ===
        browsers_group = QGroupBox("ðŸŒ ConfiguraÃ§Ã£o de Navegadores")
        browsers_group.setStyleSheet(self.get_group_style())
        browsers_layout = QVBoxLayout()
        
        # Checkbox para ativar mÃºltiplos navegadores
        self.multi_browser_checkbox = QCheckBox("Usar mÃºltiplos navegadores simultÃ¢neos")
        self.multi_browser_checkbox.setStyleSheet("""
            QCheckBox {
                font-size: 13px;
                color: #f1f5f9;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:unchecked {
                background-color: #1e293b;
                border: 2px solid rgba(6,182,212,0.15);
                border-radius: 4px;
            }
            QCheckBox::indicator:checked {
                background-color: #059669;
                border: 2px solid #059669;
                border-radius: 4px;
            }
        """)
        self.multi_browser_checkbox.setChecked(True)
        self.multi_browser_checkbox.stateChanged.connect(self.on_multi_browser_changed)
        browsers_layout.addWidget(self.multi_browser_checkbox)
        
        # Layout para quantidade de navegadores
        qty_layout = QHBoxLayout()
        
        qty_label = QLabel("Quantidade de navegadores:")
        qty_label.setStyleSheet("font-size: 13px; color: #94a3b8; padding: 5px;")
        qty_layout.addWidget(qty_label)
        
        self.num_browsers_spin = QSpinBox()
        self.num_browsers_spin.setMinimum(1)
        self.num_browsers_spin.setMaximum(5)
        self.num_browsers_spin.setValue(3)
        self.num_browsers_spin.setStyleSheet("""
            QSpinBox {
                background-color: #1e293b;
                color: #f1f5f9;
                font-size: 14px;
                font-weight: bold;
                padding: 8px 15px;
                border: 2px solid rgba(6,182,212,0.15);
                border-radius: 6px;
                min-width: 80px;
            }
            QSpinBox:hover {
                border-color: #06b6d4;
            }
        """)
        qty_layout.addWidget(self.num_browsers_spin)
        
        self.browsers_info_label = QLabel("(3 navegadores = 3x mais rÃ¡pido)")
        self.browsers_info_label.setStyleSheet("font-size: 11px; color: #6e7681; padding: 5px;")
        qty_layout.addWidget(self.browsers_info_label)
        qty_layout.addStretch()
        
        browsers_layout.addLayout(qty_layout)
        
        # Aviso
        warning_label = QLabel("âš ï¸ Dica: Se muitas contas falharem, tente usar menos navegadores (1-2)")
        warning_label.setStyleSheet("font-size: 11px; color: #d29922; padding: 5px;")
        browsers_layout.addWidget(warning_label)
        
        browsers_group.setLayout(browsers_layout)
        layout.addWidget(browsers_group)
        
        # BotÃ£o de instalaÃ§Ã£o de dependÃªncias
        deps_group = QGroupBox("ðŸ“¦ DependÃªncias (Node.js)")
        deps_group.setStyleSheet(self.get_group_style())
        deps_layout = QHBoxLayout()
        
        self.install_deps_btn = QPushButton("ðŸ“¦ Instalar DependÃªncias")
        self.install_deps_btn.setStyleSheet(self.get_button_style("#0891b2"))
        self.install_deps_btn.clicked.connect(self.install_dependencies)
        deps_layout.addWidget(self.install_deps_btn)
        
        deps_info = QLabel("NecessÃ¡rio executar apenas uma vez")
        deps_info.setStyleSheet("font-size: 11px; color: #6e7681; padding: 5px;")
        deps_layout.addWidget(deps_info)
        deps_layout.addStretch()
        
        deps_group.setLayout(deps_layout)
        layout.addWidget(deps_group)
        
        # BotÃµes de controle
        control_group = QGroupBox("ðŸŽ® Controles")
        control_group.setStyleSheet(self.get_group_style())
        control_layout = QHBoxLayout()
        
        self.start_btn = QPushButton("â–¶ï¸ INICIAR BOT")
        self.start_btn.setStyleSheet(self.get_button_style("#059669"))
        self.start_btn.clicked.connect(self.start_bot)
        control_layout.addWidget(self.start_btn)
        
        self.stop_btn = QPushButton("â¹ï¸ PARAR BOT")
        self.stop_btn.setStyleSheet(self.get_button_style("#da3633"))
        self.stop_btn.clicked.connect(self.stop_bot)
        self.stop_btn.setEnabled(False)
        control_layout.addWidget(self.stop_btn)
        
        self.skip_btn = QPushButton("â­ï¸ PULAR CONTA")
        self.skip_btn.setStyleSheet(self.get_button_style("#d29922"))
        self.skip_btn.clicked.connect(self.skip_account)
        self.skip_btn.setEnabled(False)
        control_layout.addWidget(self.skip_btn)
        
        control_group.setLayout(control_layout)
        layout.addWidget(control_group)
        
        # Console avanÃ§ado
        console_group = QGroupBox("ðŸ“œ Console AvanÃ§ado")
        console_group.setStyleSheet(self.get_group_style())
        console_layout = QVBoxLayout()
        
        self.advanced_console = AdvancedConsole()
        console_layout.addWidget(self.advanced_console)
        
        console_group.setLayout(console_layout)
        layout.addWidget(console_group)
        
        tab.setLayout(layout)
        return tab
    
    def create_verificador_tab(self):
        """Cria a aba do verificador de assinatura"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        # Grupo de entrada de contas
        input_group = QGroupBox("ðŸ“§ Contas para Verificar (email:senha)")
        input_group.setStyleSheet(self.get_group_style())
        input_layout = QVBoxLayout()
        
        self.verificador_input = QTextEdit()
        self.verificador_input.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f1f5f9;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 12px;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.verificador_input.setPlaceholderText("Cole as contas aqui para verificar...\nFormato: email:senha ou email|senha\n\nExemplo:\nuser@email.com:senha123\noutro@email.com|minhasenha")
        self.verificador_input.setMaximumHeight(150)
        input_layout.addWidget(self.verificador_input)
        
        # BotÃµes de aÃ§Ã£o
        btn_layout = QHBoxLayout()
        
        self.verificar_btn = QPushButton("ðŸ” VERIFICAR ASSINATURAS")
        self.verificar_btn.setStyleSheet(self.get_button_style("#0891b2"))
        self.verificar_btn.clicked.connect(self.start_verificador)
        btn_layout.addWidget(self.verificar_btn)
        
        self.parar_verificador_btn = QPushButton("â¹ï¸ PARAR")
        self.parar_verificador_btn.setStyleSheet(self.get_button_style("#da3633"))
        self.parar_verificador_btn.clicked.connect(self.stop_verificador)
        self.parar_verificador_btn.setEnabled(False)
        btn_layout.addWidget(self.parar_verificador_btn)
        
        load_verificar_btn = QPushButton("ðŸ“‚ Carregar Arquivo")
        load_verificar_btn.setStyleSheet(self.get_button_style("#0891b2"))
        load_verificar_btn.clicked.connect(self.load_verificar_file)
        btn_layout.addWidget(load_verificar_btn)
        
        input_layout.addLayout(btn_layout)
        input_group.setLayout(input_layout)
        layout.addWidget(input_group)
        
        # Status do verificador
        status_group = QGroupBox("ðŸ“Š Status da VerificaÃ§Ã£o")
        status_group.setStyleSheet(self.get_group_style())
        status_layout = QHBoxLayout()
        
        self.verificador_status = QLabel("â¸ï¸ Aguardando...")
        self.verificador_status.setStyleSheet("font-size: 14px; font-weight: bold; color: #94a3b8;")
        status_layout.addWidget(self.verificador_status)
        
        status_layout.addStretch()
        
        self.verificador_progress = QLabel("0/0")
        self.verificador_progress.setStyleSheet("font-size: 14px; color: #94a3b8;")
        status_layout.addWidget(self.verificador_progress)
        
        status_group.setLayout(status_layout)
        layout.addWidget(status_group)
        
        # Resultados - Completed (Assinatura Ativa)
        completed_group = QGroupBox("âœ… Assinaturas ATIVAS (Completed)")
        completed_group.setStyleSheet(self.get_group_style())
        completed_layout = QVBoxLayout()
        
        self.verificador_completed = QTextEdit()
        self.verificador_completed.setReadOnly(True)
        self.verificador_completed.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #3fb950;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                border: 1px solid #059669;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.verificador_completed.setMaximumHeight(120)
        completed_layout.addWidget(self.verificador_completed)
        
        completed_btn_layout = QHBoxLayout()
        
        copy_completed_btn = QPushButton("ðŸ“‹ Copiar")
        copy_completed_btn.setStyleSheet(self.get_button_style("#059669"))
        copy_completed_btn.clicked.connect(self.copy_verificador_completed)
        completed_btn_layout.addWidget(copy_completed_btn)
        
        copy_completed_simple_btn = QPushButton("ðŸ“‹ Copiar email:senha")
        copy_completed_simple_btn.setStyleSheet(self.get_button_style("#0891b2"))
        copy_completed_simple_btn.clicked.connect(self.copy_verificador_completed_simple)
        completed_btn_layout.addWidget(copy_completed_simple_btn)
        
        clear_completed_btn = QPushButton("ðŸ—‘ï¸ Limpar")
        clear_completed_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                font-size: 12px;
                padding: 8px 16px;
                border-radius: 6px;
                border: 1px solid rgba(6,182,212,0.15);
            }
            QPushButton:hover { background-color: #da3633; color: white; }
        """)
        clear_completed_btn.clicked.connect(self.clear_verificador_completed)
        completed_btn_layout.addWidget(clear_completed_btn)
        
        completed_btn_layout.addStretch()
        completed_layout.addLayout(completed_btn_layout)
        completed_group.setLayout(completed_layout)
        layout.addWidget(completed_group)
        
        # Resultados - Failed (Assinatura Falhou)
        failed_group = QGroupBox("âŒ Assinaturas FALHAS (Failed)")
        failed_group.setStyleSheet(self.get_group_style())
        failed_layout = QVBoxLayout()
        
        self.verificador_failed = QTextEdit()
        self.verificador_failed.setReadOnly(True)
        self.verificador_failed.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f43f5e;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                border: 1px solid #da3633;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.verificador_failed.setMaximumHeight(100)
        failed_layout.addWidget(self.verificador_failed)
        
        failed_btn_layout = QHBoxLayout()
        
        copy_failed_btn = QPushButton("ðŸ“‹ Copiar")
        copy_failed_btn.setStyleSheet(self.get_button_style("#da3633"))
        copy_failed_btn.clicked.connect(self.copy_verificador_failed)
        failed_btn_layout.addWidget(copy_failed_btn)
        
        clear_failed_btn = QPushButton("ðŸ—‘ï¸ Limpar")
        clear_failed_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                font-size: 12px;
                padding: 8px 16px;
                border-radius: 6px;
                border: 1px solid rgba(6,182,212,0.15);
            }
            QPushButton:hover { background-color: #da3633; color: white; }
        """)
        clear_failed_btn.clicked.connect(self.clear_verificador_failed)
        failed_btn_layout.addWidget(clear_failed_btn)
        
        failed_btn_layout.addStretch()
        failed_layout.addLayout(failed_btn_layout)
        failed_group.setLayout(failed_layout)
        layout.addWidget(failed_group)
        
        # InformaÃ§Ãµes
        info_group = QGroupBox("â„¹ï¸ Como Funciona")
        info_group.setStyleSheet(self.get_group_style())
        info_layout = QVBoxLayout()
        
        info_text = QLabel("""
<p style="color: #94a3b8; line-height: 1.6;">
<b style="color: #06b6d4;">O Verificador de Assinatura:</b><br><br>

1. Faz login em cada conta usando: <code style="background: #1e293b; padding: 2px 6px; border-radius: 4px;">https://sso.crunchyroll.com/pt-br/login</code><br><br>

2. Acessa o histÃ³rico de pagamentos: <code style="background: #1e293b; padding: 2px 6px; border-radius: 4px;">https://www.crunchyroll.com/payments/history</code><br><br>

3. Verifica o status da assinatura:<br>
   â€¢ <span style="color: #3fb950;"><b>Completed</b></span> = Assinatura ATIVA âœ…<br>
   â€¢ <span style="color: #f43f5e;"><b>Failed</b></span> = Assinatura FALHOU âŒ<br><br>

<b style="color: #d29922;">âš ï¸ Dica:</b> Use o proxy para evitar bloqueios!
</p>
        """)
        info_text.setWordWrap(True)
        info_layout.addWidget(info_text)
        
        info_group.setLayout(info_layout)
        layout.addWidget(info_group)
        
        layout.addStretch()
        tab.setLayout(layout)
        return tab
    
    def create_proxy_tab(self):
        """Cria a aba de configuraÃ§Ã£o de proxy"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        # Grupo de configuraÃ§Ã£o de proxy
        proxy_group = QGroupBox("ðŸŒ ConfiguraÃ§Ã£o de Proxy PyProxy Rotativa")
        proxy_group.setStyleSheet(self.get_group_style())
        proxy_layout = QVBoxLayout()
        
        # Checkbox para habilitar proxy
        self.proxy_enabled_check = QCheckBox("Habilitar Proxy")
        self.proxy_enabled_check.setStyleSheet("""
            QCheckBox {
                font-size: 14px;
                font-weight: bold;
                color: #f1f5f9;
                padding: 5px;
            }
            QCheckBox::indicator {
                width: 20px;
                height: 20px;
            }
            QCheckBox::indicator:unchecked {
                background-color: #1e293b;
                border: 2px solid rgba(6,182,212,0.15);
                border-radius: 4px;
            }
            QCheckBox::indicator:checked {
                background-color: #059669;
                border: 2px solid #059669;
                border-radius: 4px;
            }
        """)
        self.proxy_enabled_check.stateChanged.connect(self.on_proxy_enabled_changed)
        proxy_layout.addWidget(self.proxy_enabled_check)
        
        # Campo para proxy string completa
        proxy_string_layout = QVBoxLayout()
        
        proxy_string_label = QLabel("Cole sua proxy PyProxy completa (formato: host:porta:usuario:senha):")
        proxy_string_label.setStyleSheet("color: #94a3b8; font-size: 13px;")
        proxy_string_layout.addWidget(proxy_string_label)
        
        self.proxy_string_edit = QLineEdit()
        self.proxy_string_edit.setPlaceholderText("Ex: cfd0a9406cc7e8bc.shg.na.pyproxy.io:16666:admin121-zone-resi-region-br:pass1212")
        self.proxy_string_edit.setStyleSheet("""
            QLineEdit {
                background-color: #1e293b;
                color: #f1f5f9;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 6px;
                padding: 12px;
                font-family: 'Consolas', monospace;
                font-size: 13px;
            }
            QLineEdit:focus {
                border-color: #06b6d4;
            }
        """)
        self.proxy_string_edit.textChanged.connect(self.parse_proxy_string)
        proxy_string_layout.addWidget(self.proxy_string_edit)
        
        proxy_layout.addLayout(proxy_string_layout)
        
        # Campos parseados (somente leitura)
        parsed_group = QGroupBox("ðŸ“‹ Dados Parseados")
        parsed_group.setStyleSheet("""
            QGroupBox {
                font-size: 12px;
                color: #94a3b8;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 6px;
                margin-top: 10px;
                padding-top: 10px;
            }
        """)
        parsed_layout = QGridLayout()
        parsed_layout.setSpacing(8)
        
        # Host
        host_label = QLabel("Host:")
        host_label.setStyleSheet("color: #6e7681;")
        parsed_layout.addWidget(host_label, 0, 0)
        
        self.proxy_host_display = QLabel("-")
        self.proxy_host_display.setStyleSheet("color: #22d3ee; font-family: monospace;")
        parsed_layout.addWidget(self.proxy_host_display, 0, 1)
        
        # Porta
        port_label = QLabel("Porta:")
        port_label.setStyleSheet("color: #6e7681;")
        parsed_layout.addWidget(port_label, 0, 2)
        
        self.proxy_port_display = QLabel("-")
        self.proxy_port_display.setStyleSheet("color: #22d3ee; font-family: monospace;")
        parsed_layout.addWidget(self.proxy_port_display, 0, 3)
        
        # UsuÃ¡rio
        user_label = QLabel("UsuÃ¡rio:")
        user_label.setStyleSheet("color: #6e7681;")
        parsed_layout.addWidget(user_label, 1, 0)
        
        self.proxy_user_display = QLabel("-")
        self.proxy_user_display.setStyleSheet("color: #22d3ee; font-family: monospace;")
        parsed_layout.addWidget(self.proxy_user_display, 1, 1)
        
        # Senha
        pass_label = QLabel("Senha:")
        pass_label.setStyleSheet("color: #6e7681;")
        parsed_layout.addWidget(pass_label, 1, 2)
        
        self.proxy_pass_display = QLabel("-")
        self.proxy_pass_display.setStyleSheet("color: #22d3ee; font-family: monospace;")
        parsed_layout.addWidget(self.proxy_pass_display, 1, 3)
        
        parsed_group.setLayout(parsed_layout)
        proxy_layout.addWidget(parsed_group)
        
        # Checkbox IP Ãºnico por conta
        self.unique_ip_check = QCheckBox("ðŸ”„ IP Ãºnico por conta (rotaciona IP a cada conta criada)")
        self.unique_ip_check.setChecked(True)
        self.unique_ip_check.setStyleSheet("""
            QCheckBox {
                font-size: 13px;
                color: #3fb950;
                padding: 10px 5px;
            }
            QCheckBox::indicator {
                width: 18px;
                height: 18px;
            }
            QCheckBox::indicator:checked {
                background-color: #059669;
                border: 2px solid #059669;
                border-radius: 4px;
            }
        """)
        proxy_layout.addWidget(self.unique_ip_check)
        
        # BotÃµes
        btn_layout = QHBoxLayout()
        
        save_proxy_btn = QPushButton("ðŸ’¾ Salvar ConfiguraÃ§Ã£o")
        save_proxy_btn.setStyleSheet(self.get_button_style("#059669"))
        save_proxy_btn.clicked.connect(self.save_proxy_config)
        btn_layout.addWidget(save_proxy_btn)
        
        test_proxy_btn = QPushButton("ðŸ” Testar Proxy")
        test_proxy_btn.setStyleSheet(self.get_button_style("#0891b2"))
        test_proxy_btn.clicked.connect(self.test_proxy)
        btn_layout.addWidget(test_proxy_btn)
        
        btn_layout.addStretch()
        proxy_layout.addLayout(btn_layout)
        
        proxy_group.setLayout(proxy_layout)
        layout.addWidget(proxy_group)
        
        layout.addStretch()
        tab.setLayout(layout)
        return tab
    
    def parse_proxy_string(self, text):
        """Parseia a string de proxy e atualiza os campos"""
        text = text.strip()
        if not text:
            self.proxy_host_display.setText("-")
            self.proxy_port_display.setText("-")
            self.proxy_user_display.setText("-")
            self.proxy_pass_display.setText("-")
            return
        
        parts = text.split(':')
        if len(parts) >= 4:
            self.proxy_host_display.setText(parts[0])
            self.proxy_port_display.setText(parts[1])
            self.proxy_user_display.setText(parts[2])
            self.proxy_pass_display.setText(parts[3] if len(parts[3]) <= 20 else parts[3][:17] + "...")
        elif len(parts) == 2:
            self.proxy_host_display.setText(parts[0])
            self.proxy_port_display.setText(parts[1])
            self.proxy_user_display.setText("-")
            self.proxy_pass_display.setText("-")
        else:
            self.proxy_host_display.setText("Formato invÃ¡lido")
            self.proxy_port_display.setText("-")
            self.proxy_user_display.setText("-")
            self.proxy_pass_display.setText("-")
    
    def create_accounts_tab(self):
        """Cria a aba de gerenciamento de contas"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        accounts_group = QGroupBox("ðŸ“§ Contas (email|senha ou email:senha)")
        accounts_group.setStyleSheet(self.get_group_style())
        accounts_layout = QVBoxLayout()
        
        self.accounts_edit = QTextEdit()
        self.accounts_edit.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f1f5f9;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 12px;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.accounts_edit.setPlaceholderText("Cole as contas aqui...\nFormato: email|senha ou email:senha")
        accounts_layout.addWidget(self.accounts_edit)
        
        btn_layout = QHBoxLayout()
        
        save_accounts_btn = QPushButton("ðŸ’¾ Salvar Contas")
        save_accounts_btn.setStyleSheet(self.get_button_style("#059669"))
        save_accounts_btn.clicked.connect(self.save_accounts)
        btn_layout.addWidget(save_accounts_btn)
        
        load_accounts_btn = QPushButton("ðŸ“‚ Carregar Arquivo")
        load_accounts_btn.setStyleSheet(self.get_button_style("#0891b2"))
        load_accounts_btn.clicked.connect(self.load_accounts_file)
        btn_layout.addWidget(load_accounts_btn)
        
        # BOTÃƒO DE ATUALIZAR - Remove contas jÃ¡ utilizadas
        refresh_accounts_btn = QPushButton("ðŸ”„ Atualizar (Remover Utilizadas)")
        refresh_accounts_btn.setStyleSheet(self.get_button_style("#06b6d4"))
        refresh_accounts_btn.clicked.connect(self.refresh_accounts_remove_used)
        refresh_accounts_btn.setToolTip("Remove contas que jÃ¡ foram processadas (premium, falhas, login OK, etc.)")
        btn_layout.addWidget(refresh_accounts_btn)
        
        accounts_layout.addLayout(btn_layout)
        accounts_group.setLayout(accounts_layout)
        layout.addWidget(accounts_group)
        
        tab.setLayout(layout)
        return tab
    
    def create_cards_tab(self):
        """Cria a aba de gerenciamento de cartÃµes"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        cards_group = QGroupBox("ðŸ’³ CartÃµes (numero|mes|ano|cvv)")
        cards_group.setStyleSheet(self.get_group_style())
        cards_layout = QVBoxLayout()
        
        self.cards_edit = QTextEdit()
        self.cards_edit.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f1f5f9;
                font-family: 'Consolas', 'Monaco', monospace;
                font-size: 12px;
                border: 1px solid rgba(6,182,212,0.15);
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.cards_edit.setPlaceholderText("Cole os cartÃµes aqui...\nFormato: numero|mes|ano|cvv")
        cards_layout.addWidget(self.cards_edit)
        
        btn_layout = QHBoxLayout()
        
        save_cards_btn = QPushButton("ðŸ’¾ Salvar CartÃµes")
        save_cards_btn.setStyleSheet(self.get_button_style("#059669"))
        save_cards_btn.clicked.connect(self.save_cards)
        btn_layout.addWidget(save_cards_btn)
        
        load_cards_btn = QPushButton("ðŸ“‚ Carregar Arquivo")
        load_cards_btn.setStyleSheet(self.get_button_style("#0891b2"))
        load_cards_btn.clicked.connect(self.load_cards_file)
        btn_layout.addWidget(load_cards_btn)
        
        # BOTÃƒO DE ATUALIZAR - Remove cartÃµes jÃ¡ utilizados
        refresh_cards_btn = QPushButton("ðŸ”„ Atualizar (Remover Utilizados)")
        refresh_cards_btn.setStyleSheet(self.get_button_style("#06b6d4"))
        refresh_cards_btn.clicked.connect(self.refresh_cards_remove_used)
        refresh_cards_btn.setToolTip("Remove cartÃµes que jÃ¡ foram aprovados ou reprovados")
        btn_layout.addWidget(refresh_cards_btn)
        
        cards_layout.addLayout(btn_layout)
        cards_group.setLayout(cards_layout)
        layout.addWidget(cards_group)
        
        tab.setLayout(layout)
        return tab
    
    def create_results_tab(self):
        """Cria a aba de resultados com botÃµes de limpar"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(12)
        
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setSpacing(12)
        
        # Resumo
        summary_group = QGroupBox("ðŸ“ˆ Resumo")
        summary_group.setStyleSheet(self.get_group_style())
        summary_layout = QGridLayout()
        
        self.stat_premium = QLabel("âœ… Premium: 0")
        self.stat_premium.setStyleSheet("font-size: 14px; font-weight: bold; color: #10b981; padding: 10px;")
        summary_layout.addWidget(self.stat_premium, 0, 0)
        
        self.stat_falhas = QLabel("âŒ Falhas: 0")
        self.stat_falhas.setStyleSheet("font-size: 14px; font-weight: bold; color: #f43f5e; padding: 10px;")
        summary_layout.addWidget(self.stat_falhas, 0, 1)
        
        self.stat_cartoes_ok = QLabel("ðŸ’³ CartÃµes Aprovados: 0")
        self.stat_cartoes_ok.setStyleSheet("font-size: 14px; font-weight: bold; color: #10b981; padding: 10px;")
        summary_layout.addWidget(self.stat_cartoes_ok, 1, 0)
        
        self.stat_cartoes_fail = QLabel("ðŸ’³ CartÃµes Reprovados: 0")
        self.stat_cartoes_fail.setStyleSheet("font-size: 14px; font-weight: bold; color: #f43f5e; padding: 10px;")
        summary_layout.addWidget(self.stat_cartoes_fail, 1, 1)
        
        summary_group.setLayout(summary_layout)
        scroll_layout.addWidget(summary_group)
        
        # Contas Premium Criadas
        premium_group = QGroupBox("âœ… Contas Premium Criadas")
        premium_group.setStyleSheet(self.get_group_style())
        premium_layout = QVBoxLayout()
        
        self.premium_edit = QTextEdit()
        self.premium_edit.setReadOnly(True)
        self.premium_edit.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #10b981;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                border: 1px solid #059669;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.premium_edit.setMaximumHeight(150)
        premium_layout.addWidget(self.premium_edit)
        
        premium_btn_layout = QHBoxLayout()
        
        copy_premium_btn = QPushButton("ðŸ“‹ Copiar Tudo")
        copy_premium_btn.setStyleSheet(self.get_button_style("#0891b2"))
        copy_premium_btn.clicked.connect(self.copy_premium)
        premium_btn_layout.addWidget(copy_premium_btn)
        
        copy_simple_btn = QPushButton("ðŸ“‹ Copiar email:senha")
        copy_simple_btn.setStyleSheet(self.get_button_style("#0891b2"))
        copy_simple_btn.clicked.connect(self.copy_premium_simple)
        premium_btn_layout.addWidget(copy_simple_btn)
        
        clear_premium_btn = QPushButton("ðŸ—‘ï¸ Limpar")
        clear_premium_btn.setStyleSheet("""
            QPushButton {
                background-color: #da3633;
                color: white;
                font-size: 13px;
                font-weight: bold;
                padding: 10px 20px;
                border-radius: 6px;
                border: none;
            }
            QPushButton:hover { background-color: #f43f5e; }
        """)
        clear_premium_btn.clicked.connect(self.clear_premium)
        premium_btn_layout.addWidget(clear_premium_btn)
        
        premium_btn_layout.addStretch()
        premium_layout.addLayout(premium_btn_layout)
        premium_group.setLayout(premium_layout)
        scroll_layout.addWidget(premium_group)
        
        # CartÃµes Aprovados
        cards_approved_group = QGroupBox("ðŸ’³ CartÃµes Aprovados")
        cards_approved_group.setStyleSheet(self.get_group_style())
        cards_approved_layout = QVBoxLayout()
        
        self.cards_approved_edit = QTextEdit()
        self.cards_approved_edit.setReadOnly(True)
        self.cards_approved_edit.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #10b981;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                border: 1px solid #059669;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.cards_approved_edit.setMaximumHeight(120)
        cards_approved_layout.addWidget(self.cards_approved_edit)
        
        cards_approved_btn_layout = QHBoxLayout()
        
        copy_cards_btn = QPushButton("ðŸ“‹ Copiar CartÃµes Aprovados")
        copy_cards_btn.setStyleSheet(self.get_button_style("#059669"))
        copy_cards_btn.clicked.connect(self.copy_cards_approved)
        cards_approved_btn_layout.addWidget(copy_cards_btn)
        
        clear_cards_approved_btn = QPushButton("ðŸ—‘ï¸ Limpar")
        clear_cards_approved_btn.setStyleSheet("""
            QPushButton {
                background-color: #da3633;
                color: white;
                font-size: 13px;
                font-weight: bold;
                padding: 10px 20px;
                border-radius: 6px;
                border: none;
            }
            QPushButton:hover { background-color: #f43f5e; }
        """)
        clear_cards_approved_btn.clicked.connect(self.clear_cards_approved)
        cards_approved_btn_layout.addWidget(clear_cards_approved_btn)
        
        cards_approved_btn_layout.addStretch()
        cards_approved_layout.addLayout(cards_approved_btn_layout)
        cards_approved_group.setLayout(cards_approved_layout)
        scroll_layout.addWidget(cards_approved_group)
        
        # CartÃµes Reprovados
        cards_rejected_group = QGroupBox("âŒ CartÃµes Reprovados")
        cards_rejected_group.setStyleSheet(self.get_group_style())
        cards_rejected_layout = QVBoxLayout()
        
        self.cards_rejected_edit = QTextEdit()
        self.cards_rejected_edit.setReadOnly(True)
        self.cards_rejected_edit.setStyleSheet("""
            QTextEdit {
                background-color: #0a0e1a;
                color: #f43f5e;
                font-family: 'Consolas', monospace;
                font-size: 12px;
                border: 1px solid #da3633;
                border-radius: 8px;
                padding: 10px;
            }
        """)
        self.cards_rejected_edit.setMaximumHeight(100)
        cards_rejected_layout.addWidget(self.cards_rejected_edit)
        
        cards_rejected_btn_layout = QHBoxLayout()
        
        clear_cards_rejected_btn = QPushButton("ðŸ—‘ï¸ Limpar Reprovados")
        clear_cards_rejected_btn.setStyleSheet("""
            QPushButton {
                background-color: #1e293b;
                color: #94a3b8;
                font-size: 12px;
                padding: 8px 16px;
                border-radius: 6px;
                border: 1px solid rgba(6,182,212,0.15);
            }
            QPushButton:hover { background-color: rgba(6,182,212,0.15); }
        """)
        clear_cards_rejected_btn.clicked.connect(self.clear_cards_rejected)
        cards_rejected_btn_layout.addWidget(clear_cards_rejected_btn)
        
        cards_rejected_btn_layout.addStretch()
        cards_rejected_layout.addLayout(cards_rejected_btn_layout)
        cards_rejected_group.setLayout(cards_rejected_layout)
        scroll_layout.addWidget(cards_rejected_group)
        
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)
        
        tab.setLayout(layout)
        return tab
    
    # ========== FUNÃ‡Ã•ES DO VERIFICADOR ==========
    
    def start_verificador(self):
        """Inicia o verificador de assinatura"""
        accounts_text = self.verificador_input.toPlainText().strip()
        if not accounts_text:
            QMessageBox.warning(self, "Aviso", "Cole as contas para verificar!")
            return
        
        accounts = [l.strip() for l in accounts_text.split('\n') if l.strip() and not l.startswith('#')]
        
        if not accounts:
            QMessageBox.warning(self, "Aviso", "Nenhuma conta vÃ¡lida encontrada!")
            return
        
        if not self.dependencies_installed:
            reply = QMessageBox.question(
                self, "DependÃªncias nÃ£o instaladas",
                "As dependÃªncias do Node.js nÃ£o estÃ£o instaladas.\n\n"
                "Deseja instalar agora?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.install_dependencies()
            return
        
        # Iniciar thread do verificador
        self.verificador_thread = VerificadorThread(self.bot_path, accounts, self.proxy_config)
        self.verificador_thread.output_signal.connect(self.append_console)
        self.verificador_thread.finished_signal.connect(self.verificador_finished)
        self.verificador_thread.error_signal.connect(self.verificador_error)
        self.verificador_thread.result_signal.connect(self.verificador_results)
        self.verificador_thread.start()
        
        # Atualizar UI
        self.verificar_btn.setEnabled(False)
        self.parar_verificador_btn.setEnabled(True)
        self.verificador_status.setText(f"ðŸ” Verificando {len(accounts)} conta(s)...")
        self.verificador_status.setStyleSheet("font-size: 14px; font-weight: bold; color: #0891b2;")
        self.verificador_progress.setText(f"0/{len(accounts)}")
        
        self.append_console(f"[VERIFICADOR] Iniciando verificaÃ§Ã£o de {len(accounts)} conta(s)...")
    
    def stop_verificador(self):
        """Para o verificador"""
        if self.verificador_thread:
            self.verificador_thread.stop()
            self.append_console("[VERIFICADOR] Parando verificaÃ§Ã£o...")
    
    def verificador_finished(self, return_code):
        """Chamado quando o verificador termina"""
        self.verificar_btn.setEnabled(True)
        self.parar_verificador_btn.setEnabled(False)
        self.verificador_status.setText("âœ… VerificaÃ§Ã£o concluÃ­da!")
        self.verificador_status.setStyleSheet("font-size: 14px; font-weight: bold; color: #3fb950;")
        
        self.append_console(f"[VERIFICADOR] VerificaÃ§Ã£o concluÃ­da (cÃ³digo: {return_code})")
    
    def verificador_error(self, error):
        """Chamado quando ocorre erro no verificador"""
        self.verificar_btn.setEnabled(True)
        self.parar_verificador_btn.setEnabled(False)
        self.verificador_status.setText("âŒ Erro na verificaÃ§Ã£o")
        self.verificador_status.setStyleSheet("font-size: 14px; font-weight: bold; color: #f43f5e;")
        
        self.append_console(f"[VERIFICADOR] Erro: {error}")
        QMessageBox.critical(self, "Erro", error)
    
    def verificador_results(self, results):
        """Atualiza os resultados do verificador"""
        completed = results.get('completed', [])
        failed_groups = [
            ("Falha", results.get('failed', [])),
            ("Login falhou", results.get('login_failed', [])),
            ("Sem pagamento", results.get('no_payment', [])),
            ("Email invalido", results.get('invalid_email', [])),
            ("Rate limit", results.get('rate_limited', [])),
        ]

        self.verificador_completed.setText('\n'.join(completed))

        failed_text = []
        for label, lines in failed_groups:
            if not lines:
                continue
            if failed_text:
                failed_text.append("")
            failed_text.append(f"[{label}]")
            failed_text.extend(lines)
        self.verificador_failed.setText('\n'.join(failed_text))

        # Atualizar contagem
        completed_count = len(completed)
        failed_count = sum(len(lines) for _, lines in failed_groups)
        
        self.verificador_progress.setText(f"âœ… {completed_count} | âŒ {failed_count}")
    
    def load_verificar_file(self):
        """Carrega contas de um arquivo para verificar"""
        filepath, _ = QFileDialog.getOpenFileName(self, "Carregar Contas", "", "Text Files (*.txt);;All Files (*)")
        if filepath:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
                current = self.verificador_input.toPlainText()
                if current.strip():
                    self.verificador_input.setText(current + '\n' + '\n'.join(lines))
                else:
                    self.verificador_input.setText('\n'.join(lines))
    
    def copy_verificador_completed(self):
        """Copia as contas com assinatura ativa"""

        text = self.verificador_completed.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Sucesso", "Contas com assinatura ATIVA copiadas!")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhuma conta para copiar!")
    
    def copy_verificador_completed_simple(self):
        """Copia as contas com assinatura ativa no formato email:senha"""

        
        # Primeiro tentar ler do arquivo simples
        simple_path = os.path.join(self.bot_path, 'data', 'verificador_completed_simples.txt')
        if os.path.exists(simple_path):
            with open(simple_path, 'r', encoding='utf-8') as f:
                text = f.read().strip()
            if text:
                QApplication.clipboard().setText(text)
                QMessageBox.information(self, "Sucesso", "Contas copiadas no formato email:senha!")
                return
        
        # Se nÃ£o existir, converter do texto atual
        text = self.verificador_completed.toPlainText()
        if text:
            lines = []
            for line in text.strip().split('\n'):
                line = line.strip()
                if line:
                    # Converter para formato simples email:senha
                    if '|' in line:
                        parts = line.split('|')
                        if len(parts) >= 2:
                            lines.append(f"{parts[0].strip()}:{parts[1].strip()}")
                    elif ':' in line:
                        lines.append(line)
            
            if lines:
                simple_text = '\n'.join(lines)
                QApplication.clipboard().setText(simple_text)
                QMessageBox.information(self, "Sucesso", "Contas copiadas no formato email:senha!")
                return
        
        QMessageBox.warning(self, "Aviso", "Nenhuma conta para copiar!")
    
    def copy_verificador_failed(self):
        """Copia as contas com assinatura falha"""

        text = self.verificador_failed.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Sucesso", "Contas com assinatura FALHA copiadas!")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhuma conta para copiar!")
    
    def clear_verificador_completed(self):
        """Limpa as contas com assinatura ativa"""
        self.verificador_completed.clear()
        for filename in ('verificador_completed.txt', 'verificador_completed_simples.txt'):
            filepath = os.path.join(self.bot_path, 'data', filename)
            if os.path.exists(filepath):
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write('')
        self.append_console("[VERIFICADOR] Contas COMPLETED limpas")
    
    def clear_verificador_failed(self):
        """Limpa as contas com assinatura falha"""
        self.verificador_failed.clear()
        for filename in (
            'verificador_failed.txt',
            'verificador_login_failed.txt',
            'verificador_no_payment.txt',
            'verificador_invalid_email.txt',
            'verificador_rate_limited.txt',
        ):
            filepath = os.path.join(self.bot_path, 'data', filename)
            if os.path.exists(filepath):
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write('')
        self.append_console("[VERIFICADOR] Contas FAILED limpas")
    
    # ========== OUTRAS FUNÃ‡Ã•ES ==========
    
    def on_multi_browser_changed(self, state):
        """Callback quando o checkbox de mÃºltiplos navegadores muda"""
        if state == Qt.Checked:
            self.num_browsers_spin.setEnabled(True)
            self.browsers_info_label.setText(f"({self.num_browsers_spin.value()} navegadores = {self.num_browsers_spin.value()}x mais rÃ¡pido)")
        else:
            self.num_browsers_spin.setEnabled(False)
            self.num_browsers_spin.setValue(1)
            self.browsers_info_label.setText("(1 navegador - modo seguro)")
    
    def on_proxy_enabled_changed(self, state):
        """Callback quando o checkbox de proxy muda"""
        enabled = state == Qt.Checked
        self.proxy_string_edit.setEnabled(enabled)
        self.unique_ip_check.setEnabled(enabled)
    
    def load_proxy_config(self):
        """Carrega configuraÃ§Ã£o de proxy salva"""
        config_path = os.path.join(self.bot_path, 'data', 'proxy_config.json')
        if os.path.exists(config_path):
            try:
                with open(config_path, 'r', encoding='utf-8') as f:
                    config = json.load(f)
                    self.proxy_enabled_check.setChecked(config.get('enabled', False))
                    self.proxy_string_edit.setText(config.get('full_string', ''))
                    self.unique_ip_check.setChecked(config.get('unique_ip', True))
                    self.proxy_config = config
            except Exception as e:
                print(f"Erro ao carregar config de proxy: {e}")
    
    def save_proxy_config(self):
        """Salva configuraÃ§Ã£o de proxy"""
        proxy_string = self.proxy_string_edit.text().strip()
        
        # Parsear a string
        parts = proxy_string.split(':') if proxy_string else []
        
        self.proxy_config = {
            'enabled': self.proxy_enabled_check.isChecked(),
            'full_string': proxy_string,
            'host': parts[0] if len(parts) >= 1 else '',
            'port': int(parts[1]) if len(parts) >= 2 and parts[1].isdigit() else 0,
            'username': parts[2] if len(parts) >= 3 else '',
            'password': parts[3] if len(parts) >= 4 else '',
            'type': 'http',
            'country': 'BR',
            'unique_ip': self.unique_ip_check.isChecked()
        }
        
        config_path = os.path.join(self.bot_path, 'data', 'proxy_config.json')
        os.makedirs(os.path.dirname(config_path), exist_ok=True)
        
        with open(config_path, 'w', encoding='utf-8') as f:
            json.dump(self.proxy_config, f, indent=2)
        
        QMessageBox.information(self, "Sucesso", "ConfiguraÃ§Ã£o de proxy salva!")
        self.append_console("[PROXY] ConfiguraÃ§Ã£o de proxy salva")
        if self.proxy_config['enabled']:
            self.append_console(f"[PROXY] Host: {self.proxy_config['host']}:{self.proxy_config['port']}")
            self.append_console(f"[PROXY] IP Ãºnico por conta: {'Ativado' if self.proxy_config['unique_ip'] else 'Desativado'}")
    
    def test_proxy(self):
        """Testa a conexÃ£o com o proxy"""
        if not self.proxy_enabled_check.isChecked():
            QMessageBox.warning(self, "Aviso", "Habilite o proxy primeiro!")
            return
        
        proxy_string = self.proxy_string_edit.text().strip()
        if not proxy_string:
            QMessageBox.warning(self, "Aviso", "Informe a string do proxy!")
            return
        
        parts = proxy_string.split(':')
        if len(parts) < 2:
            QMessageBox.warning(self, "Aviso", "Formato de proxy invÃ¡lido!")
            return
        
        host = parts[0]
        try:
            port = int(parts[1])
        except ValueError:
            QMessageBox.warning(self, "Aviso", "Porta invÃ¡lida!")
            return
        
        self.append_console(f"[PROXY] Testando conexÃ£o com {host}:{port}...")
        
        # Teste simples de conexÃ£o
        import socket
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(10)
            result = sock.connect_ex((host, port))
            sock.close()
            
            if result == 0:
                self.append_console(f"[PROXY] âœ… ConexÃ£o com {host}:{port} bem sucedida!")
                QMessageBox.information(self, "Sucesso", f"Proxy {host}:{port} estÃ¡ acessÃ­vel!")
            else:
                self.append_console(f"[PROXY] âŒ NÃ£o foi possÃ­vel conectar a {host}:{port}")
                QMessageBox.warning(self, "Erro", f"NÃ£o foi possÃ­vel conectar ao proxy {host}:{port}")
        except Exception as e:
            self.append_console(f"[PROXY] âŒ Erro ao testar proxy: {str(e)}")
            QMessageBox.critical(self, "Erro", f"Erro ao testar proxy:\n{str(e)}")
    
    def load_files(self):
        """Carrega os arquivos de contas e cartÃµes"""
        # Carregar contas
        contas_path = os.path.join(self.bot_path, 'data', 'contas.txt')
        if os.path.exists(contas_path):
            with open(contas_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
                self.accounts_edit.setText('\n'.join(lines))
        
        # Carregar cartÃµes
        cartoes_path = os.path.join(self.bot_path, 'data', 'cartoes.txt')
        if os.path.exists(cartoes_path):
            with open(cartoes_path, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
                self.cards_edit.setText('\n'.join(lines))
        
        self.update_stats()
        self.load_results()
        self.load_verificador_results()
    
    def load_verificador_results(self):
        """Carrega os resultados do verificador"""
        if hasattr(self, "verificador_completed") and hasattr(self, "verificador_failed"):
            self.verificador_results(VerificadorThread(self.bot_path, []).read_results())
    
    def load_results(self):
        """Carrega os resultados - OTIMIZADO v9.1
        
        OtimizaÃ§Ãµes:
        - Limita quantidade de linhas exibidas para evitar travamentos
        - Leitura otimizada de arquivos grandes
        - AtualizaÃ§Ã£o de UI desabilitada durante processamento
        """
        # Limite mÃ¡ximo de linhas a exibir nos campos de texto
        MAX_DISPLAY_LINES = 500
        
        data_path = os.path.join(self.bot_path, 'data')
        
        def read_file_optimized(filepath, max_lines=MAX_DISPLAY_LINES):
            """LÃª arquivo de forma otimizada, limitando linhas"""
            if not os.path.exists(filepath):
                return '', 0
            
            try:
                with open(filepath, 'r', encoding='utf-8') as f:
                    lines = [l.strip() for l in f if l.strip()]
                    total_count = len(lines)
                    
                    if total_count > max_lines:
                        # Mostrar apenas as Ãºltimas linhas + aviso
                        display_lines = lines[-max_lines:]
                        header = f"# ... ({total_count - max_lines} linhas anteriores ocultas)\n"
                        return header + '\n'.join(display_lines), total_count
                    else:
                        return '\n'.join(lines), total_count
            except Exception:
                return '', 0
        
        # Desabilitar atualizaÃ§Ãµes visuais para performance
        self.premium_edit.setUpdatesEnabled(False)
        self.cards_approved_edit.setUpdatesEnabled(False)
        self.cards_rejected_edit.setUpdatesEnabled(False)
        
        try:
            # Premium
            premium_path = os.path.join(data_path, 'contas_premium.txt')
            content, premium_count = read_file_optimized(premium_path)
            self.premium_edit.setText(content)
            
            # Falhas (apenas contar, nÃ£o exibir)
            failed_count = 0
            for filename in ['contas_sem_pagamento.txt', 'contas_login_falhou.txt', 'contas_sem_cartao.txt']:
                filepath = os.path.join(data_path, filename)
                if os.path.exists(filepath):
                    try:
                        with open(filepath, 'r', encoding='utf-8') as f:
                            failed_count += sum(1 for l in f if l.strip())
                    except Exception:
                        pass
            
            # CartÃµes Aprovados
            cartoes_aprovados_path = os.path.join(data_path, 'cartoes_aprovados.txt')
            content, cards_approved_count = read_file_optimized(cartoes_aprovados_path)
            self.cards_approved_edit.setText(content)
            
            # CartÃµes Reprovados
            cartoes_falhos_path = os.path.join(data_path, 'cartoes_falhos.txt')
            content, cards_rejected_count = read_file_optimized(cartoes_falhos_path)
            self.cards_rejected_edit.setText(content)
            
            # Atualizar labels
            self.stat_premium.setText(f"âœ… Premium: {premium_count}")
            self.stat_falhas.setText(f"âŒ Falhas: {failed_count}")
            self.stat_cartoes_ok.setText(f"ðŸ’³ CartÃµes Aprovados: {cards_approved_count}")
            self.stat_cartoes_fail.setText(f"ðŸ’³ CartÃµes Reprovados: {cards_rejected_count}")
        finally:
            # Reabilitar atualizaÃ§Ãµes visuais
            self.premium_edit.setUpdatesEnabled(True)
            self.cards_approved_edit.setUpdatesEnabled(True)
            self.cards_rejected_edit.setUpdatesEnabled(True)
        
        self.update_stats()
    
    def update_stats(self):
        """Atualiza as estatÃ­sticas"""
        contas_count = len([l for l in self.accounts_edit.toPlainText().split('\n') if l.strip()])
        self.contas_label.setText(f"ðŸ“§ Contas: {contas_count}")
        
        cartoes_count = len([l for l in self.cards_edit.toPlainText().split('\n') if l.strip()])
        self.cartoes_label.setText(f"ðŸ’³ CartÃµes: {cartoes_count}")
        
        premium_count = len([l for l in self.premium_edit.toPlainText().split('\n') if l.strip()])
        self.premium_label.setText(f"âœ… Premium: {premium_count}")
    
    def save_accounts(self):
        """Salva as contas no arquivo"""
        contas_path = os.path.join(self.bot_path, 'data', 'contas.txt')
        os.makedirs(os.path.dirname(contas_path), exist_ok=True)
        
        with open(contas_path, 'w', encoding='utf-8') as f:
            f.write(self.accounts_edit.toPlainText())
        
        self.update_stats()
        QMessageBox.information(self, "Sucesso", "Contas salvas com sucesso!")
    
    def save_cards(self):
        """Salva os cartÃµes no arquivo"""
        cartoes_path = os.path.join(self.bot_path, 'data', 'cartoes.txt')
        os.makedirs(os.path.dirname(cartoes_path), exist_ok=True)
        
        with open(cartoes_path, 'w', encoding='utf-8') as f:
            f.write(self.cards_edit.toPlainText())
        
        self.update_stats()
        QMessageBox.information(self, "Sucesso", "CartÃµes salvos com sucesso!")
    
    def load_accounts_file(self):
        """Carrega contas de um arquivo externo"""
        filepath, _ = QFileDialog.getOpenFileName(self, "Carregar Contas", "", "Text Files (*.txt);;All Files (*)")
        if filepath:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
                current = self.accounts_edit.toPlainText()
                if current.strip():
                    self.accounts_edit.setText(current + '\n' + '\n'.join(lines))
                else:
                    self.accounts_edit.setText('\n'.join(lines))
            self.update_stats()
    
    def load_cards_file(self):
        """Carrega cartÃµes de um arquivo externo"""
        filepath, _ = QFileDialog.getOpenFileName(self, "Carregar CartÃµes", "", "Text Files (*.txt);;All Files (*)")
        if filepath:
            with open(filepath, 'r', encoding='utf-8') as f:
                content = f.read()
                lines = [l for l in content.split('\n') if l.strip() and not l.strip().startswith('#')]
                current = self.cards_edit.toPlainText()
                if current.strip():
                    self.cards_edit.setText(current + '\n' + '\n'.join(lines))
                else:
                    self.cards_edit.setText('\n'.join(lines))
            self.update_stats()
    
    def copy_premium(self):
        """Copia as contas premium"""

        text = self.premium_edit.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Sucesso", "Contas premium copiadas!")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhuma conta premium para copiar!")
    
    def copy_premium_simple(self):
        """Copia as contas premium no formato email:senha"""

        
        simple_path = os.path.join(self.bot_path, 'data', 'contas_premium_simples.txt')
        if os.path.exists(simple_path):
            with open(simple_path, 'r', encoding='utf-8') as f:
                text = f.read()
            if text.strip():
                QApplication.clipboard().setText(text)
                QMessageBox.information(self, "Sucesso", "Contas copiadas no formato email:senha!")
                return
        
        QMessageBox.warning(self, "Aviso", "Nenhuma conta para copiar!")
    
    def clear_premium(self):
        """Limpa as contas premium"""
        reply = QMessageBox.question(
            self, "Confirmar",
            "Tem certeza que deseja limpar todas as contas premium?\n\nEsta aÃ§Ã£o nÃ£o pode ser desfeita!",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.premium_edit.clear()
            
            # Limpar arquivos
            data_path = os.path.join(self.bot_path, 'data')
            for filename in ['contas_premium.txt', 'contas_premium_simples.txt']:
                filepath = os.path.join(data_path, filename)
                if os.path.exists(filepath):
                    with open(filepath, 'w', encoding='utf-8') as f:
                        f.write('')
            
            self.load_results()
            self.append_console("[SISTEMA] Contas premium limpas")
    
    def copy_cards_approved(self):
        """Copia os cartÃµes aprovados"""

        text = self.cards_approved_edit.toPlainText()
        if text:
            QApplication.clipboard().setText(text)
            QMessageBox.information(self, "Sucesso", "CartÃµes aprovados copiados!")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhum cartÃ£o aprovado para copiar!")
    
    def clear_cards_approved(self):
        """Limpa os cartÃµes aprovados"""
        reply = QMessageBox.question(
            self, "Confirmar",
            "Tem certeza que deseja limpar todos os cartÃµes aprovados?\n\nEsta aÃ§Ã£o nÃ£o pode ser desfeita!",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.cards_approved_edit.clear()
            
            filepath = os.path.join(self.bot_path, 'data', 'cartoes_aprovados.txt')
            if os.path.exists(filepath):
                with open(filepath, 'w', encoding='utf-8') as f:
                    f.write('')
            
            self.load_results()
            self.append_console("[SISTEMA] CartÃµes aprovados limpos")
    
    def clear_cards_rejected(self):
        """Limpa os cartÃµes reprovados"""
        self.cards_rejected_edit.clear()
        
        filepath = os.path.join(self.bot_path, 'data', 'cartoes_falhos.txt')
        if os.path.exists(filepath):
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write('')
        
        self.load_results()
        self.append_console("[SISTEMA] CartÃµes reprovados limpos")
    
    def install_dependencies(self):
        """Instala as dependÃªncias do Node.js"""
        reply = QMessageBox.question(
            self, "Instalar DependÃªncias",
            "Isso irÃ¡ executar 'npm install' para instalar as dependÃªncias do bot.\n\n"
            "Certifique-se de que o Node.js estÃ¡ instalado.\n\n"
            "Deseja continuar?",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            self.install_deps_btn.setEnabled(False)
            self.install_deps_btn.setText("â³ Instalando...")
            self.start_btn.setEnabled(False)
            
            self.install_thread = InstallDependenciesThread(self.bot_path)
            self.install_thread.output_signal.connect(self.append_console)
            self.install_thread.finished_signal.connect(self.install_finished)
            self.install_thread.start()
    
    def install_finished(self, success, message):
        """Chamado quando a instalaÃ§Ã£o termina"""
        self.start_btn.setEnabled(True)
        
        if success:
            self.dependencies_installed = True
            self.update_dependency_status()
            QMessageBox.information(self, "Sucesso", message)
        else:
            self.install_deps_btn.setEnabled(True)
            self.install_deps_btn.setText("ðŸ“¦ Instalar DependÃªncias")
            QMessageBox.critical(self, "Erro", message)
    
    def start_bot(self):
        """Inicia o bot Crunchyroll"""
        if not self.accounts_edit.toPlainText().strip():
            QMessageBox.warning(self, "Aviso", "Adicione contas antes de iniciar!")
            return
        
        if not self.cards_edit.toPlainText().strip():
            QMessageBox.warning(self, "Aviso", "Adicione cartÃµes antes de iniciar!")
            return
        
        if not self.dependencies_installed:
            reply = QMessageBox.question(
                self, "DependÃªncias nÃ£o instaladas",
                "As dependÃªncias do Node.js nÃ£o estÃ£o instaladas.\n\n"
                "Deseja instalar agora?",
                QMessageBox.Yes | QMessageBox.No
            )
            if reply == QMessageBox.Yes:
                self.install_dependencies()
            return
        
        # Salvar arquivos
        self.save_accounts()
        self.save_cards()
        
        # NÃºmero de workers
        num_workers = self.num_browsers_spin.value() if self.multi_browser_checkbox.isChecked() else 1
        
        # Iniciar thread
        self.bot_thread = CrunchyrollBotThread(self.bot_path, num_workers, self.proxy_config)
        self.bot_thread.output_signal.connect(self.append_console)
        self.bot_thread.finished_signal.connect(self.bot_finished)
        self.bot_thread.error_signal.connect(self.bot_error)
        self.bot_thread.dependencies_missing.connect(self.on_dependencies_missing)
        self.bot_thread.start()
        
        # Atualizar UI
        self.start_btn.setEnabled(False)
        self.stop_btn.setEnabled(True)
        self.skip_btn.setEnabled(True)
        self.multi_browser_checkbox.setEnabled(False)
        self.num_browsers_spin.setEnabled(False)
        self.status_label.setText(f"ðŸŸ¢ Bot em execuÃ§Ã£o ({num_workers} navegador(es))...")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #10b981;")
        
        self.append_console("[SISTEMA] Bot iniciado!")
        self.append_console(f"[SISTEMA] Usando {num_workers} navegador(es) simultÃ¢neo(s)")
        
        if self.proxy_config.get('enabled'):
            self.append_console(f"[PROXY] Proxy habilitado: {self.proxy_config.get('host')}:{self.proxy_config.get('port')}")
            self.append_console(f"[PROXY] IP Ãºnico por conta: {'Ativado' if self.proxy_config.get('unique_ip', True) else 'Desativado'}")
    
    def on_dependencies_missing(self):
        """Chamado quando as dependÃªncias estÃ£o faltando"""
        self.dependencies_installed = False
        self.update_dependency_status()
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)
        self.multi_browser_checkbox.setEnabled(True)
        self.num_browsers_spin.setEnabled(self.multi_browser_checkbox.isChecked())
        self.status_label.setText("âš ï¸ DependÃªncias faltando")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #f43f5e;")
    
    def stop_bot(self):
        """Para o bot Crunchyroll"""
        if self.bot_thread:
            self.bot_thread.stop()
            self.append_console("[SISTEMA] Parando bot...")
    
    def bot_finished(self, return_code):
        """Chamado quando o bot termina"""
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)
        self.multi_browser_checkbox.setEnabled(True)
        self.num_browsers_spin.setEnabled(self.multi_browser_checkbox.isChecked())
        self.status_label.setText("â¸ï¸ Bot parado")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #94a3b8;")
        
        self.append_console(f"[SISTEMA] Bot finalizado (cÃ³digo: {return_code})")
        self.load_results()
    
    def bot_error(self, error):
        """Chamado quando ocorre erro no bot"""
        self.start_btn.setEnabled(True)
        self.stop_btn.setEnabled(False)
        self.skip_btn.setEnabled(False)
        self.multi_browser_checkbox.setEnabled(True)
        self.num_browsers_spin.setEnabled(self.multi_browser_checkbox.isChecked())
        self.status_label.setText("âŒ Erro no bot")
        self.status_label.setStyleSheet("font-size: 16px; font-weight: bold; color: #da3633;")
        
        self.append_console(f"[ERRO] {error}")
        QMessageBox.critical(self, "Erro", error)
    
    def skip_account(self):
        """Envia comando para pular a conta atual"""
        if self.bot_thread and self.bot_thread.process:
            try:
                if sys.platform == 'win32':
                    self.bot_thread.process.stdin.write(b's')
                    self.bot_thread.process.stdin.flush()
                else:
                    import signal
                    self.bot_thread.process.send_signal(signal.SIGUSR1)
                
                self.append_console("[SISTEMA] Comando para pular conta enviado!")
            except Exception as e:
                self.append_console(f"[AVISO] NÃ£o foi possÃ­vel enviar comando: {str(e)}")
        else:
            self.append_console("[AVISO] Bot nÃ£o estÃ¡ em execuÃ§Ã£o")
    
    def append_console(self, text):
        """Adiciona texto ao console avanÃ§ado - OTIMIZADO v9.1
        
        OtimizaÃ§Ãµes:
        - Throttling de load_results para evitar chamadas excessivas
        - Evita travamentos quando muitos logs chegam rapidamente
        """
        import time
        
        self.advanced_console.append(text)
        
        # Recarregar dados se necessÃ¡rio (com throttling)
        text_lower = text.lower()
        if any(keyword in text_lower for keyword in [
            'cartao removido', 'cartÃ£o removido',
            'conta processada', 'sucesso', 'aprovado', 'premium',
            'completed', 'failed', 'verificador'
        ]):
            self._schedule_results_update()
    
    def _schedule_results_update(self):
        """Agenda atualizaÃ§Ã£o de resultados com throttling - OTIMIZADO v9.1"""
        import time
        
        current_time = time.time() * 1000  # em ms
        time_since_last = current_time - self._last_results_update
        
        if time_since_last >= self.RESULTS_UPDATE_INTERVAL:
            # Pode atualizar imediatamente
            self._last_results_update = current_time
            self._do_results_update()
        elif not self._results_update_pending:
            # Agendar atualizaÃ§Ã£o futura
            self._results_update_pending = True
            wait_time = int(self.RESULTS_UPDATE_INTERVAL - time_since_last)
            QTimer.singleShot(wait_time, self._do_results_update)
    
    def _do_results_update(self):
        """Executa a atualizaÃ§Ã£o de resultados"""
        import time
        
        self._results_update_pending = False
        self._last_results_update = time.time() * 1000
        
        # Executar atualizaÃ§Ãµes
        self.load_results()
        self.load_verificador_results()

    # ========== FUNÃ‡Ã•ES DE ATUALIZAÃ‡ÃƒO (REMOVER UTILIZADOS) ==========
    
    def refresh_accounts_remove_used(self):
        """
        Remove contas jÃ¡ utilizadas da lista.
        Verifica nos arquivos de resultados quais contas jÃ¡ foram processadas:
        - contas_premium.txt (aprovadas)
        - contas_premium_simples.txt (aprovadas simples)
        - contas_criadas.txt (criadas)
        - contas_login_sucesso.txt (login OK)
        - contas_login_falhou.txt (login falhou)
        - contas_sem_cartao.txt (sem cartÃ£o)
        - contas_sem_pagamento.txt (sem pagamento)
        """
        data_path = os.path.join(self.bot_path, 'data')
        
        # Coletar todos os emails jÃ¡ utilizados
        emails_utilizados = set()
        
        arquivos_resultados = [
            'contas_premium.txt',
            'contas_premium_simples.txt',
            'contas_criadas.txt',
            'contas_login_sucesso.txt',
            'contas_login_falhou.txt',
            'contas_sem_cartao.txt',
            'contas_sem_pagamento.txt'
        ]
        
        for arquivo in arquivos_resultados:
            filepath = os.path.join(data_path, arquivo)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        for linha in f:
                            linha = linha.strip()
                            if linha and not linha.startswith('#'):
                                # Extrair email da linha (pode estar em vÃ¡rios formatos)
                                # Formatos: email:senha, email|senha, email:senha|cartao|..., etc.
                                email = None
                                if '@' in linha:
                                    # Encontrar o email na linha
                                    partes = re.split(r'[:|,\s]+', linha)
                                    for parte in partes:
                                        if '@' in parte:
                                            email = parte.lower().strip()
                                            break
                                
                                if email:
                                    emails_utilizados.add(email)
                except Exception as e:
                    self.append_console(f"[AVISO] Erro ao ler {arquivo}: {str(e)}")
        
        if not emails_utilizados:
            QMessageBox.information(self, "InformaÃ§Ã£o", "Nenhuma conta utilizada encontrada nos arquivos de resultados.")
            return
        
        # Filtrar contas atuais
        contas_atuais = self.accounts_edit.toPlainText().strip().split('\n')
        contas_filtradas = []
        contas_removidas = 0
        
        for conta in contas_atuais:
            conta = conta.strip()
            if not conta or conta.startswith('#'):
                continue
            
            # Extrair email da conta
            email = None
            partes = re.split(r'[:|]+', conta)
            if len(partes) >= 1 and '@' in partes[0]:
                email = partes[0].lower().strip()
            
            if email and email in emails_utilizados:
                contas_removidas += 1
                self.append_console(f"[ATUALIZAR] Conta removida: {email}")
            else:
                contas_filtradas.append(conta)
        
        # Atualizar o campo de texto
        self.accounts_edit.setText('\n'.join(contas_filtradas))
        self.update_stats()
        
        # Mostrar resultado
        msg = f"AtualizaÃ§Ã£o concluÃ­da!\n\n"
        msg += f"â€¢ Contas removidas: {contas_removidas}\n"
        msg += f"â€¢ Contas restantes: {len(contas_filtradas)}\n\n"
        msg += f"Emails Ãºnicos encontrados nos resultados: {len(emails_utilizados)}"
        
        QMessageBox.information(self, "AtualizaÃ§Ã£o de Contas", msg)
        self.append_console(f"[ATUALIZAR] {contas_removidas} contas removidas, {len(contas_filtradas)} restantes")
    
    def refresh_cards_remove_used(self):
        """
        Remove cartÃµes jÃ¡ utilizados da lista.
        Verifica nos arquivos de resultados quais cartÃµes jÃ¡ foram processados:
        - cartoes_aprovados.txt (aprovados)
        - cartoes_falhos.txt (reprovados)
        """
        data_path = os.path.join(self.bot_path, 'data')
        
        # Coletar todos os nÃºmeros de cartÃ£o jÃ¡ utilizados
        cartoes_utilizados = set()
        
        arquivos_resultados = [
            'cartoes_aprovados.txt',
            'cartoes_falhos.txt'
        ]
        
        for arquivo in arquivos_resultados:
            filepath = os.path.join(data_path, arquivo)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        for linha in f:
                            linha = linha.strip()
                            if linha and not linha.startswith('#'):
                                # Extrair nÃºmero do cartÃ£o (primeiros 16 dÃ­gitos ou atÃ© o primeiro separador)
                                partes = re.split(r'[|:,\s]+', linha)
                                if partes:
                                    # O nÃºmero do cartÃ£o Ã© geralmente o primeiro campo
                                    numero = partes[0].strip()
                                    # Remover caracteres nÃ£o numÃ©ricos
                                    numero_limpo = re.sub(r'\D', '', numero)
                                    if len(numero_limpo) >= 13:  # CartÃµes tÃªm pelo menos 13 dÃ­gitos
                                        cartoes_utilizados.add(numero_limpo)
                except Exception as e:
                    self.append_console(f"[AVISO] Erro ao ler {arquivo}: {str(e)}")
        
        if not cartoes_utilizados:
            QMessageBox.information(self, "InformaÃ§Ã£o", "Nenhum cartÃ£o utilizado encontrado nos arquivos de resultados.")
            return
        
        # Filtrar cartÃµes atuais
        cartoes_atuais = self.cards_edit.toPlainText().strip().split('\n')
        cartoes_filtrados = []
        cartoes_removidos = 0
        
        for cartao in cartoes_atuais:
            cartao = cartao.strip()
            if not cartao or cartao.startswith('#'):
                continue
            
            # Extrair nÃºmero do cartÃ£o
            partes = re.split(r'[|:]+', cartao)
            if partes:
                numero = partes[0].strip()
                numero_limpo = re.sub(r'\D', '', numero)
                
                if numero_limpo in cartoes_utilizados:
                    cartoes_removidos += 1
                    # Mostrar apenas os Ãºltimos 4 dÃ­gitos por seguranÃ§a
                    self.append_console(f"[ATUALIZAR] CartÃ£o removido: ****{numero_limpo[-4:]}")
                else:
                    cartoes_filtrados.append(cartao)
            else:
                cartoes_filtrados.append(cartao)
        
        # Atualizar o campo de texto
        self.cards_edit.setText('\n'.join(cartoes_filtrados))
        self.update_stats()
        
        # Mostrar resultado
        msg = f"AtualizaÃ§Ã£o concluÃ­da!\n\n"
        msg += f"â€¢ CartÃµes removidos: {cartoes_removidos}\n"
        msg += f"â€¢ CartÃµes restantes: {len(cartoes_filtrados)}\n\n"
        msg += f"CartÃµes Ãºnicos encontrados nos resultados: {len(cartoes_utilizados)}"
        
        QMessageBox.information(self, "AtualizaÃ§Ã£o de CartÃµes", msg)
        self.append_console(f"[ATUALIZAR] {cartoes_removidos} cartÃµes removidos, {len(cartoes_filtrados)} restantes")

    # ========== FUNÃ‡Ã•ES DE ATUALIZAÃ‡ÃƒO AUTOMÃTICA v9.2 ==========
    
    def _setup_auto_refresh_timer(self):
        """Configura o timer de atualizaÃ§Ã£o automÃ¡tica"""
        self._auto_refresh_timer = QTimer(self)
        self._auto_refresh_timer.timeout.connect(self._auto_refresh_callback)
        self._auto_refresh_timer.start(self.AUTO_REFRESH_INTERVAL)
        self.append_console(f"[SISTEMA] AtualizaÃ§Ã£o automÃ¡tica configurada: a cada {self.AUTO_REFRESH_INTERVAL // 1000} segundos")
    
    def _auto_refresh_callback(self):
        """Callback do timer de atualizaÃ§Ã£o automÃ¡tica"""
        if not self._auto_refresh_enabled:
            return
        
        # SÃ³ atualizar se o bot estiver rodando
        if self.bot_thread and self.bot_thread.isRunning():
            self._perform_auto_refresh()
    
    def _perform_auto_refresh(self):
        """Executa a atualizaÃ§Ã£o automÃ¡tica de cartÃµes e contas"""
        try:
            # Atualizar silenciosamente (sem mensagens de popup)
            self._auto_refresh_cards_silent()
            self._auto_refresh_accounts_silent()
            
            # Recarregar resultados
            self.load_results()
            
            # Log discreto
            timestamp = datetime.now().strftime('%H:%M:%S')
            self.append_console(f"[AUTO-REFRESH] {timestamp} - Listas atualizadas automaticamente")
        except Exception as e:
            self.append_console(f"[AUTO-REFRESH] Erro na atualizaÃ§Ã£o automÃ¡tica: {str(e)}")
    
    def _auto_refresh_cards_silent(self):
        """Remove cartÃµes jÃ¡ utilizados silenciosamente (sem popup)"""
        data_path = os.path.join(self.bot_path, 'data')
        
        # Coletar todos os nÃºmeros de cartÃ£o jÃ¡ utilizados
        cartoes_utilizados = set()
        
        arquivos_resultados = ['cartoes_aprovados.txt', 'cartoes_falhos.txt']
        
        for arquivo in arquivos_resultados:
            filepath = os.path.join(data_path, arquivo)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        for linha in f:
                            linha = linha.strip()
                            if linha and not linha.startswith('#'):
                                partes = re.split(r'[|:,\s]+', linha)
                                if partes:
                                    numero = partes[0].strip()
                                    numero_limpo = re.sub(r'\D', '', numero)
                                    if len(numero_limpo) >= 13:
                                        cartoes_utilizados.add(numero_limpo)
                except Exception:
                    pass
        
        if not cartoes_utilizados:
            return
        
        # Filtrar cartÃµes atuais
        cartoes_atuais = self.cards_edit.toPlainText().strip().split('\n')
        cartoes_filtrados = []
        cartoes_removidos = 0
        
        for cartao in cartoes_atuais:
            cartao = cartao.strip()
            if not cartao or cartao.startswith('#'):
                continue
            
            partes = re.split(r'[|:]+', cartao)
            if partes:
                numero = partes[0].strip()
                numero_limpo = re.sub(r'\D', '', numero)
                
                if numero_limpo in cartoes_utilizados:
                    cartoes_removidos += 1
                else:
                    cartoes_filtrados.append(cartao)
            else:
                cartoes_filtrados.append(cartao)
        
        if cartoes_removidos > 0:
            self.cards_edit.setText('\n'.join(cartoes_filtrados))
            self.update_stats()
            self.append_console(f"[AUTO-REFRESH] {cartoes_removidos} cartÃµes removidos automaticamente")
    
    def _auto_refresh_accounts_silent(self):
        """Remove contas jÃ¡ utilizadas silenciosamente (sem popup)"""
        data_path = os.path.join(self.bot_path, 'data')
        
        # Coletar todos os emails jÃ¡ utilizados
        emails_utilizados = set()
        
        arquivos_resultados = [
            'contas_premium.txt', 'contas_premium_simples.txt', 'contas_criadas.txt',
            'contas_login_sucesso.txt', 'contas_login_falhou.txt',
            'contas_sem_cartao.txt', 'contas_sem_pagamento.txt'
        ]
        
        for arquivo in arquivos_resultados:
            filepath = os.path.join(data_path, arquivo)
            if os.path.exists(filepath):
                try:
                    with open(filepath, 'r', encoding='utf-8') as f:
                        for linha in f:
                            linha = linha.strip()
                            if linha and not linha.startswith('#'):
                                if '@' in linha:
                                    partes = re.split(r'[:|,\s]+', linha)
                                    for parte in partes:
                                        if '@' in parte:
                                            emails_utilizados.add(parte.lower().strip())
                                            break
                except Exception:
                    pass
        
        if not emails_utilizados:
            return
        
        # Filtrar contas atuais
        contas_atuais = self.accounts_edit.toPlainText().strip().split('\n')
        contas_filtradas = []
        contas_removidas = 0
        
        for conta in contas_atuais:
            conta = conta.strip()
            if not conta or conta.startswith('#'):
                continue
            
            partes = re.split(r'[:|]+', conta)
            if len(partes) >= 1 and '@' in partes[0]:
                email = partes[0].lower().strip()
                if email in emails_utilizados:
                    contas_removidas += 1
                else:
                    contas_filtradas.append(conta)
            else:
                contas_filtradas.append(conta)
        
        if contas_removidas > 0:
            self.accounts_edit.setText('\n'.join(contas_filtradas))
            self.update_stats()
            self.append_console(f"[AUTO-REFRESH] {contas_removidas} contas removidas automaticamente")
    
    def toggle_auto_refresh(self, enabled):
        """Habilita/desabilita a atualizaÃ§Ã£o automÃ¡tica"""
        self._auto_refresh_enabled = enabled
        status = "habilitada" if enabled else "desabilitada"
        self.append_console(f"[SISTEMA] AtualizaÃ§Ã£o automÃ¡tica {status}")
    
    def set_auto_refresh_interval(self, interval_seconds):
        """Define o intervalo de atualizaÃ§Ã£o automÃ¡tica em segundos"""
        if interval_seconds < 30:
            interval_seconds = 30  # MÃ­nimo de 30 segundos
        
        self.AUTO_REFRESH_INTERVAL = interval_seconds * 1000
        
        if self._auto_refresh_timer:
            self._auto_refresh_timer.stop()
            self._auto_refresh_timer.start(self.AUTO_REFRESH_INTERVAL)
        
        self.append_console(f"[SISTEMA] Intervalo de atualizaÃ§Ã£o automÃ¡tica: {interval_seconds} segundos")


