﻿#!/usr/bin/env python3
"""
Aplicação Principal - Coletor de Dados Telegram
Versão 11.0 - Interface Reorganizada + Acesso Rápido às Ferramentas
"""
import sys
import os
import asyncio
import json
import re
from datetime import datetime
from PyQt5.QtWidgets import (
    QApplication, QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QPushButton, QLabel, QMessageBox, QDialog, QFormLayout, QLineEdit,
    QSpinBox, QCheckBox, QScrollArea, QTableWidget, QTableWidgetItem,
    QHeaderView, QProgressBar, QTabWidget, QGroupBox, QComboBox,
    QFileDialog, QStatusBar, QFrame, QListWidget, QSizePolicy,
    QListWidgetItem, QTextEdit, QSplitter, QRadioButton, QButtonGroup,
    QSystemTrayIcon, QMenu, QAction, QPlainTextEdit
)
from PyQt5.QtWidgets import QShortcut, QGridLayout
from PyQt5.QtCore import Qt, pyqtSignal, QThread, QTimer, QSettings
from PyQt5.QtGui import QFont, QIcon, QPalette, QColor, QPixmap, QPainter, QBrush, QLinearGradient, QPen, QKeySequence
import ctypes

from app.core.clipboard_service import set_clipboard_text
from app.core.error_service import install_crash_logger as core_install_crash_logger, log_exception
from database import DatabaseManager
from config_manager import ConfigManager
from settings import settings, BASE_DIR
from account_manager import GerenciadorContas
from card_generator import CardGenerator
from address_generator import AddressGenerator
from account_formatter import AccountFormatter
from data_organizer import DataOrganizer
from extra_tools import ValidadorWidget, GeradorFakeWidget, BuscaAvancadaWidget, DashboardWidget
from browser_widget import BrowserWidget
from notepad_widget import NotepadWidget
from performance_widget import PerformanceWidget
from data_pro_widget import DataProWidget
from text_corrector_widget import TextCorrectorWidget
from app_hub import (
    AppDashboardWidget, GeneralSettingsWidget, GlobalSearchDialog,
    load_app_settings,
)
from ai_assistant_widget import AIAssistantWidget

# Importar widget de configurações padrão de perfis
try:
    from profile_defaults_widget import ProfileDefaultsWidget
    PROFILE_DEFAULTS_AVAILABLE = True
except ImportError:
    PROFILE_DEFAULTS_AVAILABLE = False

# Importar widget do Bot Crunchyroll
try:
    from crunchyroll_widget import CrunchyrollWidget
    CRUNCHYROLL_AVAILABLE = True
except ImportError:
    CRUNCHYROLL_AVAILABLE = False


# Importar widget do Bot Crunchyroll LOGIN
try:
    from crunchyroll_login_widget import CrunchyrollLoginWidget
    CRUNCHYROLL_LOGIN_AVAILABLE = True
except ImportError:
    CRUNCHYROLL_LOGIN_AVAILABLE = False


# Importar temas do módulo centralizado
from theme import DARK_STYLE_PRO as DARK_STYLE, LIGHT_STYLE_PRO as LIGHT_STYLE



def install_crash_logger():
    """Guarda erros fatais em arquivo para diagnosticar fechamentos silenciosos."""
    core_install_crash_logger(BASE_DIR)


class CodeInputDialog(QDialog):
    """Diálogo para entrada do código SMS do Telegram"""
    
    def __init__(self, phone: str, parent=None):
        super().__init__(parent)
        self.phone = phone
        self.code = None
        self.setWindowTitle("Código de Verificação")
        self.setModal(True)
        self.setMinimumWidth(400)
        self.setStyleSheet(DARK_STYLE)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title = QLabel("📱 Código de Verificação do Telegram")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #06b6d4;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        info = QLabel(f"Um código foi enviado para:\n{self.phone}\n\nDigite o código recebido:")
        info.setStyleSheet("color: #aaa; margin: 15px 0;")
        info.setWordWrap(True)
        info.setAlignment(Qt.AlignCenter)
        layout.addWidget(info)
        
        self.code_input = QLineEdit()
        self.code_input.setPlaceholderText("Ex: 12345")
        self.code_input.setMaxLength(10)
        self.code_input.setStyleSheet("""
            QLineEdit {
                font-size: 28px;
                font-weight: bold;
                text-align: center;
                padding: 15px;
                letter-spacing: 10px;
                background-color: #0f172a;
                border: 3px solid #06b6d4;
                border-radius: 12px;
                color: #06b6d4;
            }
        """)
        self.code_input.setAlignment(Qt.AlignCenter)
        self.code_input.returnPressed.connect(self.submit_code)
        layout.addWidget(self.code_input)
        
        layout.addSpacing(15)
        
        btn_layout = QHBoxLayout()
        
        submit_btn = QPushButton("✓ Confirmar")
        submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #06b6d4;
                color: #0f172a;
                font-size: 14px;
                padding: 12px 30px;
            }
            QPushButton:hover { background-color: #0891b2; }
        """)
        submit_btn.clicked.connect(self.submit_code)
        btn_layout.addWidget(submit_btn)
        
        cancel_btn = QPushButton("Cancelar")
        cancel_btn.setStyleSheet("""
            QPushButton {
                background-color: #f43f5e;
                padding: 12px 30px;
            }
            QPushButton:hover { background-color: #e11d48; }
        """)
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.code_input.setFocus()
    
    def submit_code(self):
        code = self.code_input.text().strip()
        if code:
            self.code = code
            self.accept()
        else:
            QMessageBox.warning(self, "Aviso", "Digite o código de verificação!")


class PasswordInputDialog(QDialog):
    """Diálogo para entrada da senha 2FA"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.password = None
        self.setWindowTitle("Autenticação 2FA")
        self.setModal(True)
        self.setMinimumWidth(400)
        self.setStyleSheet(DARK_STYLE)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title = QLabel("🔐 Autenticação de Dois Fatores")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #ff9800;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        info = QLabel("Sua conta possui 2FA.\nDigite sua senha do Telegram:")
        info.setStyleSheet("color: #aaa; margin: 15px 0;")
        info.setAlignment(Qt.AlignCenter)
        layout.addWidget(info)
        
        self.password_input = QLineEdit()
        self.password_input.setPlaceholderText("Senha 2FA")
        self.password_input.setEchoMode(QLineEdit.Password)
        self.password_input.setStyleSheet("""
            QLineEdit {
                font-size: 16px;
                padding: 12px;
                border: 3px solid #ff9800;
            }
        """)
        self.password_input.returnPressed.connect(self.submit_password)
        layout.addWidget(self.password_input)
        
        layout.addSpacing(15)
        
        btn_layout = QHBoxLayout()
        
        submit_btn = QPushButton("✓ Confirmar")
        submit_btn.setStyleSheet("""
            QPushButton {
                background-color: #ff9800;
                color: #0f172a;
                padding: 12px 30px;
            }
        """)
        submit_btn.clicked.connect(self.submit_password)
        btn_layout.addWidget(submit_btn)
        
        cancel_btn = QPushButton("Cancelar")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
        self.password_input.setFocus()
    
    def submit_password(self):
        password = self.password_input.text()
        if password:
            self.password = password
            self.accept()


class GroupManagerDialog(QDialog):
    """Diálogo para gerenciar múltiplos grupos"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Gerenciar Grupos")
        self.setModal(True)
        self.setMinimumSize(500, 400)
        self.setStyleSheet(DARK_STYLE)
        self.groups = self.load_groups()
        self.init_ui()
    
    def load_groups(self):
        """Carrega grupos salvos"""
        groups_file = BASE_DIR / 'grupos.json'
        if groups_file.exists():
            try:
                with open(groups_file, 'r') as f:
                    return json.load(f)
            except (json.JSONDecodeError, IOError, PermissionError) as e:
                print(f"Aviso: Erro ao carregar grupos: {e}")
        return [settings.default_group]
    
    def save_groups(self):
        """Salva grupos"""
        groups_file = BASE_DIR / 'grupos.json'
        with open(groups_file, 'w') as f:
            json.dump(self.groups, f)
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title = QLabel("📋 Gerenciar Grupos do Telegram")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #06b6d4;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Lista de grupos
        self.group_list = QListWidget()
        for group in self.groups:
            self.group_list.addItem(group)
        layout.addWidget(self.group_list)
        
        # Campo para adicionar
        add_layout = QHBoxLayout()
        self.new_group_input = QLineEdit()
        self.new_group_input.setPlaceholderText("Nome do grupo (ex: PuxadasTr4in)")
        add_layout.addWidget(self.new_group_input)
        
        add_btn = QPushButton("➕ Adicionar")
        add_btn.setStyleSheet("background-color: #4CAF50;")
        add_btn.clicked.connect(self.add_group)
        add_layout.addWidget(add_btn)
        
        layout.addLayout(add_layout)
        
        # Botões de ação
        btn_layout = QHBoxLayout()
        
        remove_btn = QPushButton("🗑️ Remover Selecionado")
        remove_btn.setStyleSheet("background-color: #f43f5e;")
        remove_btn.clicked.connect(self.remove_group)
        btn_layout.addWidget(remove_btn)
        
        close_btn = QPushButton("✓ Salvar e Fechar")
        close_btn.setStyleSheet("background-color: #06b6d4; color: #0f172a;")
        close_btn.clicked.connect(self.save_and_close)
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
    
    def add_group(self):
        group = self.new_group_input.text().strip()
        if group and group not in self.groups:
            self.groups.append(group)
            self.group_list.addItem(group)
            self.new_group_input.clear()
    
    def remove_group(self):
        current = self.group_list.currentItem()
        if current:
            group = current.text()
            self.groups.remove(group)
            self.group_list.takeItem(self.group_list.row(current))
    
    def save_and_close(self):
        self.save_groups()
        self.accept()


class CollectorThread(QThread):
    """Thread para executar a coleta de dados do Telegram"""
    finished = pyqtSignal(int)
    error = pyqtSignal(str)
    progress = pyqtSignal(str)
    code_requested = pyqtSignal(str)
    password_requested = pyqtSignal()
    
    def __init__(self, groups: list = None, limit: int = 2000, 
                 filtrar_idosos: bool = False, idade_maxima: int = None,
                 exigir_data_nascimento: bool = False, conta_id: int = None):
        super().__init__()
        self.groups = groups or [settings.default_group]
        self.limit = limit
        self.filtrar_idosos = filtrar_idosos
        self.idade_maxima = idade_maxima
        self.exigir_data_nascimento = exigir_data_nascimento
        self.conta_id = conta_id
        self.verification_code = None
        self.password_2fa = None
        self._code_event = asyncio.Event()
        self._password_event = asyncio.Event()
    
    def set_verification_code(self, code: str):
        self.verification_code = code
        if hasattr(self, '_loop') and self._loop:
            self._loop.call_soon_threadsafe(self._code_event.set)
    
    def set_password(self, password: str):
        self.password_2fa = password
        if hasattr(self, '_loop') and self._loop:
            self._loop.call_soon_threadsafe(self._password_event.set)
    
    def run(self):
        try:
            self.progress.emit("Iniciando coletor...")
            
            def progress_callback(msg):
                self.progress.emit(msg)
            
            self._loop = asyncio.new_event_loop()
            asyncio.set_event_loop(self._loop)
            
            self._code_event = asyncio.Event()
            self._password_event = asyncio.Event()
            
            async def code_callback():
                self.progress.emit("📱 Aguardando código de verificação...")
                self.code_requested.emit(settings.telegram_phone)
                await self._code_event.wait()
                return self.verification_code
            
            async def password_callback():
                self.progress.emit("🔐 Aguardando senha 2FA...")
                self.password_requested.emit()
                await self._password_event.wait()
                return self.password_2fa
            
            from collector import TelegramCollector

            collector = TelegramCollector(
                progress_callback=progress_callback,
                code_callback=code_callback,
                password_callback=password_callback,
                filtrar_idosos=self.filtrar_idosos,
                idade_maxima=self.idade_maxima,
                exigir_data_nascimento=self.exigir_data_nascimento,
                conta_id=self.conta_id
            )
            
            if len(self.groups) == 1:
                collected = self._loop.run_until_complete(
                    collector.run(self.groups[0], self.limit)
                )
            else:
                collected = self._loop.run_until_complete(
                    collector.run_multiple_groups(self.groups, self.limit)
                )
            
            self.finished.emit(collected)
            
        except Exception as e:
            self.error.emit(str(e))
        finally:
            if hasattr(self, '_loop') and self._loop:
                self._loop.close()


class ConfigDialog(QDialog):
    """Diálogo para configuração inicial"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Configuração")
        self.setModal(True)
        self.setMinimumWidth(450)
        self.setStyleSheet(DARK_STYLE)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        title = QLabel("⚙️ Configuração do Telegram")
        title.setStyleSheet("font-size: 16px; font-weight: bold; color: #06b6d4;")
        layout.addWidget(title)
        
        info = QLabel("Obtenha suas credenciais em: https://my.telegram.org/apps")
        info.setStyleSheet("color: #888; margin-bottom: 15px;")
        layout.addWidget(info)
        
        form = QFormLayout()
        
        self.api_id_input = QLineEdit()
        self.api_id_input.setText(str(settings.telegram_api_id) if settings.telegram_api_id else "")
        self.api_id_input.setPlaceholderText("Ex: 12345678")
        form.addRow("API ID:", self.api_id_input)
        
        self.api_hash_input = QLineEdit()
        self.api_hash_input.setText(settings.telegram_api_hash or "")
        self.api_hash_input.setPlaceholderText("Ex: a1b2c3d4e5f6...")
        form.addRow("API Hash:", self.api_hash_input)
        
        self.phone_input = QLineEdit()
        self.phone_input.setText(settings.telegram_phone or "")
        self.phone_input.setPlaceholderText("Ex: +5511999999999")
        form.addRow("Telefone:", self.phone_input)
        
        self.group_input = QLineEdit()
        self.group_input.setText(settings.default_group or "")
        self.group_input.setPlaceholderText("Ex: PuxadasTr4in")
        form.addRow("Grupo padrão:", self.group_input)
        
        layout.addLayout(form)
        
        btn_layout = QHBoxLayout()
        
        save_btn = QPushButton("💾 Salvar")
        save_btn.setStyleSheet("background-color: #06b6d4; color: #0f172a;")
        save_btn.clicked.connect(self.save_config)
        btn_layout.addWidget(save_btn)
        
        cancel_btn = QPushButton("Cancelar")
        cancel_btn.clicked.connect(self.reject)
        btn_layout.addWidget(cancel_btn)
        
        layout.addLayout(btn_layout)
        self.setLayout(layout)
    
    def save_config(self):
        try:
            api_id = int(self.api_id_input.text().strip())
            api_hash = self.api_hash_input.text().strip()
            phone = self.phone_input.text().strip()
            group = self.group_input.text().strip()
            
            if not all([api_id, api_hash, phone, group]):
                QMessageBox.warning(self, "Aviso", "Preencha todos os campos!")
                return
            
            # Usar o método create_env_file para salvar as configurações
            if settings.create_env_file(api_id, api_hash, phone, group):
                QMessageBox.information(self, "Sucesso", "Configurações salvas com sucesso!\nO arquivo .env foi criado.")
            else:
                QMessageBox.critical(self, "Erro", "Falha ao salvar configurações.\nVerifique as permissões de escrita.")
            self.accept()
            
        except ValueError:
            QMessageBox.warning(self, "Erro", "API ID deve ser um número!")


class DataViewDialog(QDialog):
    """Diálogo para visualizar dados coletados"""
    
    def __init__(self, db, parent=None):
        super().__init__(parent)
        self.db = db
        self.setWindowTitle("Dados Coletados")
        self.setModal(True)
        self.setMinimumSize(800, 600)
        self.setStyleSheet(DARK_STYLE)
        self.init_ui()
    
    def init_ui(self):
        layout = QVBoxLayout()
        
        # Filtros
        filter_layout = QHBoxLayout()
        
        self.search_input = QLineEdit()
        self.search_input.setPlaceholderText("🔍 Buscar por nome ou CPF...")
        self.search_input.textChanged.connect(self.filter_data)
        filter_layout.addWidget(self.search_input)
        
        refresh_btn = QPushButton("🔄 Atualizar")
        refresh_btn.clicked.connect(self.load_data)
        filter_layout.addWidget(refresh_btn)
        
        layout.addLayout(filter_layout)
        
        # Tabela
        self.table = QTableWidget()
        self.table.setColumnCount(6)
        self.table.setHorizontalHeaderLabels(["ID", "Nome", "CPF", "Nascimento", "Telefone", "Score"])
        self.table.horizontalHeader().setSectionResizeMode(QHeaderView.Stretch)
        self.table.setAlternatingRowColors(True)
        layout.addWidget(self.table)
        
        # Botões
        btn_layout = QHBoxLayout()
        
        import_btn = QPushButton("📤 Importar CSV")
        import_btn.clicked.connect(self.import_csv)
        btn_layout.addWidget(import_btn)

        export_btn = QPushButton("📥 Exportar CSV")
        export_btn.clicked.connect(self.export_csv)
        btn_layout.addWidget(export_btn)
        
        close_btn = QPushButton("Fechar")
        close_btn.clicked.connect(self.close)
        btn_layout.addWidget(close_btn)
        
        layout.addLayout(btn_layout)
        
        self.setLayout(layout)
        self.load_data()
    
    def load_data(self):
        data = self.db.get_all_data()
        self.table.setRowCount(len(data))
        
        for row, record in enumerate(data):
            self.table.setItem(row, 0, QTableWidgetItem(str(record.get('id', ''))))
            self.table.setItem(row, 1, QTableWidgetItem(record.get('nome', '')))
            self.table.setItem(row, 2, QTableWidgetItem(record.get('cpf', '')))
            self.table.setItem(row, 3, QTableWidgetItem(record.get('nascimento', '')))
            self.table.setItem(row, 4, QTableWidgetItem(record.get('telefone', '')))
            self.table.setItem(row, 5, QTableWidgetItem(str(record.get('score', ''))))
    
    def filter_data(self):
        search = self.search_input.text().lower()
        for row in range(self.table.rowCount()):
            show = False
            for col in range(self.table.columnCount()):
                item = self.table.item(row, col)
                if item and search in item.text().lower():
                    show = True
                    break
            self.table.setRowHidden(row, not show)
    
    def import_csv(self):
        """Importa dados de um arquivo CSV"""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Importar CSV", "", "CSV Files (*.csv);;All Files (*)"
        )
        
        if filepath:
            # Mostrar progresso indeterminado
            progress = QDialog(self)
            progress.setWindowTitle("Importando...")
            progress.setFixedSize(300, 100)
            layout = QVBoxLayout()
            layout.addWidget(QLabel("Lendo arquivo e importando dados...\nIsso pode levar alguns instantes."))
            bar = QProgressBar()
            bar.setRange(0, 0)  # Indeterminado
            layout.addWidget(bar)
            progress.setLayout(layout)
            progress.show()
            QApplication.processEvents()
            
            # Executar importação
            stats = self.db.import_csv(filepath)
            
            progress.close()
            
            # Mostrar resultado
            msg = (f"Importação concluída!\n\n"
                   f"✅ Adicionados: {stats['added']}\n"
                   f"🔄 Atualizados: {stats['updated']}\n"
                   f"⚠️ Erros/Ignorados: {stats['errors']}")
            
            QMessageBox.information(self, "Resultado da Importação", msg)
            
            # Atualizar tabela
            self.load_data()

    def export_csv(self):
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Salvar como CSV", "dados.csv", "CSV Files (*.csv)"
        )
        if filepath:
            mode = 'w'
            if os.path.exists(filepath):
                reply = QMessageBox.question(
                    self, "Arquivo Existente",
                    "O arquivo já existe. Deseja anexar os dados ao final do arquivo?",
                    QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel,
                    QMessageBox.No
                )
                
                if reply == QMessageBox.Cancel:
                    return
                elif reply == QMessageBox.Yes:
                    mode = 'a'
            
            if self.db.export_csv(filepath, 'completo', mode):
                msg = "Dados anexados com sucesso!" if mode == 'a' else "Arquivo exportado com sucesso!"
                QMessageBox.information(self, "Sucesso", f"{msg}\n{filepath}")
            else:
                QMessageBox.critical(self, "Erro", "Erro ao exportar")


class CardGeneratorThread(QThread):
    """Thread para geração de cartões sem travar a interface"""
    
    # Sinais para comunicação com a interface
    progress = pyqtSignal(int, int)  # (atual, total)
    finished_cards = pyqtSignal(list)  # lista de cartões gerados
    error = pyqtSignal(str)  # mensagem de erro
    
    def __init__(self, generator, pattern, quantity, month, year, cvv):
        super().__init__()
        self.generator = generator
        self.pattern = pattern
        self.quantity = quantity
        self.month = month
        self.year = year
        self.cvv = cvv
    
    def run(self):
        """Executa a geração em thread separada"""
        try:
            # Callback para reportar progresso
            def progress_callback(current, total):
                self.progress.emit(current, total)
            
            # Gerar cartões
            cards = self.generator.generate_cards(
                self.pattern, 
                self.quantity, 
                self.month, 
                self.year, 
                self.cvv,
                progress_callback
            )
            
            self.finished_cards.emit(cards)
            
        except Exception as e:
            self.error.emit(str(e))
    
    def stop(self):
        """Para a geração"""
        self.generator.cancel()


class AddressGeneratorThread(QThread):
    """Thread para geração de endereços sem travar a interface"""
    progress = pyqtSignal(int, int)  # (atual, total)
    finished_addresses = pyqtSignal(list)  # lista de endereços formatados
    error = pyqtSignal(str)  # mensagem de erro
    
    def __init__(self, generator, quantidade, uf=None, cidade=None, com_pontuacao=True):
        super().__init__()
        self.generator = generator
        self.quantidade = quantidade
        self.uf = uf
        self.cidade = cidade
        self.com_pontuacao = com_pontuacao
        self._stop_flag = False
    
    def stop(self):
        """Sinaliza para parar a geração"""
        self._stop_flag = True
        self.generator.cancel()
    
    def run(self):
        try:
            def progress_callback(current, total):
                if not self._stop_flag:
                    self.progress.emit(current, total)
            
            enderecos = self.generator.gerar_enderecos(
                quantidade=self.quantidade,
                uf=self.uf,
                cidade=self.cidade,
                com_pontuacao=self.com_pontuacao,
                progress_callback=progress_callback
            )
            
            # Formatar endereços para exibição
            formatted = []
            for end in enderecos:
                formatted.append(end.format_linha(self.com_pontuacao))
            
            self.finished_addresses.emit(formatted)
            
        except Exception as e:
            self.error.emit(str(e))


class ToolsDialog(QDialog):
    """Diálogo de Ferramentas com Gerador de Cartões e CEP - v4.2 com Modo Claro/Escuro"""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("🛠️ Ferramentas")
        self.setModal(False)  # Não bloqueia a janela principal
        self.setMinimumSize(750, 800)
        
        # Estado do tema
        self.is_dark_mode = True
        self.setStyleSheet(DARK_STYLE)
        
        self.card_generator = CardGenerator()
        self.address_generator = AddressGenerator()
        self.account_formatter = AccountFormatter()
        self.generated_cards = []
        self.generated_addresses = []
        self.formatted_accounts = ""
        self.generator_thread = None
        self.address_thread = None
        self.is_generating = False
        self.is_generating_addresses = False
        self.is_formatting = False
        
        # Dados do endereço atual
        self.current_address = None
        
        self.init_ui()
    
    def toggle_theme(self):
        """Alterna entre modo claro e escuro"""
        self.is_dark_mode = not self.is_dark_mode
        if self.is_dark_mode:
            self.setStyleSheet(DARK_STYLE)
            self.theme_btn.setText("☀️ Modo Claro")
        else:
            self.setStyleSheet(LIGHT_STYLE)
            self.theme_btn.setText("🌙 Modo Escuro")
        
        # Atualizar estilos dos campos de resultado do CEP
        self.update_cep_field_styles()
    
    def update_cep_field_styles(self):
        """Atualiza os estilos dos campos de resultado do CEP"""
        if self.is_dark_mode:
            field_style = """
                QLineEdit {
                    background-color: #1c1c1e;
                    border: 1px solid #3a3a3c;
                    border-radius: 12px;
                    padding: 12px 16px;
                    font-size: 14px;
                    color: #10b981;
                }
            """
            copy_btn_style = """
                QPushButton {
                    background-color: transparent;
                    border: none;
                    padding: 8px;
                    font-size: 16px;
                    min-width: 40px;
                }
                QPushButton:hover {
                    background-color: #2c2c2e;
                    border-radius: 12px;
                }
            """
        else:
            field_style = """
                QLineEdit {
                    background-color: #ffffff;
                    border: 1px solid #d2d2d7;
                    border-radius: 12px;
                    padding: 12px 16px;
                    font-size: 14px;
                    color: #1d1d1f;
                }
            """
            copy_btn_style = """
                QPushButton {
                    background-color: transparent;
                    border: none;
                    padding: 8px;
                    font-size: 16px;
                    min-width: 40px;
                }
                QPushButton:hover {
                    background-color: #e8e8ed;
                    border-radius: 12px;
                }
            """
        
        # Aplicar estilos
        self.cep_field.setStyleSheet(field_style)
        self.endereco_field.setStyleSheet(field_style)
        self.bairro_field.setStyleSheet(field_style)
        self.cidade_field.setStyleSheet(field_style)
        self.estado_field.setStyleSheet(field_style)
        
        self.copy_cep_btn.setStyleSheet(copy_btn_style)
        self.copy_endereco_btn.setStyleSheet(copy_btn_style)
        self.copy_bairro_btn.setStyleSheet(copy_btn_style)
        self.copy_cidade_btn.setStyleSheet(copy_btn_style)
        self.copy_estado_btn.setStyleSheet(copy_btn_style)
    
    def init_ui(self):
        main_layout = QVBoxLayout()
        main_layout.setSpacing(24)
        main_layout.setContentsMargins(32, 32, 32, 32)
        
        # Header com título e botão de tema
        header_layout = QHBoxLayout()
        
        # Título - Estilo Apple
        title = QLabel("Ferramentas")
        title.setFont(QFont('-apple-system', 28, QFont.Bold))
        title.setStyleSheet("color: #ffffff; letter-spacing: -0.5px;")
        header_layout.addWidget(title)
        
        header_layout.addStretch()
        
        # Botão de alternar tema
        self.theme_btn = QPushButton("☀️ Modo Claro")
        self.theme_btn.setStyleSheet("""
            QPushButton {
                background-color: #2c2c2e;
                color: #ffffff;
                border: none;
                border-radius: 12px;
                padding: 10px 16px;
                font-size: 13px;
                font-weight: 500;
            }
            QPushButton:hover {
                background-color: #3a3a3c;
            }
        """)
        self.theme_btn.clicked.connect(self.toggle_theme)
        header_layout.addWidget(self.theme_btn)
        
        main_layout.addLayout(header_layout)
        
        # Tabs de ferramentas - Estilo Apple
        self.tabs = QTabWidget()
        self.tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 8px;
            }
            QTabBar::tab {
                background: transparent;
                color: #64748b;
                padding: 12px 28px;
                margin-right: 8px;
                border: none;
                border-bottom: 2px solid transparent;
                font-weight: 500;
                font-size: 14px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                border-bottom: 2px solid #06b6d4;
            }
            QTabBar::tab:hover {
                color: #ffffff;
            }
        """)
        
        # Aba do Gerador de Cartões
        card_tab = self.create_card_generator_tab()
        self.tabs.addTab(card_tab, "💳 Gerador de Cartões")
        
        # Aba do Gerador de CEP (novo layout)
        address_tab = self.create_cep_generator_tab()
        self.tabs.addTab(address_tab, "🏠 Gerador de CEP")
        
        # Aba do Organizador de Contas Premium
        accounts_tab = self.create_account_formatter_tab()
        self.tabs.addTab(accounts_tab, "📧 Organizador de Contas")

        # Aba do Formatador de Dados
        organizer_tab = DataOrganizer()
        self.tabs.addTab(organizer_tab, "🗂️ Formatar Dados")
        
        # === NOVAS FERRAMENTAS v8.0 ===
        
        # Aba do Validador de CPF/CNPJ
        validador_tab = ValidadorWidget()
        self.tabs.addTab(validador_tab, "✅ Validador")
        
        # Aba do Gerador de Dados Fake
        gerador_fake_tab = GeradorFakeWidget()
        self.tabs.addTab(gerador_fake_tab, "🎭 Dados Fake")
        
        main_layout.addWidget(self.tabs)
        self.setLayout(main_layout)

    def _tool_header(self, title: str, subtitle: str, accent: str = "#22d3ee"):
        frame = QFrame()
        frame.setStyleSheet(f"""
            QFrame {{
                background: #07111f;
                border: 1px solid rgba(34, 211, 238, 0.18);
                border-radius: 14px;
            }}
        """)
        layout = QVBoxLayout(frame)
        layout.setContentsMargins(18, 14, 18, 14)
        layout.setSpacing(4)
        title_label = QLabel(title)
        title_label.setStyleSheet(f"color: {accent}; font-size: 20px; font-weight: 900; background: transparent; border: none;")
        subtitle_label = QLabel(subtitle)
        subtitle_label.setStyleSheet("color: #94a3b8; font-size: 12px; background: transparent; border: none;")
        layout.addWidget(title_label)
        layout.addWidget(subtitle_label)
        return frame

    def _tool_group_style(self):
        return """
            QGroupBox {
                background-color: #07111f;
                border: 1px solid rgba(34, 211, 238, 0.16);
                border-radius: 14px;
                margin-top: 18px;
                padding: 18px;
                padding-top: 34px;
                color: #e5e7eb;
            }
            QGroupBox::title {
                color: #67e8f9;
                font-size: 11px;
                font-weight: 800;
                letter-spacing: 1px;
                subcontrol-origin: margin;
                left: 14px;
                top: 5px;
            }
        """

    def _tool_input_style(self):
        return """
            QLineEdit, QComboBox, QSpinBox {
                background-color: #0b1626;
                border: 1px solid rgba(148, 163, 184, 0.18);
                border-radius: 10px;
                padding: 10px 12px;
                color: #f8fafc;
                font-size: 13px;
            }
            QLineEdit:focus, QComboBox:focus, QSpinBox:focus {
                border-color: rgba(34, 211, 238, 0.55);
            }
            QLineEdit::placeholder {
                color: #64748b;
            }
            QComboBox::drop-down {
                border: 0;
                width: 24px;
            }
        """

    def _tool_button_style(self, kind="secondary"):
        colors = {
            "primary": ("#0891b2", "#06b6d4", "#ffffff"),
            "success": ("#10b981", "#34d399", "#04111d"),
            "danger": ("#dc2626", "#ef4444", "#ffffff"),
            "secondary": ("#0f172a", "#1e293b", "#e5e7eb"),
        }
        bg, hover, fg = colors.get(kind, colors["secondary"])
        return f"""
            QPushButton {{
                background-color: {bg};
                color: {fg};
                font-size: 13px;
                font-weight: 800;
                padding: 10px 16px;
                border-radius: 10px;
                border: 1px solid rgba(148, 163, 184, 0.16);
            }}
            QPushButton:hover {{
                background-color: {hover};
                border-color: rgba(34, 211, 238, 0.35);
            }}
            QPushButton:disabled {{
                background-color: #111827;
                color: #475569;
                border-color: rgba(148, 163, 184, 0.10);
            }}
        """

    def _polish_card_tool(self, tab):
        tab.setStyleSheet("QWidget{background:#05070d;color:#e5e7eb;}")
        if tab.layout():
            tab.layout().setContentsMargins(12, 10, 12, 12)
            tab.layout().setSpacing(14)
        for group in tab.findChildren(QGroupBox):
            group.setStyleSheet(self._tool_group_style())
        for cls in (QLineEdit, QComboBox, QSpinBox):
            for widget in tab.findChildren(cls):
                widget.setStyleSheet(self._tool_input_style())
        for button in tab.findChildren(QPushButton):
            button.setStyleSheet(self._tool_button_style("secondary"))
        self.generate_btn.setText("Gerar cartoes")
        self.generate_btn.setStyleSheet(self._tool_button_style("success"))
        self.cancel_btn.setStyleSheet(self._tool_button_style("danger"))
        self.result_text.setStyleSheet("""
            QTextEdit {
                background-color: #030712;
                border: 1px solid rgba(34, 211, 238, 0.16);
                border-radius: 12px;
                padding: 14px;
                font-family: Consolas, 'SF Mono', monospace;
                font-size: 13px;
                color: #34d399;
                line-height: 1.6;
            }
        """)
        self.progress_bar.setStyleSheet("""
            QProgressBar { background:#0f172a; border:0; border-radius:4px; height:8px; }
            QProgressBar::chunk { background:#22d3ee; border-radius:4px; }
        """)
        self.status_label.setStyleSheet("color:#94a3b8;font-size:12px;font-weight:600;background:transparent;border:none;")

    def _polish_cep_tool(self, tab):
        tab.setStyleSheet("QWidget{background:#05070d;color:#e5e7eb;}")
        if tab.layout():
            tab.layout().setContentsMargins(12, 10, 12, 12)
            tab.layout().setSpacing(14)
        for group in tab.findChildren(QGroupBox):
            group.setStyleSheet(self._tool_group_style())
        for cls in (QLineEdit, QComboBox):
            for widget in tab.findChildren(cls):
                widget.setStyleSheet(self._tool_input_style())
        for radio in tab.findChildren(QRadioButton):
            radio.setStyleSheet("color:#e5e7eb;font-weight:700;background:transparent;border:none;")
        for button in tab.findChildren(QPushButton):
            button.setStyleSheet(self._tool_button_style("secondary"))
        self.gerar_cep_btn.setText("Gerar CEP")
        self.gerar_cep_btn.setStyleSheet(self._tool_button_style("primary"))
        result_style = """
            QLineEdit {
                background-color: #030712;
                border: 1px solid rgba(34, 211, 238, 0.18);
                border-radius: 10px;
                padding: 10px 12px;
                font-size: 13px;
                color: #34d399;
                font-weight: 700;
            }
        """
        for field in (self.cep_field, self.endereco_field, self.bairro_field, self.cidade_field, self.estado_field):
            field.setStyleSheet(result_style)
        self.cep_status_label.setStyleSheet("color:#94a3b8;font-size:12px;font-weight:600;background:transparent;border:none;")

    def _polish_account_formatter_tool(self, tab):
        tab.setStyleSheet("QWidget{background:#05070d;color:#e5e7eb;}")
        for group in tab.findChildren(QGroupBox):
            group.setStyleSheet(self._tool_group_style())
        for cls in (QLineEdit, QComboBox, QTextEdit):
            for widget in tab.findChildren(cls):
                if widget is getattr(self, "accounts_result", None):
                    continue
                if widget is getattr(self, "accounts_preview", None):
                    continue
                widget.setStyleSheet("""
                    QTextEdit, QLineEdit, QComboBox {
                        background-color: #07111f;
                        border: 1px solid rgba(139, 92, 246, 0.22);
                        border-radius: 12px;
                        padding: 10px 12px;
                        color: #f8fafc;
                        font-size: 13px;
                    }
                    QTextEdit:focus, QLineEdit:focus, QComboBox:focus {
                        border-color: rgba(139, 92, 246, 0.60);
                    }
                    QComboBox::drop-down { border: 0; width: 24px; }
                """)
        for button in tab.findChildren(QPushButton):
            button.setStyleSheet(self._tool_button_style("secondary"))
        self.format_btn.setText("Gerar contas")
        self.format_btn.setStyleSheet(self._tool_button_style("primary"))
        self.accounts_result.setStyleSheet("""
            QTextEdit {
                background-color: #030712;
                border: 1px solid rgba(139, 92, 246, 0.24);
                border-radius: 14px;
                padding: 14px;
                font-family: Consolas, 'SF Mono', monospace;
                font-size: 12px;
                color: #34d399;
                line-height: 1.6;
            }
        """)
        self.accounts_status_label.setStyleSheet("color:#94a3b8;font-size:12px;font-weight:600;background:transparent;border:none;")

    def _current_account_service(self):
        service = self.service_combo.currentData()
        if service == "Personalizado":
            return self.custom_service_input.text().strip() or "Personalizado"
        return service or "Crunchyroll"

    def _update_accounts_preview(self):
        if not hasattr(self, "accounts_preview"):
            return
        service = self._current_account_service()
        model = self.model_combo.currentData() or 1
        service_password = self.service_password_input.text().strip() or None
        preview, _ = self.account_formatter.process_and_format(
            "exemplo@outlook.com:senha123",
            model,
            service,
            service_password,
        )
        self.accounts_preview.setText(preview.strip())

    def _update_accounts_stats(self):
        if not hasattr(self, "accounts_total_stat"):
            return
        credentials = self.account_formatter.parse_credentials(self.accounts_input.toPlainText())
        domains = {cred.domain for cred in credentials}
        visible = len(getattr(self, "_account_result_blocks", []) or [])
        if hasattr(self, "accounts_search_input") and self.accounts_search_input.text().strip():
            visible = len([b for b in self._account_result_blocks if self.accounts_search_input.text().lower() in b.lower()])
        output_count = len(getattr(self, "_account_result_blocks", []) or [])
        self.accounts_total_stat.setText(f"{len(credentials)}\nCONTAS")
        self.accounts_domains_stat.setText(f"{len(domains)}\nDOMINIOS")
        self.accounts_visible_stat.setText(f"{visible}\nVISIVEIS")
        self.accounts_output_stat.setText(f"{output_count}\nSAIDAS")

    def _make_account_blocks(self, result, model):
        text = (result or "").strip()
        if not text:
            return []
        if model in (4, 7, 8, 9):
            return [line for line in text.splitlines() if line.strip()]
        return [block.strip() for block in re.split(r"\n\s*\n", text) if block.strip()]

    def filter_formatted_accounts(self):
        if not hasattr(self, "accounts_result"):
            return
        blocks = getattr(self, "_account_result_blocks", []) or []
        query = self.accounts_search_input.text().strip().lower()
        if not blocks:
            self._update_accounts_stats()
            return
        filtered = [block for block in blocks if not query or query in block.lower()]
        model = self.model_combo.currentData() or 1
        sep = "\n" if model in (4, 7, 8, 9) else "\n\n"
        self.accounts_result.setText(sep.join(filtered))
        self._update_accounts_stats()

    def export_formatted_accounts(self):
        text = self.accounts_result.toPlainText().strip()
        if not text:
            QMessageBox.warning(self, "Aviso", "Nenhum resultado para exportar!")
            return
        service = re.sub(r'[^a-zA-Z0-9_-]+', '_', self._current_account_service()).strip("_") or "contas"
        default_name = f"contas_{service}_{datetime.now().strftime('%Y%m%d_%H%M%S')}.txt"
        path, _ = QFileDialog.getSaveFileName(self, "Exportar contas", str(Path.home() / "Downloads" / default_name), "Texto (*.txt);;Todos os arquivos (*)")
        if not path:
            return
        try:
            Path(path).write_text(text, encoding="utf-8")
            self.accounts_status_label.setText(f"Exportado em: {path}")
            self.accounts_status_label.setStyleSheet("color:#10b981;font-size:12px;font-weight:600;")
        except Exception as exc:
            QMessageBox.warning(self, "Erro", f"Nao consegui exportar:\n{exc}")
    
    def create_card_generator_tab(self):
        """Cria a aba do gerador de cartões"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.addWidget(self._tool_header("Cartoes", "Gere listas no formato NUMERO|MES|ANO|CVV com uma interface mais limpa.", "#34d399"))
        
        # Grupo de configuração - Estilo Apple
        config_group = QGroupBox("CONFIGURAÇÃO")
        config_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 24px;
                padding: 24px;
                padding-top: 40px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        config_layout = QVBoxLayout()
        config_layout.setSpacing(16)
        
        # Padrão do cartão
        pattern_layout = QHBoxLayout()
        pattern_label = QLabel("Padrão")
        pattern_label.setStyleSheet("font-weight: 500; min-width: 80px; color: #64748b;")
        pattern_layout.addWidget(pattern_label)
        
        self.pattern_input = QLineEdit()
        self.pattern_input.setPlaceholderText("Ex: 406669994713XXXX (X = dígitos aleatórios)")
        self.pattern_input.textChanged.connect(self.update_card_pattern_hint)
        self.pattern_input.setStyleSheet("""
            QLineEdit {
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 14px 16px;
                font-size: 14px;
                font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
                color: #ffffff;
            }
            QLineEdit:focus {
                background-color: #3a3a3c;
            }
            QLineEdit::placeholder {
                color: #48484a;
            }
        """)
        pattern_layout.addWidget(self.pattern_input)
        config_layout.addLayout(pattern_layout)

        self.card_analysis_label = QLabel("Digite um padrão para ver bandeira, tamanho, campos X e validade local.")
        self.card_analysis_label.setWordWrap(True)
        self.card_analysis_label.setStyleSheet(
            "color: #94a3b8; background: #0b1626; border: 1px solid rgba(34,211,238,0.16); "
            "border-radius: 10px; padding: 10px 12px; font-size: 12px;"
        )
        config_layout.addWidget(self.card_analysis_label)
        
        # Linha de expiração e CVV
        exp_layout = QHBoxLayout()
        exp_layout.setSpacing(16)
        
        # Estilo comum para labels
        label_style = "font-weight: 500; color: #64748b;"
        
        # Estilo comum para combos e inputs pequenos
        small_input_style = """
            min-width: 70px;
            background-color: #2c2c2e;
            border: none;
            border-radius: 12px;
            padding: 10px 12px;
        """
        
        # Mês
        mes_label = QLabel("Mês")
        mes_label.setStyleSheet(label_style)
        exp_layout.addWidget(mes_label)
        self.month_combo = QComboBox()
        self.month_combo.addItems([f"{i:02d}" for i in range(1, 13)])
        self.month_combo.setCurrentIndex(9)  # Outubro
        self.month_combo.setStyleSheet(small_input_style)
        exp_layout.addWidget(self.month_combo)
        
        # Ano
        ano_label = QLabel("Ano")
        ano_label.setStyleSheet(label_style)
        exp_layout.addWidget(ano_label)
        self.year_combo = QComboBox()
        current_year = datetime.now().year
        self.year_combo.addItems([str(y) for y in range(current_year, current_year + 10)])
        self.year_combo.setStyleSheet(small_input_style)
        exp_layout.addWidget(self.year_combo)
        
        # CVV
        cvv_label = QLabel("CVV")
        cvv_label.setStyleSheet(label_style)
        exp_layout.addWidget(cvv_label)
        self.cvv_combo = QComboBox()
        self.cvv_combo.addItem("Aleatório", "random")
        self.cvv_combo.addItems([f"{i:03d}" for i in range(0, 1000, 111)])
        self.cvv_combo.setStyleSheet(small_input_style)
        exp_layout.addWidget(self.cvv_combo)
        
        # Quantidade
        qtd_label = QLabel("Qtd")
        qtd_label.setStyleSheet(label_style)
        exp_layout.addWidget(qtd_label)
        self.quantity_spin = QSpinBox()
        self.quantity_spin.setRange(1, 10000)
        self.quantity_spin.setValue(10)
        self.quantity_spin.setStyleSheet(small_input_style + "min-width: 90px;")
        exp_layout.addWidget(self.quantity_spin)
        
        exp_layout.addStretch()
        config_layout.addLayout(exp_layout)
        
        config_group.setLayout(config_layout)
        layout.addWidget(config_group)
        
        # Barra de progresso - Estilo Apple
        progress_layout = QVBoxLayout()
        progress_layout.setSpacing(8)
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(False)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                background-color: #2c2c2e;
                border: none;
                border-radius: 4px;
                height: 6px;
            }
            QProgressBar::chunk {
                background-color: #06b6d4;
                border-radius: 4px;
            }
        """)
        self.progress_bar.hide()
        progress_layout.addWidget(self.progress_bar)
        
        self.progress_label = QLabel("")
        self.progress_label.setAlignment(Qt.AlignCenter)
        self.progress_label.setStyleSheet("color: #06b6d4; font-size: 13px; font-weight: 500;")
        self.progress_label.hide()
        progress_layout.addWidget(self.progress_label)
        
        layout.addLayout(progress_layout)
        
        # Botões de ação - Estilo Apple
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)
        
        # Estilos dos botões
        primary_btn_style = """
            QPushButton {
                background-color: #06b6d4;
                color: #ffffff;
                font-size: 14px;
                font-weight: 600;
                padding: 14px 28px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #409cff; }
            QPushButton:pressed { background-color: #0071e3; }
            QPushButton:disabled { background-color: #1c1c1e; color: #48484a; }
        """
        
        secondary_btn_style = """
            QPushButton {
                background-color: #2c2c2e;
                color: #ffffff;
                font-size: 13px;
                font-weight: 500;
                padding: 12px 20px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #3a3a3c; }
        """
        
        destructive_btn_style = """
            QPushButton {
                background-color: #ff453a;
                color: #ffffff;
                font-size: 13px;
                font-weight: 500;
                padding: 12px 20px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #ff6961; }
        """
        
        self.generate_btn = QPushButton("Gerar Cartões")
        self.generate_btn.setStyleSheet(primary_btn_style)
        self.generate_btn.clicked.connect(self.generate_cards)
        btn_layout.addWidget(self.generate_btn)
        
        self.cancel_btn = QPushButton("Cancelar")
        self.cancel_btn.setStyleSheet(destructive_btn_style)
        self.cancel_btn.clicked.connect(self.cancel_generation)
        self.cancel_btn.hide()
        btn_layout.addWidget(self.cancel_btn)
        
        copy_btn = QPushButton("Copiar Tudo")
        copy_btn.setStyleSheet(secondary_btn_style)
        copy_btn.clicked.connect(self.copy_cards)
        btn_layout.addWidget(copy_btn)
        
        clear_btn = QPushButton("Limpar")
        clear_btn.setStyleSheet(secondary_btn_style)
        clear_btn.clicked.connect(self.clear_cards)
        btn_layout.addWidget(clear_btn)

        validate_btn = QPushButton("Validar lista")
        validate_btn.setStyleSheet(secondary_btn_style)
        validate_btn.clicked.connect(self.validate_generated_cards)
        btn_layout.addWidget(validate_btn)

        masked_btn = QPushButton("Copiar mascarado")
        masked_btn.setStyleSheet(secondary_btn_style)
        masked_btn.clicked.connect(self.copy_masked_cards)
        btn_layout.addWidget(masked_btn)
        
        layout.addLayout(btn_layout)
        
        # Botões de cópia individual - Estilo Apple
        copy_individual_layout = QHBoxLayout()
        copy_individual_layout.setSpacing(8)
        
        copy_btn_style = """
            QPushButton {
                background-color: #1c1c1e;
                color: #06b6d4;
                font-size: 12px;
                font-weight: 500;
                padding: 10px 14px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #2c2c2e; }
        """
        
        copy_numbers_btn = QPushButton("Números")
        copy_numbers_btn.setStyleSheet(copy_btn_style)
        copy_numbers_btn.clicked.connect(lambda: self.copy_card_field(0, "Número"))
        copy_individual_layout.addWidget(copy_numbers_btn)
        
        copy_months_btn = QPushButton("Meses")
        copy_months_btn.setStyleSheet(copy_btn_style)
        copy_months_btn.clicked.connect(lambda: self.copy_card_field(1, "Mês"))
        copy_individual_layout.addWidget(copy_months_btn)
        
        copy_years_btn = QPushButton("Anos")
        copy_years_btn.setStyleSheet(copy_btn_style)
        copy_years_btn.clicked.connect(lambda: self.copy_card_field(2, "Ano"))
        copy_individual_layout.addWidget(copy_years_btn)
        
        copy_cvvs_btn = QPushButton("CVVs")
        copy_cvvs_btn.setStyleSheet(copy_btn_style)
        copy_cvvs_btn.clicked.connect(lambda: self.copy_card_field(3, "CVV"))
        copy_individual_layout.addWidget(copy_cvvs_btn)
        
        layout.addLayout(copy_individual_layout)
        
        # Área de resultado - Estilo Apple
        result_group = QGroupBox("RESULTADO")
        result_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 20px;
                padding: 20px;
                padding-top: 36px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        result_layout = QVBoxLayout()
        
        self.result_text = QTextEdit()
        self.result_text.setReadOnly(True)
        self.result_text.setStyleSheet("""
            QTextEdit {
                background-color: #000000;
                border: 1px solid #2c2c2e;
                border-radius: 12px;
                padding: 16px;
                font-family: 'SF Mono', 'Menlo', 'Monaco', 'Consolas', monospace;
                font-size: 13px;
                color: #10b981;
                line-height: 1.6;
            }
        """)
        self.result_text.setPlaceholderText("Os cartões gerados aparecerão aqui...\n\nFormato: NUMERO|MES|ANO|CVV")
        result_layout.addWidget(self.result_text)
        
        result_group.setLayout(result_layout)
        layout.addWidget(result_group)
        
        # Status - Estilo Apple
        self.status_label = QLabel("Histórico: 0 cartões · Gerados: 0")
        self.status_label.setStyleSheet("color: #64748b; font-size: 12px; font-weight: 400;")
        self.status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.status_label)
        
        tab.setLayout(layout)
        self._polish_card_tool(tab)
        return tab
    
    def create_cep_generator_tab(self):
        """Cria a aba do gerador de CEP com layout similar à imagem de referência"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.addWidget(self._tool_header("CEP", "Gere endereco completo, copie campos separados ou use tudo junto.", "#22d3ee"))
        
        # Grupo de Opções
        options_group = QGroupBox("OPÇÕES")
        options_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 24px;
                padding: 24px;
                padding-top: 40px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        options_layout = QVBoxLayout()
        options_layout.setSpacing(16)
        
        # Estilo comum para labels
        label_style = "font-weight: 500; color: #64748b; font-size: 13px;"
        
        # Estilo comum para combos
        combo_style = """
            QComboBox {
                min-width: 200px;
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 12px 16px;
                color: #ffffff;
            }
        """
        
        # 1. Estado (opcional)
        estado_layout = QHBoxLayout()
        estado_label = QLabel("1. Estado (opcional):")
        estado_label.setStyleSheet(label_style)
        estado_layout.addWidget(estado_label)
        estado_layout.addStretch()
        options_layout.addLayout(estado_layout)
        
        self.estado_combo = QComboBox()
        self.estado_combo.addItem("Todos", "")
        for uf, nome in self.address_generator.get_estados():
            self.estado_combo.addItem(f"{uf} - {nome}", uf)
        self.estado_combo.setStyleSheet(combo_style)
        self.estado_combo.currentIndexChanged.connect(self.on_estado_changed)
        options_layout.addWidget(self.estado_combo)
        
        # 2. Cidade (opcional)
        cidade_layout = QHBoxLayout()
        cidade_label = QLabel("2. Cidade (opcional):")
        cidade_label.setStyleSheet(label_style)
        cidade_layout.addWidget(cidade_label)
        cidade_layout.addStretch()
        options_layout.addLayout(cidade_layout)
        
        self.cidade_combo = QComboBox()
        self.cidade_combo.addItem("Todas", "")
        self.cidade_combo.setStyleSheet(combo_style)
        options_layout.addWidget(self.cidade_combo)
        
        # 3. Gerar com pontuação?
        pontuacao_layout = QHBoxLayout()
        pontuacao_label = QLabel("3. Gerar com pontuação?")
        pontuacao_label.setStyleSheet(label_style)
        pontuacao_layout.addWidget(pontuacao_label)
        pontuacao_layout.addStretch()
        options_layout.addLayout(pontuacao_layout)
        
        # Radio buttons para pontuação
        radio_layout = QHBoxLayout()
        radio_layout.setSpacing(20)
        
        self.pontuacao_group = QButtonGroup()
        
        self.radio_sim = QRadioButton("Sim")
        self.radio_sim.setChecked(True)
        self.radio_sim.setStyleSheet("color: #ffffff;")
        self.pontuacao_group.addButton(self.radio_sim)
        radio_layout.addWidget(self.radio_sim)
        
        self.radio_nao = QRadioButton("Não")
        self.radio_nao.setStyleSheet("color: #ffffff;")
        self.pontuacao_group.addButton(self.radio_nao)
        radio_layout.addWidget(self.radio_nao)
        
        radio_layout.addStretch()
        options_layout.addLayout(radio_layout)
        
        options_group.setLayout(options_layout)
        layout.addWidget(options_group)
        
        # Botão Gerar CEP
        btn_layout = QHBoxLayout()
        btn_layout.addStretch()
        
        self.gerar_cep_btn = QPushButton("↻ GERAR CEP")
        self.gerar_cep_btn.setStyleSheet("""
            QPushButton {
                background-color: #4a7c7e;
                color: #ffffff;
                font-size: 14px;
                font-weight: 600;
                padding: 14px 40px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover {
                background-color: #5a8c8e;
            }
            QPushButton:pressed {
                background-color: #3a6c6e;
            }
        """)
        self.gerar_cep_btn.clicked.connect(self.generate_single_cep)
        btn_layout.addWidget(self.gerar_cep_btn)
        
        btn_layout.addStretch()
        layout.addLayout(btn_layout)
        
        # Grupo de Resultado com campos individuais
        result_group = QGroupBox("")
        result_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                padding: 24px;
            }
        """)
        result_layout = QVBoxLayout()
        result_layout.setSpacing(16)
        
        # Estilo dos campos de resultado
        field_style = """
            QLineEdit {
                background-color: #1c1c1e;
                border: 1px solid #3a3a3c;
                border-radius: 12px;
                padding: 12px 16px;
                font-size: 14px;
                color: #10b981;
            }
        """
        
        copy_btn_style = """
            QPushButton {
                background-color: transparent;
                border: none;
                padding: 8px;
                font-size: 16px;
                min-width: 40px;
            }
            QPushButton:hover {
                background-color: #2c2c2e;
                border-radius: 12px;
            }
        """
        
        field_label_style = "font-weight: 500; color: #64748b; font-size: 12px;"
        
        # CEP
        cep_label = QLabel("CEP")
        cep_label.setStyleSheet(field_label_style)
        result_layout.addWidget(cep_label)
        
        cep_row = QHBoxLayout()
        self.cep_field = QLineEdit()
        self.cep_field.setReadOnly(True)
        self.cep_field.setPlaceholderText("00000-000")
        self.cep_field.setStyleSheet(field_style)
        cep_row.addWidget(self.cep_field)
        
        self.copy_cep_btn = QPushButton("📋")
        self.copy_cep_btn.setStyleSheet(copy_btn_style)
        self.copy_cep_btn.setToolTip("Copiar CEP")
        self.copy_cep_btn.clicked.connect(lambda: self.copy_single_field(self.cep_field, "CEP"))
        cep_row.addWidget(self.copy_cep_btn)
        result_layout.addLayout(cep_row)
        
        # Endereço
        endereco_label = QLabel("Endereço")
        endereco_label.setStyleSheet(field_label_style)
        result_layout.addWidget(endereco_label)
        
        endereco_row = QHBoxLayout()
        self.endereco_field = QLineEdit()
        self.endereco_field.setReadOnly(True)
        self.endereco_field.setPlaceholderText("Rua/Avenida")
        self.endereco_field.setStyleSheet(field_style)
        endereco_row.addWidget(self.endereco_field)
        
        self.copy_endereco_btn = QPushButton("📋")
        self.copy_endereco_btn.setStyleSheet(copy_btn_style)
        self.copy_endereco_btn.setToolTip("Copiar Endereço")
        self.copy_endereco_btn.clicked.connect(lambda: self.copy_single_field(self.endereco_field, "Endereço"))
        endereco_row.addWidget(self.copy_endereco_btn)
        result_layout.addLayout(endereco_row)
        
        # Bairro
        bairro_label = QLabel("Bairro")
        bairro_label.setStyleSheet(field_label_style)
        result_layout.addWidget(bairro_label)
        
        bairro_row = QHBoxLayout()
        self.bairro_field = QLineEdit()
        self.bairro_field.setReadOnly(True)
        self.bairro_field.setPlaceholderText("Bairro")
        self.bairro_field.setStyleSheet(field_style)
        bairro_row.addWidget(self.bairro_field)
        
        self.copy_bairro_btn = QPushButton("📋")
        self.copy_bairro_btn.setStyleSheet(copy_btn_style)
        self.copy_bairro_btn.setToolTip("Copiar Bairro")
        self.copy_bairro_btn.clicked.connect(lambda: self.copy_single_field(self.bairro_field, "Bairro"))
        bairro_row.addWidget(self.copy_bairro_btn)
        result_layout.addLayout(bairro_row)
        
        # Cidade
        cidade_label_result = QLabel("Cidade")
        cidade_label_result.setStyleSheet(field_label_style)
        result_layout.addWidget(cidade_label_result)
        
        cidade_row = QHBoxLayout()
        self.cidade_field = QLineEdit()
        self.cidade_field.setReadOnly(True)
        self.cidade_field.setPlaceholderText("Cidade")
        self.cidade_field.setStyleSheet(field_style)
        cidade_row.addWidget(self.cidade_field)
        
        self.copy_cidade_btn = QPushButton("📋")
        self.copy_cidade_btn.setStyleSheet(copy_btn_style)
        self.copy_cidade_btn.setToolTip("Copiar Cidade")
        self.copy_cidade_btn.clicked.connect(lambda: self.copy_single_field(self.cidade_field, "Cidade"))
        cidade_row.addWidget(self.copy_cidade_btn)
        result_layout.addLayout(cidade_row)
        
        # Estado
        estado_label_result = QLabel("Estado")
        estado_label_result.setStyleSheet(field_label_style)
        result_layout.addWidget(estado_label_result)
        
        estado_row = QHBoxLayout()
        self.estado_field = QLineEdit()
        self.estado_field.setReadOnly(True)
        self.estado_field.setPlaceholderText("UF")
        self.estado_field.setStyleSheet(field_style)
        estado_row.addWidget(self.estado_field)
        
        self.copy_estado_btn = QPushButton("📋")
        self.copy_estado_btn.setStyleSheet(copy_btn_style)
        self.copy_estado_btn.setToolTip("Copiar Estado")
        self.copy_estado_btn.clicked.connect(lambda: self.copy_single_field(self.estado_field, "Estado"))
        estado_row.addWidget(self.copy_estado_btn)
        result_layout.addLayout(estado_row)
        
        result_group.setLayout(result_layout)
        layout.addWidget(result_group)
        
        # Status
        self.cep_status_label = QLabel("")
        self.cep_status_label.setStyleSheet("color: #64748b; font-size: 12px; font-weight: 400;")
        self.cep_status_label.setAlignment(Qt.AlignCenter)
        layout.addWidget(self.cep_status_label)
        
        layout.addStretch()
        
        tab.setLayout(layout)
        self._polish_cep_tool(tab)
        return tab
    
    def on_estado_changed(self, index):
        """Atualiza as cidades quando o estado muda"""
        self.cidade_combo.clear()
        self.cidade_combo.addItem("Todas", "")
        
        uf = self.estado_combo.currentData()
        if uf:
            cidades = self.address_generator.get_cidades(uf)
            for id_cidade, nome_cidade in cidades:
                # Exibe o NOME, mas armazena o ID como dado
                self.cidade_combo.addItem(nome_cidade, id_cidade)
    
    def generate_single_cep(self):
        """Gera um único CEP e exibe nos campos"""
        uf = self.estado_combo.currentData() or None
        cidade = self.cidade_combo.currentData() or None
        com_pontuacao = self.radio_sim.isChecked()
        
        # Gerar um endereço
        endereco = self.address_generator.gerar_endereco(uf, cidade, com_pontuacao)
        
        if endereco:
            self.current_address = endereco
            
            # Preencher os campos
            self.cep_field.setText(endereco.cep)
            self.endereco_field.setText(endereco.logradouro)
            self.bairro_field.setText(endereco.bairro)
            self.cidade_field.setText(endereco.cidade)
            estado_nome = self.address_generator.ESTADOS.get(endereco.uf, endereco.estado or endereco.uf)
            self.estado_field.setText(estado_nome)

            source = getattr(self.address_generator, "last_source", "")
            if source == "reserva":
                self.cep_status_label.setText("Reserva local usada porque a API nao respondeu.")
                self.cep_status_label.setStyleSheet("color: #fbbf24; font-size: 12px; font-weight: 600;")
            else:
                self.cep_status_label.setText("CEP gerado pela API.")
                self.cep_status_label.setStyleSheet("color: #10b981; font-size: 12px; font-weight: 400;")
        else:
            self.cep_status_label.setText("Erro ao gerar CEP")
            self.cep_status_label.setStyleSheet("color: #ff453a; font-size: 12px; font-weight: 400;")
    
    def copy_single_field(self, field, field_name):
        """Copia o valor de um campo específico"""
        text = field.text()
        if text:
            _set_clipboard_text_safe(text)
            self.cep_status_label.setText(f"{field_name} copiado!")
            self.cep_status_label.setStyleSheet("color: #10b981; font-size: 12px; font-weight: 400;")
        else:
            self.cep_status_label.setText(f"Nenhum {field_name} para copiar")
            self.cep_status_label.setStyleSheet("color: #ff9f0a; font-size: 12px; font-weight: 400;")
    
    # ===== MÉTODOS DO GERADOR DE CARTÕES =====
    
    def generate_cards(self):
        """Inicia a geração de cartões em thread separada"""
        if self.is_generating:
            return
        
        pattern = self.pattern_input.text().strip()
        if not pattern:
            QMessageBox.warning(self, "Aviso", "Digite um padrão de cartão!")
            return
        
        quantity = self.quantity_spin.value()
        month = self.month_combo.currentText()
        year = self.year_combo.currentText()
        cvv = self.cvv_combo.currentData() if self.cvv_combo.currentIndex() == 0 else self.cvv_combo.currentText()
        if str(cvv).lower() == "random":
            cvv = "RANDOM"
        
        # Preparar interface para geração
        self.is_generating = True
        self.generate_btn.setEnabled(False)
        self.cancel_btn.show()
        self.progress_bar.show()
        self.progress_label.show()
        self.progress_bar.setRange(0, quantity)
        self.progress_bar.setValue(0)
        self.progress_label.setText("Iniciando geração...")
        self.result_text.clear()
        
        # Resetar flag de cancelamento
        self.card_generator.reset_cancel()
        
        # Criar e iniciar thread
        self.generator_thread = CardGeneratorThread(
            self.card_generator, pattern, quantity, month, year, cvv
        )
        self.generator_thread.progress.connect(self.on_progress)
        self.generator_thread.finished_cards.connect(self.on_generation_finished)
        self.generator_thread.error.connect(self.on_generation_error)
        self.generator_thread.start()
    
    def on_progress(self, current, total):
        """Atualiza a barra de progresso"""
        self.progress_bar.setValue(current)
        percent = (current / total) * 100 if total > 0 else 0
        self.progress_label.setText(f"⚡ Gerando: {current}/{total} cartões ({percent:.1f}%)")
    
    def on_generation_finished(self, cards):
        """Chamado quando a geração termina"""
        self.is_generating = False
        self.generate_btn.setEnabled(True)
        self.cancel_btn.hide()
        
        if cards:
            self.generated_cards = cards
            self.result_text.setText('\n'.join(cards))
            self.update_status()
            
            self.progress_bar.setValue(len(cards))
            self.progress_label.setText(f"Concluído · {len(cards)} cartões gerados")
            self.progress_label.setStyleSheet("color: #10b981; font-size: 13px; font-weight: 500;")
        else:
            self.progress_label.setText("Nenhum cartão gerado")
            self.progress_label.setStyleSheet("color: #ff453a; font-size: 13px; font-weight: 500;")
        
        # Esconder barra após 3 segundos
        QTimer.singleShot(3000, self.hide_progress)
    
    def on_generation_error(self, error_msg):
        """Chamado quando ocorre erro na geração"""
        self.is_generating = False
        self.generate_btn.setEnabled(True)
        self.cancel_btn.hide()
        self.progress_label.setText(f"Erro: {error_msg}")
        self.progress_label.setStyleSheet("color: #ff453a; font-size: 13px; font-weight: 500;")
        QMessageBox.critical(self, "Erro", f"Erro durante a geração:\n\n{error_msg}")
        QTimer.singleShot(3000, self.hide_progress)
    
    def cancel_generation(self):
        """Cancela a geração em andamento"""
        if self.generator_thread and self.is_generating:
            self.generator_thread.stop()
            self.progress_label.setText("Cancelando...")
            self.progress_label.setStyleSheet("color: #ff9f0a; font-size: 13px; font-weight: 500;")
    
    def hide_progress(self):
        """Esconde a barra de progresso"""
        if not self.is_generating:
            self.progress_bar.hide()
            self.progress_label.hide()
            self.progress_label.setStyleSheet("color: #06b6d4; font-size: 13px; font-weight: 500;")
    
    def copy_cards(self):
        """Copia os cartões para a área de transferência"""
        text = self.result_text.toPlainText()
        if text:
            _set_clipboard_text_safe(text)
            QMessageBox.information(self, "Sucesso", f"{len(self.generated_cards)} cartões copiados!")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhum cartão para copiar!")
    
    def clear_cards(self):
        """Limpa a lista de cartões gerados"""
        self.result_text.clear()
        self.generated_cards = []
        self.update_status()
    
    def update_status(self):
        """Atualiza o status"""
        history_count = self.card_generator.get_history_count()
        generated_count = len(self.generated_cards)
        self.status_label.setText(f"Histórico: {history_count} cartões · Gerados: {generated_count}")
    
    def copy_card_field(self, field_index: int, field_name: str):
        """Copia um campo específico dos cartões para a área de transferência"""
        if not self.generated_cards:
            QMessageBox.warning(self, "Aviso", "Nenhum cartão para copiar!")
            return
        
        try:
            # Extrair o campo específico de cada cartão
            # Formato: NUMERO|MES|ANO|CVV
            fields = []
            for card in self.generated_cards:
                parts = card.split('|')
                if len(parts) > field_index:
                    fields.append(parts[field_index])
            
            if fields:
                text = '\n'.join(fields)
                _set_clipboard_text_safe(text)
                QMessageBox.information(self, "Sucesso", f"{len(fields)} {field_name}(s) copiado(s)!")
            else:
                QMessageBox.warning(self, "Aviso", f"Não foi possível extrair {field_name}!")
        except Exception as e:
            QMessageBox.warning(self, "Erro", f"Erro ao copiar: {str(e)}")

    def _card_digits(self, value: str) -> str:
        """Extrai apenas os digitos do numero do cartao."""
        return re.sub(r"\D", "", value or "")

    def _detect_card_brand(self, digits: str) -> str:
        """Detecta a bandeira por prefixo, apenas localmente."""
        if not digits:
            return "Indefinida"
        prefix2 = int(digits[:2]) if len(digits) >= 2 else -1
        prefix3 = int(digits[:3]) if len(digits) >= 3 else -1
        prefix4 = int(digits[:4]) if len(digits) >= 4 else -1
        prefix6 = int(digits[:6]) if len(digits) >= 6 else -1
        if (
            digits.startswith(("401178", "401179", "431274", "438935", "451416", "457393", "457631"))
            or digits.startswith(("504175", "5067", "5090", "627780", "636297", "636368"))
        ):
            return "Elo"
        if digits.startswith("4"):
            return "Visa"
        if 51 <= prefix2 <= 55 or 2221 <= prefix4 <= 2720:
            return "Mastercard"
        if prefix2 in (34, 37):
            return "American Express"
        if digits.startswith("6011") or digits.startswith("65") or 644 <= prefix3 <= 649:
            return "Discover"
        if digits.startswith("35"):
            return "JCB"
        if prefix2 in (36, 38, 39):
            return "Diners"
        return "Indefinida"

    def update_card_pattern_hint(self):
        """Mostra uma leitura rapida do padrao antes de gerar."""
        if not hasattr(self, "card_analysis_label"):
            return
        pattern = self.pattern_input.text().strip()
        if not pattern:
            self.card_analysis_label.setText("Digite um padrão para ver bandeira, tamanho, campos X e validade local.")
            self.card_analysis_label.setStyleSheet(
                "color: #94a3b8; background: #0b1626; border: 1px solid rgba(34,211,238,0.16); "
                "border-radius: 10px; padding: 10px 12px; font-size: 12px;"
            )
            return

        clean_pattern = pattern.upper().replace(" ", "").replace("-", "")
        invalid_chars = [char for char in clean_pattern if not char.isdigit() and char != "X"]
        digits = self._card_digits(clean_pattern)
        x_count = clean_pattern.count("X")
        variable_digits = max(0, x_count - (1 if clean_pattern.endswith("X") else 0))
        combinations = 10 ** variable_digits if variable_digits <= 6 else None
        brand = self._detect_card_brand(digits)
        length = len(clean_pattern)

        if invalid_chars:
            status = "Revise: use apenas números e X."
            color = "#f43f5e"
        elif length < 13 or length > 19:
            status = "Tamanho incomum. O normal fica entre 13 e 19 dígitos."
            color = "#fbbf24"
        elif x_count == 0:
            valid = self.card_generator.validate_luhn(digits)
            status = "Luhn OK." if valid else "Luhn inválido para número completo."
            color = "#10b981" if valid else "#f43f5e"
        else:
            auto = "último X vira dígito Luhn automático" if clean_pattern.endswith("X") else "Luhn será validado por tentativa"
            status = f"{x_count} campo(s) X; {auto}."
            color = "#22d3ee"

        combo_text = f"{combinations:,}".replace(",", ".") if combinations is not None else "muitas"
        self.card_analysis_label.setText(
            f"Bandeira provável: {brand} | Tamanho: {length} | X: {x_count} | Combinações: {combo_text} | {status}"
        )
        self.card_analysis_label.setStyleSheet(
            f"color: {color}; background: #0b1626; border: 1px solid {color}; "
            "border-radius: 10px; padding: 10px 12px; font-size: 12px; font-weight: 700;"
        )

    def _analyze_card_line(self, line: str) -> dict:
        parts = [part.strip() for part in re.split(r"[|;:]", line.strip()) if part.strip()]
        if len(parts) < 4:
            return {"ok": False, "reason": "formato", "brand": "Indefinida", "number": ""}

        number = self._card_digits(parts[0])
        month = self._card_digits(parts[1])
        year = self._card_digits(parts[2])
        cvv = self._card_digits(parts[3])
        brand = self._detect_card_brand(number)

        if not (13 <= len(number) <= 19):
            return {"ok": False, "reason": "numero", "brand": brand, "number": number}
        if not self.card_generator.validate_luhn(number):
            return {"ok": False, "reason": "luhn", "brand": brand, "number": number}
        if not month or not (1 <= int(month) <= 12):
            return {"ok": False, "reason": "mes", "brand": brand, "number": number}
        if len(year) == 2:
            full_year = 2000 + int(year)
        elif len(year) == 4:
            full_year = int(year)
        else:
            return {"ok": False, "reason": "ano", "brand": brand, "number": number}
        now = datetime.now()
        if full_year < now.year or (full_year == now.year and int(month) < now.month):
            return {"ok": False, "reason": "vencido", "brand": brand, "number": number}
        if len(cvv) not in (3, 4):
            return {"ok": False, "reason": "cvv", "brand": brand, "number": number}
        return {"ok": True, "reason": "ok", "brand": brand, "number": number}

    def validate_generated_cards(self):
        """Valida formato/Luhn da lista exibida, sem consulta externa."""
        lines = [line.strip() for line in self.result_text.toPlainText().splitlines() if line.strip()]
        if not lines:
            QMessageBox.warning(self, "Aviso", "Nenhum cartão na lista para validar.")
            return

        seen = set()
        stats = {"ok": 0, "duplicado": 0}
        brands = {}
        invalid_reasons = {}
        for line in lines:
            data = self._analyze_card_line(line)
            number = data.get("number", "")
            if number and number in seen:
                stats["duplicado"] += 1
            elif number:
                seen.add(number)
            if data["ok"]:
                stats["ok"] += 1
                brands[data["brand"]] = brands.get(data["brand"], 0) + 1
            else:
                reason = data.get("reason", "invalido")
                invalid_reasons[reason] = invalid_reasons.get(reason, 0) + 1

        invalid = len(lines) - stats["ok"]
        brand_text = ", ".join(f"{brand}: {count}" for brand, count in sorted(brands.items())) or "-"
        reason_text = ", ".join(f"{reason}: {count}" for reason, count in sorted(invalid_reasons.items())) or "-"
        self.status_label.setText(
            f"Validação local: {stats['ok']} OK · {invalid} revisar · {stats['duplicado']} duplicados"
        )
        QMessageBox.information(
            self,
            "Validação local",
            "Nada foi enviado para site externo.\n\n"
            f"Total: {len(lines)}\n"
            f"Formato/Luhn OK: {stats['ok']}\n"
            f"Para revisar: {invalid}\n"
            f"Duplicados por número: {stats['duplicado']}\n"
            f"Bandeiras: {brand_text}\n"
            f"Motivos de revisão: {reason_text}"
        )

    def copy_masked_cards(self):
        """Copia a lista com os numeros mascarados."""
        lines = [line.strip() for line in self.result_text.toPlainText().splitlines() if line.strip()]
        if not lines:
            QMessageBox.warning(self, "Aviso", "Nenhum cartão para copiar.")
            return

        masked = []
        for line in lines:
            parts = [part.strip() for part in re.split(r"[|;:]", line) if part.strip()]
            if len(parts) >= 4:
                number = self._card_digits(parts[0])
                safe_number = number[:6] + ("*" * max(0, len(number) - 10)) + number[-4:] if len(number) >= 10 else "****"
                masked.append(f"{safe_number}|{parts[1]}|{parts[2]}|***")
            else:
                masked.append(line)
        _set_clipboard_text_safe("\n".join(masked))
        QMessageBox.information(self, "Copiado", f"{len(masked)} linha(s) copiadas com número mascarado.")
    
    # ===== MÉTODOS DO FORMATADOR DE CONTAS =====
    
    def create_account_formatter_tab(self):
        """Cria a aba do formatador de contas premium"""
        tab = QWidget()
        layout = QVBoxLayout()
        layout.setSpacing(16)
        layout.addWidget(self._tool_header(
            "Organizador de Contas",
            "Cole contas email:senha, escolha serviço/modelo e gere saídas prontas.",
            "#8b5cf6",
        ))
        
        # Scroll area para caber tudo
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("QScrollArea { border: none; background: transparent; }")
        
        scroll_content = QWidget()
        scroll_layout = QVBoxLayout(scroll_content)
        scroll_layout.setSpacing(16)
        
        # Grupo de Entrada
        input_group = QGroupBox("ENTRADA")
        input_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 24px;
                padding: 24px;
                padding-top: 40px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        input_layout = QVBoxLayout()
        input_layout.setSpacing(12)
        
        # Área de texto para colar credenciais
        input_label = QLabel("Cole as credenciais (email:senha, email|senha, email-senha):")
        input_label.setStyleSheet("font-weight: 500; color: #64748b; font-size: 12px;")
        input_layout.addWidget(input_label)
        
        self.accounts_input = QTextEdit()
        self.accounts_input.setPlaceholderText("usuario@gmail.com:senha123\noutro@hotmail.com|minhasenha\nemail@yahoo.com-pass456")
        self.accounts_input.setMinimumHeight(120)
        self.accounts_input.setMaximumHeight(150)
        self.accounts_input.setStyleSheet("""
            QTextEdit {
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 12px;
                font-family: 'SF Mono', 'Menlo', 'Consolas', monospace;
                font-size: 12px;
                color: #ffffff;
            }
        """)
        self.accounts_input.textChanged.connect(self._update_accounts_stats)
        input_layout.addWidget(self.accounts_input)
        
        input_group.setLayout(input_layout)
        scroll_layout.addWidget(input_group)

        stats_layout = QGridLayout()
        stats_layout.setSpacing(8)
        self.accounts_total_stat = QLabel("0\nCONTAS")
        self.accounts_domains_stat = QLabel("0\nDOMINIOS")
        self.accounts_visible_stat = QLabel("0\nVISIVEIS")
        self.accounts_output_stat = QLabel("0\nSAIDAS")
        for i, label in enumerate((
            self.accounts_total_stat,
            self.accounts_domains_stat,
            self.accounts_visible_stat,
            self.accounts_output_stat,
        )):
            label.setAlignment(Qt.AlignCenter)
            label.setStyleSheet("""
                QLabel {
                    background: #07111f;
                    border: 1px solid rgba(139, 92, 246, 0.22);
                    border-radius: 12px;
                    padding: 10px;
                    color: #c4b5fd;
                    font-size: 12px;
                    font-weight: 900;
                }
            """)
            stats_layout.addWidget(label, 0, i)
        scroll_layout.addLayout(stats_layout)
        
        # Grupo de Configurações
        config_group = QGroupBox("CONFIGURAÇÕES")
        config_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 20px;
                padding: 24px;
                padding-top: 40px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        config_layout = QVBoxLayout()
        config_layout.setSpacing(16)
        
        # Estilo comum
        label_style = "font-weight: 500; color: #64748b; font-size: 12px;"
        combo_style = """
            QComboBox {
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 12px 16px;
                color: #ffffff;
                min-width: 200px;
            }
        """
        
        # Serviço
        service_layout = QHBoxLayout()
        service_label = QLabel("Serviço:")
        service_label.setStyleSheet(label_style)
        service_layout.addWidget(service_label)
        
        self.service_combo = QComboBox()
        services = self.account_formatter.get_services()
        for name, emoji in services.items():
            self.service_combo.addItem(f"{emoji} {name}", name)
        self.service_combo.setStyleSheet(combo_style)
        self.service_combo.currentIndexChanged.connect(self.on_service_changed)
        service_layout.addWidget(self.service_combo)
        service_layout.addStretch()
        config_layout.addLayout(service_layout)
        
        # Campo de serviço personalizado (oculto por padrão)
        self.custom_service_layout = QHBoxLayout()
        custom_label = QLabel("Nome do serviço:")
        custom_label.setStyleSheet(label_style)
        self.custom_service_layout.addWidget(custom_label)
        
        self.custom_service_input = QLineEdit()
        self.custom_service_input.setPlaceholderText("Digite o nome do serviço")
        self.custom_service_input.setStyleSheet("""
            QLineEdit {
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 12px 16px;
                color: #ffffff;
            }
        """)
        self.custom_service_input.textChanged.connect(self._update_accounts_preview)
        self.custom_service_layout.addWidget(self.custom_service_input)
        self.custom_service_layout.addStretch()
        
        # Widget container para o layout personalizado
        self.custom_service_widget = QWidget()
        self.custom_service_widget.setLayout(self.custom_service_layout)
        self.custom_service_widget.hide()
        config_layout.addWidget(self.custom_service_widget)
        
        # Senha do serviço (opcional)
        pwd_layout = QHBoxLayout()
        pwd_label = QLabel("Senha do serviço (opcional):")
        pwd_label.setStyleSheet(label_style)
        pwd_layout.addWidget(pwd_label)
        
        self.service_password_input = QLineEdit()
        self.service_password_input.setPlaceholderText("Deixe vazio para usar a senha original")
        self.service_password_input.setStyleSheet("""
            QLineEdit {
                background-color: #2c2c2e;
                border: none;
                border-radius: 12px;
                padding: 12px 16px;
                color: #ffffff;
                min-width: 250px;
            }
        """)
        self.service_password_input.textChanged.connect(self._update_accounts_preview)
        pwd_layout.addWidget(self.service_password_input)
        pwd_layout.addStretch()
        config_layout.addLayout(pwd_layout)
        
        # Modelo de formatação
        model_layout = QHBoxLayout()
        model_label = QLabel("Modelo:")
        model_label.setStyleSheet(label_style)
        model_layout.addWidget(model_label)
        
        self.model_combo = QComboBox()
        self.model_combo.addItem("📝 Clássico (Completo)", 1)
        self.model_combo.addItem("✨ Minimalista (Limpo)", 2)
        self.model_combo.addItem("📦 Detalhado (Box)", 3)
        self.model_combo.addItem("⚡ Compacto (One-liner)", 4)
        self.model_combo.addItem("💎 PRO Completo", 5)
        self.model_combo.addItem("🚀 PRO Simples", 6)
        self.model_combo.addItem("🔹 PRO Minimal", 7)
        self.model_combo.addItem("📊 Tabela Pipe", 8)
        self.model_combo.addItem("🧩 JSON Lines", 9)
        self.model_combo.setStyleSheet(combo_style)
        self.model_combo.currentIndexChanged.connect(self._update_accounts_preview)
        model_layout.addWidget(self.model_combo)
        model_layout.addStretch()
        config_layout.addLayout(model_layout)
        
        config_group.setLayout(config_layout)
        scroll_layout.addWidget(config_group)

        preview_group = QGroupBox("PREVIEW DO MODELO")
        preview_group.setStyleSheet(self._tool_group_style())
        preview_layout = QVBoxLayout()
        self.accounts_preview = QTextEdit()
        self.accounts_preview.setReadOnly(True)
        self.accounts_preview.setMaximumHeight(135)
        self.accounts_preview.setStyleSheet("""
            QTextEdit {
                background-color: #030712;
                border: 1px dashed rgba(139, 92, 246, 0.28);
                border-radius: 12px;
                padding: 12px;
                font-family: Consolas, 'SF Mono', monospace;
                font-size: 12px;
                color: #c4b5fd;
            }
        """)
        preview_layout.addWidget(self.accounts_preview)
        preview_group.setLayout(preview_layout)
        scroll_layout.addWidget(preview_group)
        
        # Botões de ação
        btn_layout = QHBoxLayout()
        btn_layout.setSpacing(12)
        
        self.format_btn = QPushButton("✨ FORMATAR CONTAS")
        self.format_btn.setStyleSheet("""
            QPushButton {
                background-color: #5856d6;
                color: #ffffff;
                font-size: 14px;
                font-weight: 600;
                padding: 14px 28px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #6e6cd8; }
            QPushButton:pressed { background-color: #4a48c4; }
        """)
        self.format_btn.clicked.connect(self.format_accounts)
        btn_layout.addWidget(self.format_btn)
        
        copy_formatted_btn = QPushButton("📋 Copiar Resultado")
        copy_formatted_btn.setStyleSheet("""
            QPushButton {
                background-color: #2c2c2e;
                color: #ffffff;
                font-size: 13px;
                font-weight: 500;
                padding: 12px 20px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #3a3a3c; }
        """)
        copy_formatted_btn.clicked.connect(self.copy_formatted_accounts)
        btn_layout.addWidget(copy_formatted_btn)

        export_formatted_btn = QPushButton("💾 Exportar TXT")
        export_formatted_btn.setStyleSheet("""
            QPushButton {
                background-color: #2c2c2e;
                color: #ffffff;
                font-size: 13px;
                font-weight: 500;
                padding: 12px 20px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #3a3a3c; }
        """)
        export_formatted_btn.clicked.connect(self.export_formatted_accounts)
        btn_layout.addWidget(export_formatted_btn)
        
        clear_formatted_btn = QPushButton("🗑️ Limpar")
        clear_formatted_btn.setStyleSheet("""
            QPushButton {
                background-color: #2c2c2e;
                color: #ffffff;
                font-size: 13px;
                font-weight: 500;
                padding: 12px 20px;
                border-radius: 12px;
                border: none;
            }
            QPushButton:hover { background-color: #3a3a3c; }
        """)
        clear_formatted_btn.clicked.connect(self.clear_formatted_accounts)
        btn_layout.addWidget(clear_formatted_btn)
        
        scroll_layout.addLayout(btn_layout)

        search_layout = QHBoxLayout()
        search_label = QLabel("Buscar no resultado:")
        search_label.setStyleSheet("font-weight: 700; color: #94a3b8; font-size: 12px;")
        search_layout.addWidget(search_label)
        self.accounts_search_input = QLineEdit()
        self.accounts_search_input.setPlaceholderText("email, dominio, serviço ou provedor...")
        self.accounts_search_input.textChanged.connect(self.filter_formatted_accounts)
        search_layout.addWidget(self.accounts_search_input, 1)
        scroll_layout.addLayout(search_layout)
        
        # Grupo de Resultado
        result_group = QGroupBox("RESULTADO")
        result_group.setStyleSheet("""
            QGroupBox {
                background-color: #1c1c1e;
                border: none;
                border-radius: 16px;
                margin-top: 20px;
                padding: 20px;
                padding-top: 36px;
            }
            QGroupBox::title {
                color: #64748b;
                font-size: 11px;
                font-weight: 600;
                letter-spacing: 1px;
            }
        """)
        result_layout = QVBoxLayout()
        
        self.accounts_result = QTextEdit()
        self.accounts_result.setReadOnly(True)
        self.accounts_result.setMinimumHeight(200)
        self.accounts_result.setStyleSheet("""
            QTextEdit {
                background-color: #000000;
                border: 1px solid #2c2c2e;
                border-radius: 12px;
                padding: 16px;
                font-family: 'SF Mono', 'Menlo', 'Monaco', 'Consolas', monospace;
                font-size: 12px;
                color: #10b981;
                line-height: 1.6;
            }
        """)
        self.accounts_result.setPlaceholderText("As contas formatadas aparecerão aqui...")
        result_layout.addWidget(self.accounts_result)
        
        result_group.setLayout(result_layout)
        scroll_layout.addWidget(result_group)
        
        # Status
        self.accounts_status_label = QLabel("")
        self.accounts_status_label.setStyleSheet("color: #64748b; font-size: 12px; font-weight: 400;")
        self.accounts_status_label.setAlignment(Qt.AlignCenter)
        scroll_layout.addWidget(self.accounts_status_label)
        
        scroll.setWidget(scroll_content)
        layout.addWidget(scroll)
        
        tab.setLayout(layout)
        self._account_result_blocks = []
        self._polish_account_formatter_tool(tab)
        self._update_accounts_preview()
        self._update_accounts_stats()
        return tab
    
    def on_service_changed(self, index):
        """Mostra/oculta o campo de serviço personalizado"""
        service = self.service_combo.currentData()
        if service == "Personalizado":
            self.custom_service_widget.show()
        else:
            self.custom_service_widget.hide()
        self._update_accounts_preview()
    
    def format_accounts(self):
        """Formata as contas de acordo com as configurações"""
        input_text = self.accounts_input.toPlainText().strip()
        
        if not input_text:
            QMessageBox.warning(self, "Aviso", "Cole as credenciais na área de entrada!")
            return
        
        # Obter configurações
        service = self.service_combo.currentData()
        if service == "Personalizado":
            service = self.custom_service_input.text().strip()
            if not service:
                QMessageBox.warning(self, "Aviso", "Digite o nome do serviço personalizado!")
                return
        
        model = self.model_combo.currentData()
        service_password = self.service_password_input.text().strip() or None
        
        # Formatar
        try:
            result, count = self.account_formatter.process_and_format(
                input_text, model, service, service_password
            )
            
            if result:
                self.formatted_accounts = result
                self._account_result_blocks = self._make_account_blocks(result, model)
                self.accounts_search_input.clear()
                self.accounts_result.setText(result)
                self.accounts_status_label.setText(f"✅ {count} conta(s) formatada(s) com sucesso!")
                self.accounts_status_label.setStyleSheet("color: #10b981; font-size: 12px; font-weight: 400;")
                self._update_accounts_stats()
            else:
                self._account_result_blocks = []
                self.accounts_result.clear()
                self.accounts_status_label.setText("⚠️ Nenhuma credencial válida encontrada")
                self.accounts_status_label.setStyleSheet("color: #ff9f0a; font-size: 12px; font-weight: 400;")
                self._update_accounts_stats()
        
        except Exception as e:
            self.accounts_status_label.setText(f"❌ Erro: {str(e)}")
            self.accounts_status_label.setStyleSheet("color: #ff453a; font-size: 12px; font-weight: 400;")
    
    def copy_formatted_accounts(self):
        """Copia as contas formatadas para a área de transferência"""
        text = self.accounts_result.toPlainText()
        if text:
            _set_clipboard_text_safe(text)
            self.accounts_status_label.setText("📋 Resultado copiado!")
            self.accounts_status_label.setStyleSheet("color: #10b981; font-size: 12px; font-weight: 400;")
        else:
            QMessageBox.warning(self, "Aviso", "Nenhum resultado para copiar!")
    
    def clear_formatted_accounts(self):
        """Limpa os campos do formatador"""
        self.accounts_input.clear()
        self.accounts_result.clear()
        self.service_password_input.clear()
        self.custom_service_input.clear()
        self.formatted_accounts = ""
        self._account_result_blocks = []
        if hasattr(self, "accounts_search_input"):
            self.accounts_search_input.clear()
        self.accounts_status_label.setText("")
        self._update_accounts_stats()
        self._update_accounts_preview()
    
    def closeEvent(self, event):
        """Garante que a thread seja parada ao fechar"""
        if self.generator_thread and self.is_generating:
            self.generator_thread.stop()
            self.generator_thread.wait(2000)  # Espera até 2 segundos
        if self.address_thread and self.is_generating_addresses:
            self.address_thread.stop()
            self.address_thread.wait(2000)
        event.accept()


def create_app_icon():
    """Cria um ícone para a aplicação programaticamente"""
    pixmap = QPixmap(64, 64)
    pixmap.fill(Qt.transparent)
    
    painter = QPainter(pixmap)
    painter.setRenderHint(QPainter.Antialiasing)
    
    gradient = QLinearGradient(0, 0, 64, 64)
    gradient.setColorAt(0, QColor("#06b6d4"))
    gradient.setColorAt(1, QColor("#6d28d9"))
    
    painter.setBrush(QBrush(gradient))
    painter.setPen(QPen(Qt.transparent))
    painter.drawEllipse(4, 4, 56, 56)
    
    painter.setPen(QPen(QColor("#ffffff")))
    font = QFont("Arial", 20, QFont.Bold)
    painter.setFont(font)
    painter.drawText(pixmap.rect(), Qt.AlignCenter, "TC")
    
    painter.end()
    
    return QIcon(pixmap)



# ═══════════════════════════════════════════════════════════════
#  CONSTANTES DE DESIGN GLOBAL
# ═══════════════════════════════════════════════════════════════
APP_COLORS = {
    "bg_deep":    "#07080f",
    "bg_base":    "#0a0e1a",
    "bg_panel":   "#0f1626",
    "bg_card":    "#131d2e",
    "bg_hover":   "#1a2540",
    "border":     "rgba(6,182,212,0.12)",
    "border_hi":  "rgba(6,182,212,0.35)",
    "accent":     "#06b6d4",
    "accent_dim": "#0891b2",
    "accent_glow":"rgba(6,182,212,0.08)",
    "text_hi":    "#f1f5f9",
    "text_mid":   "#94a3b8",
    "text_lo":    "#475569",
    "green":      "#10b981",
    "red":        "#f43f5e",
    "amber":      "#f59e0b",
    "purple":     "#8b5cf6",
}

# QSS global ultra-clean, substituindo o DARK_STYLE herdado
GLOBAL_QSS = """
QMainWindow, QWidget {
    background-color: #07080f;
    color: #f1f5f9;
    font-family: 'Segoe UI', 'Inter', 'Arial', sans-serif;
}
QScrollBar:vertical {
    background: #0f1626; width: 7px; margin: 0;
    border-radius: 3px;
}
QScrollBar::handle:vertical {
    background: #1a2540; border-radius: 3px; min-height: 24px;
}
QScrollBar::handle:vertical:hover { background: #06b6d4; }
QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0; }
QScrollBar:horizontal {
    background: #0f1626; height: 7px; margin: 0; border-radius: 3px;
}
QScrollBar::handle:horizontal {
    background: #1a2540; border-radius: 3px; min-width: 24px;
}
QScrollBar::handle:horizontal:hover { background: #06b6d4; }
QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0; }
QStatusBar {
    background-color: #07080f;
    color: #475569;
    font-size: 11px;
    border-top: 1px solid rgba(6,182,212,0.08);
}
QStatusBar::item { border: none; }
QToolTip {
    background-color: #131d2e;
    color: #f1f5f9;
    border: 1px solid rgba(6,182,212,0.3);
    border-radius: 6px;
    padding: 6px 10px;
    font-size: 12px;
}
QLineEdit, QTextEdit, QPlainTextEdit, QComboBox, QSpinBox {
    background-color: #0b1626;
    color: #e2e8f0;
    border: 1px solid rgba(125,211,252,0.16);
    border-radius: 7px;
    selection-background-color: #0e7490;
    selection-color: #ffffff;
}
QLineEdit:focus, QTextEdit:focus, QPlainTextEdit:focus, QComboBox:focus, QSpinBox:focus {
    border-color: rgba(34,211,238,0.55);
}
QMenu {
    background-color: #0b1626;
    color: #e2e8f0;
    border: 1px solid rgba(125,211,252,0.18);
    border-radius: 8px;
    padding: 5px;
}
QMenu::item {
    padding: 7px 18px;
    border-radius: 6px;
}
QMenu::item:selected {
    background: rgba(6,182,212,0.16);
    color: #e0f2fe;
}
"""

TAB_SIDEBAR_QSS = """
QTabWidget::pane {
    border: none;
    background: transparent;
}
QTabBar {
    background: transparent;
}
QTabBar::tab {
    background: transparent;
    color: #475569;
    padding: 14px 0px;
    margin: 2px 0;
    border: none;
    border-left: 3px solid transparent;
    font-size: 12px;
    font-weight: 500;
    text-align: left;
}
QTabBar::tab:selected {
    color: #06b6d4;
    border-left: 3px solid #06b6d4;
    background: rgba(6,182,212,0.06);
    font-weight: 600;
}
QTabBar::tab:hover:!selected {
    color: #94a3b8;
    background: rgba(255,255,255,0.03);
}
"""

TAB_TOP_QSS = """
QTabWidget::pane {
    border: none;
    background: transparent;
    margin-top: 0;
}
QTabBar {
    background: transparent;
}
QTabBar::tab {
    background: transparent;
    color: #475569;
    padding: 10px 18px;
    margin-right: 2px;
    border: none;
    border-bottom: 2px solid transparent;
    font-size: 12px;
    font-weight: 500;
}
QTabBar::tab:selected {
    color: #06b6d4;
    border-bottom: 2px solid #06b6d4;
    font-weight: 600;
}
QTabBar::tab:hover:!selected { color: #94a3b8; }
"""

def _btn(text, color="#06b6d4", text_color="#07080f", icon=""):
    """Helper para criar QPushButton estilizado."""
    b = QPushButton(f"{icon} {text}".strip() if icon else text)
    b.setStyleSheet(f"""
        QPushButton {{
            background-color: {color};
            color: {text_color};
            border: none;
            border-radius: 10px;
            padding: 9px 18px;
            font-size: 12px;
            font-weight: 600;
        }}
        QPushButton:hover {{ background-color: {color}cc; }}
        QPushButton:pressed {{ background-color: {color}99; }}
        QPushButton:disabled {{ background-color: #1a2540; color: #475569; }}
    """)
    return b

def _ghost_btn(text, icon=""):
    """Botão fantasma (sem fundo)."""
    b = QPushButton(f"{icon} {text}".strip() if icon else text)
    b.setStyleSheet("""
        QPushButton {
            background: rgba(255,255,255,0.04);
            color: #94a3b8;
            border: 1px solid rgba(6,182,212,0.15);
            border-radius: 9px;
            padding: 8px 14px;
            font-size: 11px;
            font-weight: 500;
        }
        QPushButton:hover {
            background: rgba(6,182,212,0.1);
            border-color: rgba(6,182,212,0.4);
            color: #22d3ee;
        }
        QPushButton:checked {
            background: rgba(6,182,212,0.15);
            border-color: #06b6d4;
            color: #06b6d4;
        }
    """)
    return b

def _card(radius=14):
    """Cria um QFrame estilo cartão."""
    f = QFrame()
    f.setStyleSheet(f"""
        QFrame {{
            background-color: #131d2e;
            border: 1px solid rgba(6,182,212,0.1);
            border-radius: {radius}px;
        }}
    """)
    return f

def _separator(horizontal=True):
    f = QFrame()
    f.setFrameShape(QFrame.HLine if horizontal else QFrame.VLine)
    f.setStyleSheet("QFrame { background: rgba(6,182,212,0.08); border: none; max-height: 1px; }")
    return f

def _log_compact_error(context, exc):
    """Registra falhas do painel compacto sem derrubar o app."""
    log_exception(BASE_DIR, "compact_panel_errors.log", context, exc)

def _set_clipboard_text_safe(text):
    """Copia texto usando apenas Qt; evita chamadas ctypes que podem crashar."""
    return set_clipboard_text(text)

def _label(text, size=12, color="#94a3b8", bold=False, mono=False):
    l = QLabel(text)
    weight = "600" if bold else "400"
    family = "'Consolas', 'SF Mono', monospace" if mono else "inherit"
    l.setStyleSheet(f"color:{color}; font-size:{size}px; font-weight:{weight}; font-family:{family}; background:transparent; border:none;")
    return l

def _field_row(icon_text, field_widget, copy_cb):
    """Linha de campo com label + widget + botão copiar."""
    row = QHBoxLayout()
    row.setSpacing(6)
    row.setContentsMargins(0, 1, 0, 1)
    lbl = QLabel(icon_text)
    lbl.setFixedWidth(68)
    lbl.setCursor(Qt.PointingHandCursor)
    lbl.setToolTip(f"Copiar {icon_text}")
    lbl.setStyleSheet("color:#94a3b8; font-size:11px; background:transparent; border:none;")
    cp = QPushButton("Copiar")
    cp.setFixedSize(52, 24)
    cp.setToolTip(f"Copiar {icon_text}")
    cp.setStyleSheet("""
        QPushButton {
            background: rgba(6,182,212,0.07);
            border: 1px solid rgba(6,182,212,0.15);
            border-radius: 5px;
            font-size: 10px;
            font-weight: 700;
            color: #06b6d4;
        }
        QPushButton:hover { background: rgba(6,182,212,0.2); }
    """)
    field_widget.setCursorPosition(0)
    field_widget.setCursor(Qt.PointingHandCursor)
    field_widget.setToolTip(f"Clique para copiar {icon_text}")
    field_widget.mousePressEvent = lambda ev: copy_cb()
    lbl.mousePressEvent = lambda ev: copy_cb()
    cp.clicked.connect(lambda checked=False: copy_cb())
    row.addWidget(lbl)
    row.addWidget(field_widget, 1)
    row.addWidget(cp)
    return row


# ═══════════════════════════════════════════════════════════════
#  SIDEBAR NAVEGAÇÃO (substituindo QTabBar lateral)
# ═══════════════════════════════════════════════════════════════
class SidebarNav(QFrame):
    tab_changed = pyqtSignal(int)
    tool_requested = pyqtSignal(int)

    NAV_ITEMS = [
        ("🏠", "Início"),
        ("🎲", "Gerador"),
        ("🌐", "Navegador"),
        ("🤖", "IA Local"),
        ("🍦", "Crunchyroll"),
        ("📝", "Notas"),
        ("⚙️", "Config"),
    ]
    TOOL_ITEMS = [
        ("💳", "Cartões", 0),
        ("🏠", "CEP", 1),
        ("📧", "Organizador", 2),
        ("🗂️", "Formatar", 3),
        ("✅", "CPF/CNPJ", 4),
        ("🎭", "Fake", 5),
        ("⚡", "Desempenho", 6),
        ("🧹", "Dados Pro", 7),
        ("✍️", "Português", 8),
    ]
    SLIM_W = 56
    FULL_W = 156

    def __init__(self, parent=None):
        super().__init__(parent)
        self.nav_items = [
            item for item in self.NAV_ITEMS
            if CRUNCHYROLL_AVAILABLE or item[1] != "Crunchyroll"
        ]
        self._slim = False
        self._current = 0
        self._buttons = []
        self._apply_width()
        self.setStyleSheet(
            "QFrame{background-color:#08111f;"
            "border-right:1px solid rgba(125,211,252,0.10);}"
        )
        self._build()

    def _apply_width(self):
        self.setFixedWidth(self.SLIM_W if self._slim else self.FULL_W)

    def _build(self):
        # Clear old layout
        old = self.layout()
        if old:
            while old.count():
                item = old.takeAt(0)
                w = item.widget()
                if w:
                    w.setParent(None)
            QWidget().setLayout(old)

        lay = QVBoxLayout(self)
        lay.setContentsMargins(8, 10, 8, 10)
        lay.setSpacing(4)

        logo = QLabel("TC" if self._slim else "Telegram Pro")
        logo.setAlignment(Qt.AlignCenter)
        logo.setFixedHeight(38)
        logo.setStyleSheet(
            "color:#e0f2fe;font-size:13px;font-weight:800;"
            "background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0e7490,stop:1 #155e75);"
            "border-radius:10px;border:1px solid rgba(125,211,252,0.22);"
        )
        lay.addWidget(logo)
        lay.addSpacing(4)

        self._buttons = []
        for i, (icon, label) in enumerate(self.nav_items):
            btn = self._make_nav_btn(icon, label, i)
            self._buttons.append(btn)
            lay.addWidget(btn)

        lay.addSpacing(8)
        if not self._slim:
            tools_lbl = QLabel("FERRAMENTAS")
            tools_lbl.setStyleSheet(
                "color:#475569;font-size:10px;font-weight:800;"
                "letter-spacing:1px;background:transparent;border:none;"
                "padding:2px 4px;"
            )
            lay.addWidget(tools_lbl)
        for icon, label, tab_idx in self.TOOL_ITEMS:
            lay.addWidget(self._make_tool_btn(icon, label, tab_idx))

        lay.addStretch()

        self._pin_btn     = self._make_ctrl_btn("📌", "Fixar no topo (sempre visível)")
        self._fs_btn      = self._make_ctrl_btn("⛶", "Tela cheia  —  F11")
        self._compact_btn = self._make_ctrl_btn("▣", "Modo compacto flutuante")
        for b in (self._pin_btn, self._fs_btn, self._compact_btn):
            lay.addWidget(b)

        self._set_active(self._current)

    def _make_nav_btn(self, icon, label, idx):
        w = self.SLIM_W - 16 if self._slim else self.FULL_W - 16
        if self._slim:
            btn = QPushButton(icon)
            btn.setFixedSize(w, 38)
        else:
            btn = QPushButton(f"{icon}  {label}")
            btn.setFixedSize(w, 38)
        btn.setToolTip(label)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda _, i=idx: self._on_click(i))
        btn.setStyleSheet(self._inactive_qss())
        return btn

    def _make_ctrl_btn(self, icon, tip):
        w = self.SLIM_W - 16 if self._slim else self.FULL_W - 16
        btn = QPushButton(icon)
        btn.setFixedSize(w, 28)
        btn.setToolTip(tip)
        btn.setCursor(Qt.PointingHandCursor)
        btn.setStyleSheet(
            "QPushButton{background:rgba(148,163,184,0.04);color:#64748b;"
            "border:1px solid rgba(148,163,184,0.08);"
            "border-radius:8px;font-size:14px;}"
            "QPushButton:hover{background:rgba(6,182,212,0.12);color:#7dd3fc;"
            "border-color:rgba(125,211,252,0.24);}"
            "QPushButton:checked{color:#f43f5e;}"
        )
        return btn

    def _make_tool_btn(self, icon, label, tab_idx):
        w = self.SLIM_W - 16 if self._slim else self.FULL_W - 16
        text = icon if self._slim else f"{icon}  {label}"
        btn = QPushButton(text)
        btn.setFixedSize(w, 28)
        btn.setToolTip(label)
        btn.setCursor(Qt.PointingHandCursor)
        btn.clicked.connect(lambda _, i=tab_idx: self.tool_requested.emit(i))
        if self._slim:
            btn.setStyleSheet(
                "QPushButton{background:rgba(148,163,184,0.035);color:#64748b;"
                "border:1px solid rgba(148,163,184,0.07);border-radius:8px;"
                "font-size:14px;}"
                "QPushButton:hover{background:rgba(6,182,212,0.12);"
                "color:#7dd3fc;border-color:rgba(125,211,252,0.22);}"
            )
        else:
            btn.setStyleSheet(
                "QPushButton{background:rgba(148,163,184,0.035);color:#7c8da3;"
                "border:1px solid rgba(148,163,184,0.07);border-radius:8px;"
                "font-size:11px;font-weight:600;text-align:left;padding:2px 9px;}"
                "QPushButton:hover{background:rgba(6,182,212,0.12);"
                "color:#e0f2fe;border-color:rgba(125,211,252,0.22);}"
            )
        return btn

    def _inactive_qss(self):
        if self._slim:
            return ("QPushButton{background:transparent;color:#475569;border:none;"
                    "border-radius:9px;font-size:17px;padding:2px 0;}"
                    "QPushButton:hover{background:rgba(6,182,212,0.07);color:#94a3b8;}")
        return ("QPushButton{background:transparent;color:#94a3b8;"
                "border:1px solid transparent;border-radius:9px;font-size:12px;"
                "padding:2px 10px;"
                "text-align:left;}"
                "QPushButton:hover{background:rgba(6,182,212,0.08);"
                "color:#e0f2fe;border-color:rgba(125,211,252,0.14);}")

    def _active_qss(self):
        if self._slim:
            return ("QPushButton{background:rgba(6,182,212,0.13);color:#06b6d4;"
                    "border:1px solid rgba(6,182,212,0.26);border-radius:9px;"
                    "font-size:17px;font-weight:700;padding:2px 0;}")
        return ("QPushButton{background:rgba(6,182,212,0.15);color:#67e8f9;"
                "border:1px solid rgba(125,211,252,0.30);border-radius:9px;"
                "font-size:12px;font-weight:700;padding:2px 10px;"
                "text-align:left;}")

    def _on_click(self, idx):
        self._set_active(idx)
        self.tab_changed.emit(idx)

    def _set_active(self, idx):
        for i, btn in enumerate(self._buttons):
            btn.setStyleSheet(self._active_qss() if i == idx else self._inactive_qss())
        self._current = idx

    def set_current(self, idx):
        self._set_active(idx)

    def set_collapsed(self, slim: bool):
        if slim == self._slim:
            return
        self._slim = slim
        self._apply_width()
        self._build()

    @property
    def pin_btn(self): return self._pin_btn
    @property
    def fs_btn(self): return self._fs_btn
    @property
    def compact_btn(self): return self._compact_btn


# ═══════════════════════════════════════════════════════════════
#  HEADER BAR (faixa superior com título + controles)
# ═══════════════════════════════════════════════════════════════
class HeaderBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(50)
        self.setStyleSheet("""
            QFrame {
                background-color: #08111f;
                border-bottom: 1px solid rgba(125,211,252,0.10);
            }
        """)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(18, 0, 16, 0)
        lay.setSpacing(10)

        self.title_lbl = QLabel("🏠  Painel Inicial")
        self.title_lbl.setStyleSheet(
            "color:#f8fafc; font-size:15px; font-weight:700;"
            " background:transparent; border:none; min-width:180px;"
        )
        lay.addWidget(self.title_lbl)
        lay.addStretch()

        # Stats individuais como mini-badges (se escondem se pequeno)
        self._stat_widgets = []
        stat_defs = [
            ("📋", "#94a3b8"), ("✅", "#10b981"), ("📅", "#8b5cf6"),
            ("📞", "#f43f5e"), ("⭐", "#f59e0b"),
        ]
        for icon, color in stat_defs:
            lbl = QLabel(f"{icon} —")
            lbl.setStyleSheet(
                f"color:{color}; font-size:11px; font-weight:700;"
                " background:rgba(148,163,184,0.055);"
                " border:1px solid rgba(148,163,184,0.10);"
                " border-radius:8px; padding:5px 8px;"
            )
            lbl.setMinimumWidth(48)
            lay.addWidget(lbl)
            self._stat_widgets.append(lbl)

    def set_title(self, text):
        self.title_lbl.setText(text)

    def set_stats(self, text):
        # Extrai números do texto de stats para badges individuais
        import re
        nums = re.findall(r"\d+", text)
        for i, w in enumerate(self._stat_widgets):
            parts = w.text().split()
            icon = parts[0] if parts else ""
            val = nums[i] if i < len(nums) else "—"
            w.setText(f"{icon} {val}")

    def resizeEvent(self, event):
        """Esconde badges de stats progressivamente conforme janela encolhe."""
        super().resizeEvent(event)
        w = event.size().width()
        for i, lbl in enumerate(self._stat_widgets):
            # Esconde os últimos badges primeiro
            threshold = 400 + i * 60
            lbl.setVisible(w > threshold)


# ═══════════════════════════════════════════════════════════════
#  STATUS BAR MELHORADA
# ═══════════════════════════════════════════════════════════════
class AppStatusBar(QFrame):
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setFixedHeight(28)
        self.setStyleSheet("""
            QFrame {
                background-color: #08111f;
                border-top: 1px solid rgba(125,211,252,0.10);
            }
        """)
        lay = QHBoxLayout(self)
        lay.setContentsMargins(16, 0, 16, 0)
        lay.setSpacing(16)

        self._msg = QLabel("✅ Pronto")
        self._msg.setStyleSheet("color:#94a3b8; font-size:11px; background:transparent; border:none;")
        lay.addWidget(self._msg)

        lay.addStretch()

        self._version = QLabel("v11.0 Pro")
        self._version.setStyleSheet("color:#38bdf8; font-size:10px; font-weight:700; background:transparent; border:none;")
        lay.addWidget(self._version)

    def showMessage(self, text, timeout=0):
        self._msg.setText(text)
        if timeout > 0:
            QTimer.singleShot(timeout, lambda: self._msg.setText("✅ Pronto"))


# ═══════════════════════════════════════════════════════════════
#  MODO COMPACTO — widget flutuante moderno
# ═══════════════════════════════════════════════════════════════
class CompactWidget(QFrame):
    """Painel compacto lateral focado em nome, idade, score e cidade."""

    UF_NAMES = {
        "AC": "Acre", "AL": "Alagoas", "AP": "Amapá", "AM": "Amazonas",
        "BA": "Bahia", "CE": "Ceará", "DF": "Distrito Federal", "ES": "Espírito Santo",
        "GO": "Goiás", "MA": "Maranhão", "MT": "Mato Grosso", "MS": "Mato Grosso do Sul",
        "MG": "Minas Gerais", "PA": "Pará", "PB": "Paraíba", "PR": "Paraná",
        "PE": "Pernambuco", "PI": "Piauí", "RJ": "Rio de Janeiro", "RN": "Rio Grande do Norte",
        "RS": "Rio Grande do Sul", "RO": "Rondônia", "RR": "Roraima", "SC": "Santa Catarina",
        "SP": "São Paulo", "SE": "Sergipe", "TO": "Tocantins",
    }

    def __init__(self, db, address_gen, parent=None):
        super().__init__(None)
        self._main_window = parent
        self.db = db
        self.address_gen = address_gen
        self._current_pair = None
        self._drag_pos = None

        self.setWindowFlags(Qt.Window | Qt.FramelessWindowHint | Qt.WindowStaysOnTopHint)
        self.setAttribute(Qt.WA_TranslucentBackground)
        self.setAttribute(Qt.WA_QuitOnClose, False)
        self.setFixedSize(360, 590)
        self._build()

    def _build(self):
        outer = QVBoxLayout(self)
        outer.setContentsMargins(8, 8, 8, 8)
        outer.setSpacing(0)

        # Container com sombra simulada via borda
        container = QFrame()
        container.setObjectName("compact_container")
        container.setStyleSheet("""
            QFrame#compact_container {
                background-color: #08111f;
                border: 1px solid rgba(125,211,252,0.28);
                border-radius: 18px;
            }
        """)
        c_lay = QVBoxLayout(container)
        c_lay.setContentsMargins(0, 0, 0, 0)
        c_lay.setSpacing(0)

        # ── Header arrastável
        hdr = QFrame()
        hdr.setFixedHeight(46)
        hdr.setStyleSheet("""
            QFrame {
                background: qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0e7490,stop:1 #155e75);
                border-radius: 18px 18px 0 0;
                border-bottom: 1px solid rgba(125,211,252,0.20);
            }
        """)
        hdr_lay = QHBoxLayout(hdr)
        hdr_lay.setContentsMargins(12, 0, 8, 0)
        title = QLabel("Painel Compacto")
        title.setStyleSheet("color:#e0f2fe; font-size:13px; font-weight:900; background:transparent; border:none;")
        hdr_lay.addWidget(title)
        hdr_lay.addStretch()
        restore_btn = QPushButton("↗")
        restore_btn.setFixedSize(25, 25)
        restore_btn.setToolTip("Mostrar janela principal")
        restore_btn.setStyleSheet("""
            QPushButton {
                background: rgba(224,242,254,0.14);
                color: #e0f2fe;
                border: 1px solid rgba(224,242,254,0.20);
                border-radius: 8px;
                font-size: 13px;
                font-weight: 800;
            }
            QPushButton:hover { background: rgba(224,242,254,0.24); }
        """)
        restore_btn.clicked.connect(self._restore_main)
        hdr_lay.addWidget(restore_btn)
        close_btn = QPushButton("✕")
        close_btn.setFixedSize(25, 25)
        close_btn.setStyleSheet("""
            QPushButton {
                background: rgba(244,63,94,0.15);
                color: #f43f5e;
                border: none;
                border-radius: 8px;
                font-size: 12px;
                font-weight: 700;
            }
            QPushButton:hover { background: #f43f5e; color: white; }
        """)
        close_btn.setToolTip("Fechar painel compacto e voltar ao app")
        close_btn.clicked.connect(self._close_compact)
        hdr_lay.addWidget(close_btn)
        hdr.mousePressEvent = self._drag_start
        hdr.mouseMoveEvent = self._drag_move
        c_lay.addWidget(hdr)

        # Conteudo fixo: sem scroll, tudo visivel no painel.
        body = QWidget()
        body.setStyleSheet("background: transparent;")
        b_lay = QVBoxLayout(body)
        b_lay.setContentsMargins(10, 8, 10, 10)
        b_lay.setSpacing(6)

        self._status = QLabel("Pronto")
        self._status.setStyleSheet(
            "color:#94a3b8;font-size:11px;background:rgba(148,163,184,0.06);"
            "border:1px solid rgba(148,163,184,0.10);border-radius:8px;padding:7px 9px;"
        )
        b_lay.addWidget(self._status)

        # ── Seção Pares
        b_lay.addWidget(self._section_header("Gerador de Pares"))
        self._fields = {}
        for key, icon_txt in [("nome","Nome"), ("cpf","CPF"), ("idade","Idade"), ("score","Score")]:
            f = QLineEdit()
            f.setReadOnly(True)
            f.setPlaceholderText("—")
            f.setFixedHeight(27 if key != "nome" else 32)
            f.setStyleSheet("""
                QLineEdit {
                    background: #0f1626;
                    border: 1px solid rgba(6,182,212,0.12);
                    border-radius: 6px;
                    color: #22d3ee;
                    font-size: 11px;
                    padding: 3px 8px;
                    font-family: 'Consolas', monospace;
                }
            """)
            self._fields[key] = f
            row = _field_row(icon_txt, f, lambda v=f, label=icon_txt: self._copy_field(label, v))
            b_lay.addLayout(row)

        # Botões pares
        pair_btns = QHBoxLayout()
        pair_btns.setSpacing(6)
        gen_btn = QPushButton("Gerar")
        gen_btn.setFixedHeight(30)
        gen_btn.setStyleSheet("QPushButton{background:#059669;color:white;border:none;"
                              "border-radius:7px;font-size:12px;font-weight:700;}"
                              "QPushButton:hover{background:#047857;}")
        gen_btn.clicked.connect(self._gen_pair)
        copy_all = QPushButton("Copiar")
        copy_all.setFixedHeight(30)
        copy_all.setStyleSheet("QPushButton{background:#0891b2;color:white;border:none;"
                               "border-radius:7px;font-size:12px;font-weight:700;}"
                               "QPushButton:hover{background:#0e7490;}")
        copy_all.clicked.connect(self._copy_pair)
        pair_btns.addWidget(gen_btn)
        pair_btns.addWidget(copy_all)
        b_lay.addLayout(pair_btns)

        b_lay.addWidget(_separator())

        # ── Seção CEP
        b_lay.addWidget(self._section_header("Cidade / Estado"))

        self._cep_estado = QComboBox()
        self._cep_estado.addItem("Todos os Estados", None)
        for uf, nome in self.UF_NAMES.items():
            self._cep_estado.addItem(f"{uf} — {nome}", uf)
        self._cep_estado.setFixedHeight(27)
        self._cep_estado.setStyleSheet("""
            QComboBox {
                background: #0f1626;
                border: 1px solid rgba(6,182,212,0.12);
                border-radius: 6px;
                color: #f1f5f9;
                font-size: 11px;
                padding: 3px 8px;
            }
            QComboBox::drop-down { border: none; }
            QComboBox QAbstractItemView {
                background: #131d2e;
                border: 1px solid rgba(6,182,212,0.2);
                color: #f1f5f9;
                selection-background-color: rgba(6,182,212,0.2);
            }
        """)
        b_lay.addWidget(self._cep_estado)

        self._cep_fields = {}
        for key, icon_txt in [("endereco","Endereço"),("cidade","Cidade"),("estado","Estado"),("cep","CEP")]:
            f = QLineEdit()
            f.setReadOnly(True)
            f.setPlaceholderText("—")
            f.setFixedHeight(27)
            f.setStyleSheet("""
                QLineEdit {
                    background: #0f1626;
                    border: 1px solid rgba(6,182,212,0.12);
                    border-radius: 6px;
                    color: #10b981;
                    font-size: 11px;
                    padding: 3px 8px;
                    font-family: 'Consolas', monospace;
                }
            """)
            self._cep_fields[key] = f
            row = _field_row(icon_txt, f, lambda v=f, label=icon_txt: self._copy_field(label, v))
            b_lay.addLayout(row)

        cep_btns = QHBoxLayout()
        cep_btns.setSpacing(6)
        cep_gen = QPushButton("Gerar cidade")
        cep_gen.setFixedHeight(30)
        cep_gen.setStyleSheet("QPushButton{background:#0891b2;color:white;border:none;"
                              "border-radius:7px;font-size:12px;font-weight:700;}"
                              "QPushButton:hover{background:#0e7490;}")
        cep_gen.clicked.connect(self._gen_cep)
        cep_copy = QPushButton("Copiar")
        cep_copy.setFixedHeight(30)
        cep_copy.setStyleSheet("QPushButton{background:#7c3aed;color:white;border:none;"
                               "border-radius:7px;font-size:12px;font-weight:700;}"
                               "QPushButton:hover{background:#6d28d9;}")
        cep_copy.clicked.connect(self._copy_cep)
        cep_btns.addWidget(cep_gen)
        cep_btns.addWidget(cep_copy)
        b_lay.addLayout(cep_btns)

        b_lay.addStretch()
        c_lay.addWidget(body, 1)

        outer.addWidget(container)

    def _section_header(self, text):
        l = QLabel(text)
        l.setStyleSheet("color:#06b6d4; font-size:11px; font-weight:900; background:transparent; border:none; padding:1px 0;")
        return l

    def _state_name(self, uf, fallback=""):
        uf = (uf or "").strip().upper()
        return self.UF_NAMES.get(uf) or fallback or uf

    def _set_status(self, text, color="#94a3b8"):
        self._status.setText(text)
        self._status.setStyleSheet(
            f"color:{color};font-size:11px;background:rgba(148,163,184,0.06);"
            "border:1px solid rgba(148,163,184,0.10);border-radius:8px;padding:7px 9px;"
        )

    def _keep_app_alive(self):
        QApplication.setQuitOnLastWindowClosed(False)

    def _copy_text(self, text, status="Copiado"):
        try:
            self._keep_app_alive()
            text = text or ""
            if not text.strip():
                self._set_status("Nada para copiar", "#f59e0b")
                return
            _set_clipboard_text_safe(text)
            self._set_status(status, "#10b981")
            if not self.isVisible():
                self.show()
            QTimer.singleShot(0, self.raise_)
            QTimer.singleShot(0, self.activateWindow)
        except Exception as exc:
            _log_compact_error("copiar texto do painel compacto", exc)
            self._set_status("Erro ao copiar; veja _temp/compact_panel_errors.log", "#f43f5e")

    def _copy_field(self, label, field):
        self._copy_text(field.text(), f"{label} copiado")

    def _main(self):
        return self._main_window or self.parent()

    def _restore_main(self):
        parent = self._main()
        if parent:
            self.hide()
            if hasattr(parent, "is_compact_mode"):
                parent.is_compact_mode = False
            QApplication.setQuitOnLastWindowClosed(True)
            parent.showNormal()
            parent.activateWindow()
            parent.raise_()
        self._set_status("Janela principal aberta", "#7dd3fc")

    def _close_compact(self):
        parent = self._main()
        self.hide()
        if parent:
            if hasattr(parent, "is_compact_mode"):
                parent.is_compact_mode = False
            QApplication.setQuitOnLastWindowClosed(True)
            parent.showNormal()
            parent.activateWindow()
            parent.raise_()

    def _open_tool(self, tab_idx):
        parent = self._main()
        if parent and hasattr(parent, "show_tools_tab"):
            parent.showNormal()
            parent.show_tools_tab(tab_idx)
            parent.activateWindow()
            parent.raise_()
            self._set_status("Ferramenta aberta na janela principal", "#7dd3fc")

    def _open_notes(self):
        parent = self._main()
        if parent and hasattr(parent, "open_notes_page"):
            parent.showNormal()
            parent.open_notes_page()
            parent.activateWindow()
            parent.raise_()
            self._set_status("Notas abertas", "#7dd3fc")

    def _open_config(self):
        parent = self._main()
        if parent and hasattr(parent, "open_page_by_name"):
            parent.showNormal()
            parent.open_page_by_name("Config")
            parent.activateWindow()
            parent.raise_()
            self._set_status("Config/Backup aberto", "#7dd3fc")
        elif parent and hasattr(parent, "main_tabs"):
            notes_idx = parent.main_tabs.count() - 1
            parent.showNormal()
            parent.main_tabs.setCurrentIndex(notes_idx)
            parent.sidebar.set_current(notes_idx)
            parent.header.set_title(parent.tab_titles[notes_idx] if notes_idx < len(parent.tab_titles) else "📝  Bloco de Notas")
            parent.activateWindow()
            parent.raise_()
            self._set_status("Notas abertas", "#7dd3fc")

    def _gen_pair(self):
        pair = self.db.get_random_pair({})
        if pair:
            self._current_pair = pair
            self._fields["nome"].setText(pair.get("nome", ""))
            self._fields["cpf"].setText(pair.get("cpf", ""))
            self._fields["idade"].setText(str(pair.get("idade", "")) + " anos" if pair.get("idade") else "")
            self._fields["score"].setText(str(pair.get("score", "")))
            self._set_status("Par gerado com sucesso", "#10b981")
        else:
            self._set_status("Nenhum registro encontrado", "#f59e0b")

    def _copy_pair(self):
        if not self._current_pair:
            return
        p = self._current_pair
        lines = []
        if p.get("nome"): lines.append(f"👤 {p['nome']}")
        if p.get("cpf"):  lines.append(f"🆔 {p['cpf']}")
        if p.get("idade"): lines.append(f"🎂 {p['idade']} anos")
        if p.get("nascimento"): lines.append(f"📅 {p['nascimento']}")
        if p.get("telefone"): lines.append(f"📞 {p['telefone']}")
        if p.get("score"): lines.append(f"⭐ {p['score']}")
        self._copy_text("\n".join(lines), "Par copiado")

    def _gen_cep(self):
        try:
            uf = self._cep_estado.currentData()
            end = self.address_gen.gerar_endereco(uf, None, True)
            if end:
                estado_nome = self._state_name(end.uf, getattr(end, "estado", ""))
                endereco_linha = end.logradouro
                if getattr(end, "bairro", ""):
                    endereco_linha = f"{endereco_linha} - {end.bairro}" if endereco_linha else end.bairro
                self._cep_fields["endereco"].setText(endereco_linha)
                self._cep_fields["cep"].setText(end.cep)
                self._cep_fields["cidade"].setText(end.cidade)
                self._cep_fields["estado"].setText(estado_nome)
                if getattr(self.address_gen, "last_source", "") == "reserva":
                    self._set_status("Cidade reserva usada", "#fbbf24")
                else:
                    self._set_status("Cidade gerada", "#10b981")
        except Exception as e:
            _log_compact_error("gerar CEP no painel compacto", e)
            self._set_status(f"Erro ao gerar CEP: {e}", "#f43f5e")

    def _copy_cep(self):
        try:
            parts = [
                self._cep_fields["endereco"].text(),
                self._cep_fields["cidade"].text(),
                self._cep_fields["estado"].text(),
                f"CEP: {self._cep_fields['cep'].text()}",
            ]
            self._copy_text("\n".join(p for p in parts if p), "Cidade copiada")
        except Exception as e:
            _log_compact_error("copiar CEP no painel compacto", e)
            self._set_status("Erro ao copiar CEP", "#f43f5e")

    # Drag para mover janela
    def _drag_start(self, ev):
        if ev.button() == Qt.LeftButton:
            self._drag_pos = ev.globalPos() - self.frameGeometry().topLeft()

    def _drag_move(self, ev):
        if ev.buttons() == Qt.LeftButton and self._drag_pos:
            self.move(ev.globalPos() - self._drag_pos)

    def update_db(self, db):
        self.db = db


# ═══════════════════════════════════════════════════════════════
#  SIMPLE APP — janela principal redesenhada
# ═══════════════════════════════════════════════════════════════
class SimpleApp(QMainWindow):
    """Janela principal — design lateral moderno com sidebar de ícones."""

    NORMAL_SIZE = (1280, 860)
    COMPACT_SIZE = (400, 600)

    # Títulos das abas para o header
    TAB_TITLES = {
        "inicio": "🏠  Painel Inicial",
        "gerador": "🎲  Gerador de Pares",
        "ferramentas": "🛠️  Ferramentas",
        "navegador": "🌐  Navegador Seguro",
        "ia": "🤖  IA Local",
        "crunchyroll": "🍦  Crunchyroll",
        "notas": "📝  Bloco de Notas",
        "config": "⚙️  Configurações",
    }

    def __init__(self):
        super().__init__()
        self.config_manager = ConfigManager()
        self.db = self._get_database()
        self.collector_thread = None
        self.current_pair = None
        self._address_gen = AddressGenerator()

        self.is_always_on_top = False
        self.is_fullscreen = False
        self.is_compact_mode = False
        self._force_quit = False
        self.settings = QSettings("TelegramCollector", "Pro")

        self.mostrar_nome = True
        self.mostrar_cpf = True
        self.mostrar_idade = True
        self.mostrar_data = True
        self.mostrar_telefone = True
        self.mostrar_score = True
        self.tab_titles = [
            self.TAB_TITLES["inicio"],
            self.TAB_TITLES["gerador"],
            self.TAB_TITLES["navegador"],
            self.TAB_TITLES["ia"],
        ]
        if CRUNCHYROLL_AVAILABLE:
            self.tab_titles.append(self.TAB_TITLES["crunchyroll"])
        self.tab_titles.append(self.TAB_TITLES["notas"])
        self.tab_titles.append(self.TAB_TITLES["config"])

        self._setup_window()
        self.init_ui()
        self._setup_tray()
        self.check_configuration()
        self._load_state()

    # ─── Janela ──────────────────────────────────────────────
    def _setup_window(self):
        self.setWindowTitle("Telegram Collector Pro  v11.0")
        self.setGeometry(80, 80, *self.NORMAL_SIZE)
        self.setMinimumSize(900, 600)
        self.setStyleSheet(GLOBAL_QSS)

        # Ícone
        self.app_icon = create_app_icon()
        self.setWindowIcon(self.app_icon)
        if sys.platform == "win32":
            try:
                ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(
                    "TelegramCollector.Pro.v11.0"
                )
            except Exception:
                pass

    # ─── UI principal ─────────────────────────────────────────
    def init_ui(self):
        root = QWidget()
        self.setCentralWidget(root)
        root_lay = QVBoxLayout(root)
        root_lay.setContentsMargins(0, 0, 0, 0)
        root_lay.setSpacing(0)
        root.setContentsMargins(0, 0, 0, 0)

        # ── Header
        self.header = HeaderBar()
        root_lay.addWidget(self.header)

        # ── Corpo: sidebar + stack (QSplitter para ser redimensionável)
        self.body_splitter = QSplitter(Qt.Horizontal)
        self.body_splitter.setStyleSheet(
            "QSplitter::handle{background:transparent;width:0px;}"
        )
        self.body_splitter.setChildrenCollapsible(False)
        self.body_splitter.setHandleWidth(0)

        self.sidebar = SidebarNav()
        self.sidebar.tab_changed.connect(self._on_nav)
        self.sidebar.tool_requested.connect(self.show_tools_tab)
        self.sidebar.pin_btn.clicked.connect(self.toggle_always_on_top)
        self.sidebar.fs_btn.clicked.connect(self.toggle_fullscreen)
        self.sidebar.compact_btn.clicked.connect(self.toggle_compact_mode)
        self.body_splitter.addWidget(self.sidebar)

        # Stack pages
        self.main_tabs = QTabWidget()
        self.main_tabs.setStyleSheet("QTabWidget::pane{border:none;background:transparent;} QTabBar{max-height:0;}")
        self.main_tabs.tabBar().hide()
        self.main_tabs.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.body_splitter.addWidget(self.main_tabs)

        # Sidebar não encolhe, conteúdo pega todo o resto
        self.body_splitter.setStretchFactor(0, 0)
        self.body_splitter.setStretchFactor(1, 1)

        root_lay.addWidget(self.body_splitter, 1)

        # ── Status bar customizada
        self.status_bar = AppStatusBar()
        root_lay.addWidget(self.status_bar)

        # ── Atalhos globais
        QShortcut(QKeySequence("F11"),    self, self.toggle_fullscreen)
        QShortcut(QKeySequence("Escape"), self, self._exit_fullscreen)
        QShortcut(QKeySequence("Return"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Space"),  self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+G"), self, self.generate_pair)
        QShortcut(QKeySequence("Ctrl+C"), self, self._shortcut_copy)
        QShortcut(QKeySequence("Return"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+G"), self, self._shortcut_generate)
        QShortcut(QKeySequence("Ctrl+C"), self, self._shortcut_copy)

        # Constrói as páginas
        self._build_pages()
        self.open_page_by_name("Gerador")
        QTimer.singleShot(1200, self._run_startup_tasks)
        self.update_stats()

    def _on_nav(self, idx):
        if idx < 0 or idx >= self.main_tabs.count():
            return
        self.main_tabs.setCurrentIndex(idx)
        self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else "")

    def _page_index_by_name(self, name):
        target = name.lower()
        for i, title in enumerate(self.tab_titles):
            if target in title.lower():
                return i
        for i in range(self.main_tabs.count()):
            if target in self.main_tabs.tabText(i).lower():
                return i
        return -1

    def open_page_by_name(self, name):
        idx = self._page_index_by_name(name)
        if idx >= 0:
            self.main_tabs.setCurrentIndex(idx)
            self.sidebar.set_current(idx)
            self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else name)

    def open_notes_page(self):
        self.open_page_by_name("Notas")

    def open_global_search(self):
        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        GlobalSearchDialog(manager, self).exec_()

    def _run_startup_tasks(self):
        # Nao roda backup pesado na abertura: perfis de navegador podem ter muitos
        # arquivos e isso deixa o Windows marcar o app como "nao respondendo".
        self.status_bar.showMessage("✅ Pronto", 1500)

    # ─── Tray ────────────────────────────────────────────────
    def _setup_tray(self):
        if not QSystemTrayIcon.isSystemTrayAvailable():
            return
        self.tray_icon = QSystemTrayIcon(self.app_icon, self)
        menu = QMenu()
        menu.addAction("Mostrar", self._show_normal)
        menu.addAction("Modo Compacto", self.toggle_compact_mode)
        menu.addSeparator()
        menu.addAction("Fixar no Topo", self.toggle_always_on_top)
        menu.addSeparator()
        menu.addAction("Sair", self.quit_application)
        self.tray_icon.setContextMenu(menu)
        self.tray_icon.activated.connect(lambda r: self._show_normal() if r == QSystemTrayIcon.DoubleClick else None)
        self.tray_icon.show()
        self.tray_icon.setToolTip("Telegram Collector Pro v11.0")

    def _show_normal(self):
        self.showNormal()
        self.activateWindow()
        self.raise_()

    def quit_application(self):
        self._force_quit = True
        QApplication.setQuitOnLastWindowClosed(True)
        self._save_state()
        if hasattr(self, "tray_icon"):
            self.tray_icon.hide()
        QApplication.quit()

    # ─── Controles de janela ─────────────────────────────────
    def toggle_always_on_top(self):
        self.is_always_on_top = not self.is_always_on_top
        if self.is_always_on_top:
            self.setWindowFlags(self.windowFlags() | Qt.WindowStaysOnTopHint)
            self.sidebar.pin_btn.setStyleSheet(self.sidebar.pin_btn.styleSheet().replace("#475569", "#f43f5e"))
            self.status_bar.showMessage("📌 Janela fixada no topo", 2500)
        else:
            self.setWindowFlags(self.windowFlags() & ~Qt.WindowStaysOnTopHint)
            self.status_bar.showMessage("📌 Janela desfixada", 2500)
        self.show()

    def toggle_fullscreen(self):
        if self.isFullScreen():
            self.showNormal()
            self.is_fullscreen = False
            self.sidebar.set_collapsed(False)
            self.sidebar.fs_btn.setToolTip("  Tela cheia  [F11]  ")
            self.status_bar.showMessage("⛶ Modo janela", 2000)
        else:
            self._pre_fs_geometry = self.geometry()
            self.showFullScreen()
            self.is_fullscreen = True
            self.sidebar.set_collapsed(True)
            self.sidebar.fs_btn.setToolTip("  Sair da tela cheia  [F11 / Esc]  ")
            self.status_bar.showMessage("⛶ Tela cheia — F11 ou Esc para sair", 3000)

    def _exit_fullscreen(self):
        if self.isFullScreen():
            self.toggle_fullscreen()

    def toggle_compact_mode(self):
        if not hasattr(self, "_compact_widget"):
            self._compact_widget = CompactWidget(self.db, self._address_gen, self)

        if self.is_compact_mode:
            self._compact_widget.hide()
            self.is_compact_mode = False
            QApplication.setQuitOnLastWindowClosed(True)
            self._show_normal()
            self.status_bar.showMessage("🖥️ Modo normal", 2000)
        else:
            QApplication.setQuitOnLastWindowClosed(False)
            self.is_compact_mode = True
            self._restore_compact_pos(self._compact_widget)
            self._compact_widget.show()
            self._compact_widget.raise_()
            self.showMinimized()
            self.status_bar.showMessage("📱 Painel compacto ativo  •  arraste pelo cabeçalho", 3000)

    # ─── Persistência ────────────────────────────────────────
    def _save_state(self):
        self.settings.setValue("geometry", self.saveGeometry())
        self.settings.setValue("alwaysOnTop", self.is_always_on_top)
        if hasattr(self, "_compact_widget") and self._compact_widget.isVisible():
            pos = self._compact_widget.pos()
            self.settings.setValue("compactX", pos.x())
            self.settings.setValue("compactY", pos.y())

    def _load_state(self):
        geo = self.settings.value("geometry")
        if geo:
            self.restoreGeometry(geo)
        if self.settings.value("alwaysOnTop", False, type=bool):
            self.toggle_always_on_top()

    def _restore_compact_pos(self, widget):
        """Restaura posição salva do painel compacto."""
        x = self.settings.value("compactX", type=int)
        y = self.settings.value("compactY", type=int)
        if x is not None and y is not None:
            screen = QApplication.primaryScreen().availableGeometry()
            # Garante que está dentro da tela
            x = max(0, min(x, screen.right() - widget.width()))
            y = max(0, min(y, screen.bottom() - widget.height()))
            widget.move(x, y)
        else:
            screen = QApplication.primaryScreen().availableGeometry()
            widget.move(screen.right() - widget.width() - 20, screen.top() + 60)

    # ─── Banco de dados ──────────────────────────────────────
    def _get_database(self):
        conta = self.config_manager.get_conta_ativa()
        if conta:
            return DatabaseManager(self.config_manager.get_caminho_banco(conta["id"]))
        return DatabaseManager()

    def refresh_database(self):
        self.db = self._get_database()
        if hasattr(self, "_compact_widget"):
            self._compact_widget.update_db(self.db)
        if hasattr(self, "data_pro_tab"):
            self.data_pro_tab.update_db(self.db)
        self.update_stats()

    def check_configuration(self):
        if not settings.is_configured:
            self.status_bar.showMessage(
                "⚙️ Telegram ainda não configurado. Use Config. quando for coletar.",
                5000,
            )

    # ═══════════════════════════════════════════════════════════
    #  CONSTRUÇÃO DAS PÁGINAS
    # ═══════════════════════════════════════════════════════════
    def _build_pages(self):
        self.main_tabs.addTab(self._build_inicio_page(), "Início")
        self.main_tabs.addTab(self._build_gerador_page(), "Gerador")
        self.main_tabs.addTab(self._build_navegador_page(), "Navegador")
        self.main_tabs.addTab(self._build_ai_page(), "IA Local")
        if CRUNCHYROLL_AVAILABLE:
            self.main_tabs.addTab(self._build_crunchyroll_page(), "Crunchyroll")
        self.main_tabs.addTab(self._build_notas_page(), "Notas")
        self.main_tabs.addTab(self._build_config_page(), "Config")
        self.main_tabs.addTab(self._build_ferramentas_page(), "Ferramentas")
        self.tab_titles.append(self.TAB_TITLES["ferramentas"])

    def _build_inicio_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.dashboard_page = AppDashboardWidget(
            db=self.db,
            browser_widget=getattr(self, "browser_widget", None),
            open_page=self.open_page_by_name,
            open_tool=self.show_tools_tab,
        )
        lay.addWidget(self.dashboard_page)
        return page

    # ── Página 1: Gerador de Pares ────────────────────────────
    def _build_gerador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")

        root_lay = QVBoxLayout(page)
        root_lay.setContentsMargins(10, 8, 10, 8)
        root_lay.setSpacing(0)

        splitter = QSplitter(Qt.Horizontal)
        splitter.setHandleWidth(6)
        splitter.setStyleSheet("""
            QSplitter::handle {
                background: transparent;
                width: 6px;
            }
            QSplitter::handle:hover {
                background: rgba(6,182,212,0.25);
                border-radius: 3px;
            }
            QSplitter::handle:pressed {
                background: rgba(6,182,212,0.45);
            }
        """)
        splitter.setChildrenCollapsible(False)

        # === PAINEL ESQUERDO (scroll) ===
        left_scroll = QScrollArea()
        left_scroll.setWidgetResizable(True)
        left_scroll.setFrameShape(QFrame.NoFrame)
        left_scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        left_scroll.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        left_scroll.setStyleSheet(
            "QScrollArea{background:transparent;border:none;}"
            "QScrollBar:vertical{background:#07080f;width:5px;border-radius:2px;}"
            "QScrollBar::handle:vertical{background:#1a2540;border-radius:2px;min-height:20px;}"
            "QScrollBar::handle:vertical:hover{background:#06b6d4;}"
            "QScrollBar::add-line:vertical,QScrollBar::sub-line:vertical{height:0;}"
        )

        left_widget = QWidget()
        left_widget.setStyleSheet("background:transparent;")
        left_lay = QVBoxLayout(left_widget)
        left_lay.setContentsMargins(0, 0, 6, 0)
        left_lay.setSpacing(6)

        sp_qss = ("QSpinBox{background:#0d1525;border:1px solid rgba(6,182,212,0.2);"
                  "border-radius:6px;color:#e2e8f0;padding:3px 6px;font-size:12px;min-width:52px;}"
                  "QSpinBox::up-button,QSpinBox::down-button{width:14px;border:none;background:transparent;}")
        cb_qss = ("QCheckBox{color:#94a3b8;font-size:12px;spacing:5px;}"
                  "QCheckBox::indicator{width:13px;height:13px;"
                  "border:1px solid rgba(6,182,212,0.3);border-radius:3px;background:#0d1525;}"
                  "QCheckBox::indicator:checked{background:#06b6d4;border-color:#06b6d4;}")
        sec_btn_qss = ("QPushButton{background:rgba(255,255,255,0.035);color:#64748b;"
                       "border:1px solid rgba(255,255,255,0.07);border-radius:6px;"
                       "font-size:11px;padding:5px 4px;}"
                       "QPushButton:hover{background:rgba(6,182,212,0.12);color:#94a3b8;"
                       "border-color:rgba(6,182,212,0.3);}")

        def sec_lbl(txt):
            l = QLabel(txt)
            l.setStyleSheet("color:#1e3a4a;font-size:10px;font-weight:700;letter-spacing:1px;"
                            "background:transparent;border:none;padding:2px 0 0 0;")
            return l

        def card(build_fn):
            f = QFrame()
            f.setStyleSheet("QFrame{background:#0d1525;border:1px solid rgba(6,182,212,0.09);border-radius:10px;}")
            f.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Minimum)
            lay = QVBoxLayout(f)
            lay.setContentsMargins(12, 10, 12, 10)
            lay.setSpacing(7)
            build_fn(lay)
            return f

        # CARD FILTROS
        def build_filters(lay):
            lay.addWidget(sec_lbl("FILTROS"))
            row = QHBoxLayout(); row.setSpacing(8)
            self.filtro_checkbox = QCheckBox("Idade")
            self.filtro_checkbox.setStyleSheet(cb_qss)
            self.filtro_checkbox.stateChanged.connect(self.toggle_filtro)
            self.idade_min_spin = QSpinBox()
            self.idade_min_spin.setRange(0,120); self.idade_min_spin.setValue(18)
            self.idade_min_spin.setEnabled(False); self.idade_min_spin.setStyleSheet(sp_qss)
            self.idade_max_spin = QSpinBox()
            self.idade_max_spin.setRange(0,120); self.idade_max_spin.setValue(65)
            self.idade_max_spin.setEnabled(False); self.idade_max_spin.setStyleSheet(sp_qss)
            s1 = QLabel("–"); s1.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_checkbox)
            row.addWidget(self.idade_min_spin)
            row.addWidget(s1)
            row.addWidget(self.idade_max_spin)
            row.addSpacing(12)
            self.filtro_score_checkbox = QCheckBox("Score")
            self.filtro_score_checkbox.setStyleSheet(cb_qss)
            self.filtro_score_checkbox.stateChanged.connect(self.toggle_filtro_score)
            self.score_min_spin = QSpinBox()
            self.score_min_spin.setRange(0,1000); self.score_min_spin.setValue(500)
            self.score_min_spin.setEnabled(False); self.score_min_spin.setStyleSheet(sp_qss)
            self.score_max_spin = QSpinBox()
            self.score_max_spin.setRange(0,1000); self.score_max_spin.setValue(1000)
            self.score_max_spin.setEnabled(False); self.score_max_spin.setStyleSheet(sp_qss)
            s2 = QLabel("–"); s2.setStyleSheet("color:#334155;")
            row.addWidget(self.filtro_score_checkbox)
            row.addWidget(self.score_min_spin)
            row.addWidget(s2)
            row.addWidget(self.score_max_spin)
            row.addStretch()
            lay.addLayout(row)
            disp = QHBoxLayout(); disp.setSpacing(10)
            lbl_e = QLabel("Exibir:"); lbl_e.setStyleSheet("color:#334155;font-size:11px;")
            disp.addWidget(lbl_e)
            for field, txt in [("nome","Nome"),("cpf","CPF"),("idade","Idade"),
                               ("data","Nasc."),("telefone","Tel."),("score","Score")]:
                cb = QCheckBox(txt); cb.setChecked(True); cb.setStyleSheet(cb_qss)
                cb.stateChanged.connect(lambda _, f=field: self.toggle_display(f))
                setattr(self, f"check_{field}", cb)
                disp.addWidget(cb)
            disp.addStretch()
            lay.addLayout(disp)
        left_lay.addWidget(card(build_filters))

        # CARD ACOES
        def build_acoes(lay):
            lay.addWidget(sec_lbl("AÇÕES"))
            mrow = QHBoxLayout(); mrow.setSpacing(8)
            self.generate_btn = QPushButton("🎲  GERAR PAR")
            self.generate_btn.setCursor(Qt.PointingHandCursor)
            self.generate_btn.setFixedHeight(40)
            self.generate_btn.setStyleSheet("""
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #059669,stop:1 #10b981);
                color:white;border:none;border-radius:8px;font-size:13px;font-weight:700;}
                QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #047857,stop:1 #059669);}
                QPushButton:disabled{background:#1a2540;color:#334155;}""")
            self.generate_btn.clicked.connect(self.generate_pair)
            cbtn = QPushButton("📋  COPIAR")
            cbtn.setCursor(Qt.PointingHandCursor)
            cbtn.setFixedHeight(40)
            cbtn.setStyleSheet("""
                QPushButton{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0891b2,stop:1 #06b6d4);
                color:white;border:none;border-radius:8px;font-size:13px;font-weight:700;}
                QPushButton:hover{background:qlineargradient(x1:0,y1:0,x2:1,y2:0,stop:0 #0e7490,stop:1 #0891b2);}""")
            cbtn.clicked.connect(self.copy_result)
            mrow.addWidget(self.generate_btn, 3)
            mrow.addWidget(cbtn, 2)
            lay.addLayout(mrow)
            grid = QGridLayout(); grid.setSpacing(5)
            for i, (txt, fn) in enumerate([
                ("📥 Coletar", self.start_collection), ("📊 Ver Dados", self.show_data),
                ("💾 Exportar", self.export_data), ("📋 Grupos", self.show_groups_dialog),
                ("⚙️ Config.", self.show_config_dialog), ("📱 Contas", self.show_contas_dialog),
            ]):
                b = QPushButton(txt); b.setFixedHeight(28); b.setCursor(Qt.PointingHandCursor)
                b.setStyleSheet(sec_btn_qss); b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.clicked.connect(fn)
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_acoes))

        # CARD RAPIDO
        def build_rapido(lay):
            lay.addWidget(sec_lbl("ACESSO RÁPIDO"))
            grid = QGridLayout(); grid.setSpacing(5)
            items = [("💳 Cartões",0,"#10b981"),("🏠 CEP",1,"#06b6d4"),
                     ("✅ CPF/CNPJ",4,"#8b5cf6"),("🎭 Fake",5,"#f59e0b"),
                     ("📧 Organizador",2,"#0ea5e9"),("⚡ Desempenho",6,"#fbbf24")]
            for i, (txt, ti, color) in enumerate(items):
                b = QPushButton(txt); b.setFixedHeight(27); b.setCursor(Qt.PointingHandCursor)
                b.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Fixed)
                b.setStyleSheet(f"QPushButton{{background:rgba(6,182,212,0.05);color:{color};"
                               f"border:1px solid {color}28;border-radius:6px;font-size:11px;font-weight:600;}}"
                               f"QPushButton:hover{{background:{color}18;border-color:{color}55;}}")
                b.clicked.connect(lambda _, i=ti: self.show_tools_tab(i))
                grid.addWidget(b, i // 3, i % 3)
            lay.addLayout(grid)
        left_lay.addWidget(card(build_rapido))

        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        self.progress_bar.setFixedHeight(3)
        self.progress_bar.setStyleSheet("QProgressBar{background:#0d1525;border:none;border-radius:1px;}"
                                        "QProgressBar::chunk{background:#06b6d4;border-radius:1px;}")
        self.progress_bar.setTextVisible(False)
        left_lay.addWidget(self.progress_bar)

        self.stats_label = QLabel("—")
        self.stats_label.setAlignment(Qt.AlignCenter)
        self.stats_label.setStyleSheet("color:#1a3040;font-size:10px;background:transparent;border:none;")
        self.stats_label.setWordWrap(True)
        left_lay.addWidget(self.stats_label)
        left_lay.addStretch(1)

        left_scroll.setWidget(left_widget)
        splitter.addWidget(left_scroll)

        # === PAINEL DIREITO — RESULTADO ===
        right_widget = QWidget()
        right_widget.setStyleSheet("background:transparent;")
        right_lay = QVBoxLayout(right_widget)
        right_lay.setContentsMargins(6, 0, 0, 0)
        right_lay.setSpacing(6)
        right_lay.addWidget(sec_lbl("RESULTADO"))

        rc = QFrame()
        rc.setStyleSheet("QFrame{background:#0d1525;border:1px solid rgba(6,182,212,0.09);border-radius:10px;}")
        rc.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        rc_lay = QVBoxLayout(rc)
        rc_lay.setContentsMargins(12, 10, 12, 10)
        rc_lay.setSpacing(7)

        field_qss = ("QLabel{color:#22d3ee;font-family:'Consolas','Cascadia Code',monospace;"
                     "font-size:13px;font-weight:500;background:#07080f;"
                     "border:1px solid rgba(6,182,212,0.09);border-radius:7px;"
                     "padding:8px 12px;}")
        cp_qss = ("QPushButton{background:rgba(6,182,212,0.07);border:1px solid rgba(6,182,212,0.15);"
                  "border-radius:6px;font-size:12px;color:#06b6d4;"
                  "min-width:28px;max-width:28px;min-height:28px;max-height:28px;}"
                  "QPushButton:hover{background:rgba(6,182,212,0.22);}")

        for icon, attr, label_txt in [
            ("👤","nome","Nome"), ("🆔","cpf","CPF"), ("🎂","idade","Idade"),
            ("📅","nasc","Nascimento"), ("📞","telefone","Telefone"), ("⭐","score","Score"),
        ]:
            row = QHBoxLayout(); row.setSpacing(8)
            lbl = QLabel(f"{icon}   {label_txt}: —")
            lbl.setStyleSheet(field_qss)
            lbl.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            cp = QPushButton("⎘")
            cp.setStyleSheet(cp_qss); cp.setCursor(Qt.PointingHandCursor)
            cp.setToolTip(f"Copiar {label_txt}")
            cp.clicked.connect(lambda _, a=attr: self.copy_field(a))
            row.addWidget(lbl, 1); row.addWidget(cp)
            rc_lay.addLayout(row)
            setattr(self, f"{attr}_label", lbl)
        rc_lay.addStretch(1)

        right_lay.addWidget(rc, 1)
        splitter.addWidget(right_widget)

        splitter.setSizes([420, 580])
        splitter.setStretchFactor(0, 42)
        splitter.setStretchFactor(1, 58)
        root_lay.addWidget(splitter, 1)

        self.nome_label.setText("👤   Nome: —")
        self.cpf_label.setText("🆔   CPF: —")
        self.idade_label.setText("🎂   Idade: —")
        self.nasc_label.setText("📅   Nascimento: —")
        self.telefone_label.setText("📞   Telefone: —")
        self.score_label.setText("⭐   Score: —")

        return page

    # ── Página 2: Ferramentas ────────────────────────────────
    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 0;
            }
            QTabBar {
                background: #07080f;
                border-bottom: 1px solid rgba(6,182,212,0.08);
            }
            QTabBar::tab {
                background: transparent;
                color: #475569;
                padding: 7px 11px;
                margin-right: 1px;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                background: rgba(6,182,212,0.06);
                border-bottom: 2px solid #06b6d4;
                font-weight: 700;
            }
            QTabBar::tab:hover:!selected {
                color: #94a3b8;
                background: rgba(255,255,255,0.03);
            }
            QTabBar::scroller { width: 22px; }
            QTabBar QToolButton {
                background: #0d1525;
                border: 1px solid rgba(6,182,212,0.2);
                color: #06b6d4;
                border-radius: 4px;
                font-size: 12px;
            }
            QTabBar QToolButton:hover { background: rgba(6,182,212,0.18); }
        """)

        tools_helper = ToolsDialog(self)
        self.tools_tabs.addTab(tools_helper.create_card_generator_tab(), "💳 Cartões")
        self.tools_tabs.addTab(tools_helper.create_cep_generator_tab(), "🏠 CEP")
        self.tools_tabs.addTab(tools_helper.create_account_formatter_tab(), "📧 Organizador")
        self.tools_tabs.addTab(DataOrganizer(), "🗂️ Formatar")
        self.tools_tabs.addTab(ValidadorWidget(), "✅ CPF/CNPJ")
        self.tools_tabs.addTab(GeradorFakeWidget(), "🎭 Fake")
        self.tools_tabs.addTab(PerformanceWidget(), "⚡ Desempenho")
        self.data_pro_tab = DataProWidget(self.db)
        self.tools_tabs.addTab(self.data_pro_tab, "🧹 Dados Pro")
        self.tools_tabs.addTab(TextCorrectorWidget(), "✍️ Português")

        lay.addWidget(self.tools_tabs)
        return page

    # ── Página 3: Navegador ──────────────────────────────────
    def _build_navegador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)

        self.browser_tabs = QTabWidget()
        self.browser_tabs.setStyleSheet(TAB_TOP_QSS)
        self.browser_widget = BrowserWidget()
        if hasattr(self, "dashboard_page"):
            self.dashboard_page.browser_widget = self.browser_widget
            self.dashboard_page.browser_manager = self.browser_widget.browser_manager
        self.browser_tabs.addTab(self.browser_widget, "🌐 Navegador")
        if PROFILE_DEFAULTS_AVAILABLE:
            config_dir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "browser_config")
            self.profile_defaults_tab = ProfileDefaultsWidget(config_dir)
            self.browser_tabs.addTab(self.profile_defaults_tab, "⚙️ Configurações")
        lay.addWidget(self.browser_tabs)
        return page

    def _build_ai_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.ai_assistant_tab = AIAssistantWidget()
        lay.addWidget(self.ai_assistant_tab)
        return page

    # ── Página 4: Crunchyroll ────────────────────────────────
    def _build_crunchyroll_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(10, 8, 10, 8)
        lay.setSpacing(8)

        quick = QFrame()
        quick.setStyleSheet(
            "QFrame{background:#0b1626;border:1px solid rgba(34,211,238,0.12);border-radius:8px;}"
        )
        quick_lay = QHBoxLayout(quick)
        quick_lay.setContentsMargins(10, 8, 10, 8)
        quick_lay.setSpacing(8)
        title = QLabel("Crunchyroll")
        title.setStyleSheet("color:#e2e8f0;font-weight:900;font-size:14px;background:transparent;border:none;")
        quick_lay.addWidget(title)
        quick_lay.addStretch()

        back_btn = QPushButton("← Voltar")
        back_btn.setFixedHeight(32)
        back_btn.setToolTip("Voltar para o início do Crunchyroll")
        back_btn.clicked.connect(self._crunchyroll_back)
        quick_lay.addWidget(back_btn)

        for text, tab_name in [
            ("Contas", "Contas"),
            ("Cartões", "Cartões"),
            ("Resultados", "Resultados"),
            ("Verificador", "Verificador"),
        ]:
            btn = QPushButton(text)
            btn.setFixedHeight(32)
            btn.clicked.connect(lambda _, name=tab_name: self._open_crunchyroll_bot_tab(name))
            quick_lay.addWidget(btn)

        if CRUNCHYROLL_LOGIN_AVAILABLE:
            login_btn = QPushButton("Login/Auth")
            login_btn.setFixedHeight(32)
            login_btn.clicked.connect(self._open_crunchyroll_login_tab)
            quick_lay.addWidget(login_btn)

        refresh_btn = QPushButton("Atualizar resultados")
        refresh_btn.setFixedHeight(32)
        refresh_btn.clicked.connect(self._refresh_crunchyroll_results)
        quick_lay.addWidget(refresh_btn)
        lay.addWidget(quick)

        self.crunchy_tabs = QTabWidget()
        self.crunchy_tabs.setStyleSheet(TAB_TOP_QSS)
        self.crunchyroll_tab = CrunchyrollWidget()
        self.crunchy_tabs.addTab(self.crunchyroll_tab, "🍦 Bot Principal")
        if CRUNCHYROLL_LOGIN_AVAILABLE:
            self.crunchyroll_login_tab = CrunchyrollLoginWidget()
            self.crunchy_tabs.addTab(self.crunchyroll_login_tab, "🔐 Login/Auth")
        lay.addWidget(self.crunchy_tabs)
        return page

    def _open_crunchyroll_bot_tab(self, tab_name):
        if hasattr(self, "crunchy_tabs"):
            self.crunchy_tabs.setCurrentIndex(0)
        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if not inner_tabs:
            return
        target = tab_name.lower()
        for i in range(inner_tabs.count()):
            if target in inner_tabs.tabText(i).lower():
                inner_tabs.setCurrentIndex(i)
                break

    def _crunchyroll_back(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.currentIndex() != 0:
            self.crunchy_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Bot Principal", 2000)
            return

        inner_tabs = getattr(getattr(self, "crunchyroll_tab", None), "tabs", None)
        if inner_tabs and inner_tabs.currentIndex() != 0:
            inner_tabs.setCurrentIndex(0)
            self.status_bar.showMessage("✅ Voltou para o Controle do Crunchyroll", 2000)
            return

        self.status_bar.showMessage("ℹ️ Você já está no início do Crunchyroll", 2000)

    def _open_crunchyroll_login_tab(self):
        if hasattr(self, "crunchy_tabs") and self.crunchy_tabs.count() > 1:
            self.crunchy_tabs.setCurrentIndex(1)

    def _refresh_crunchyroll_results(self):
        refreshed = False
        for widget_name in ("crunchyroll_tab", "crunchyroll_login_tab"):
            widget = getattr(self, widget_name, None)
            if widget and hasattr(widget, "load_results"):
                widget.load_results()
                refreshed = True
        if refreshed:
            self.status_bar.showMessage("✅ Resultados do Crunchyroll atualizados", 2500)

    # ── Página 5: Notas ──────────────────────────────────────
    def _build_notas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        self.notepad_tab = NotepadWidget()
        lay.addWidget(self.notepad_tab)
        return page

    def _build_config_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        self.general_settings_tab = GeneralSettingsWidget(manager)
        lay.addWidget(self.general_settings_tab)
        return page

    # ═══════════════════════════════════════════════════════════
    #  MÉTODOS DE NEGÓCIO (idênticos ao original)
    # ═══════════════════════════════════════════════════════════
    def _shortcut_generate(self):
        """Atalho Ctrl+G ou Enter: gera par apenas se na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            self.generate_pair()

    def _shortcut_copy(self):
        """Atalho Ctrl+C: copia resultado se na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador") and self.current_pair:
            self.copy_result()

    def statusBar(self):
        return self.status_bar

    def _shortcut_generate(self):
        """Enter/Space gera par apenas quando na aba Gerador."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            self.generate_pair()

    def _shortcut_copy(self):
        """Ctrl+C copia resultado apenas quando na aba Gerador e sem seleção."""
        if self.main_tabs.currentIndex() == self._page_index_by_name("Gerador"):
            focused = QApplication.focusWidget()
            # Só age se não houver widget de texto com foco
            if not isinstance(focused, (QLineEdit, QTextEdit, QPlainTextEdit)):
                self.copy_result()

    def toggle_filtro(self, state):
        enabled = state == Qt.Checked
        self.idade_min_spin.setEnabled(enabled)
        self.idade_max_spin.setEnabled(enabled)

    def toggle_filtro_score(self, state):
        enabled = state == Qt.Checked
        self.score_min_spin.setEnabled(enabled)
        self.score_max_spin.setEnabled(enabled)

    def toggle_display(self, field):
        mapping = {
            "nome": "mostrar_nome", "cpf": "mostrar_cpf",
            "idade": "mostrar_idade", "data": "mostrar_data",
            "telefone": "mostrar_telefone", "score": "mostrar_score",
        }
        if field in mapping:
            cb = getattr(self, f"check_{field}", None)
            if cb:
                setattr(self, mapping[field], cb.isChecked())
        self.update_field_visibility()
        if self.current_pair:
            self.display_pair(self.current_pair)

    def update_field_visibility(self):
        pairs = [
            ("nome_label", self.mostrar_nome),
            ("cpf_label", self.mostrar_cpf),
            ("idade_label", self.mostrar_idade),
            ("nasc_label", self.mostrar_data),
            ("telefone_label", self.mostrar_telefone),
            ("score_label", self.mostrar_score),
        ]
        for attr, vis in pairs:
            w = getattr(self, attr, None)
            if w:
                w.setVisible(vis)

    def update_stats(self):
        stats = self.db.get_stats()
        txt = (f"📊 {stats['total']}  ✅ {stats['complete']}  "
               f"📅 {stats.get('with_birth',0)}  📞 {stats['with_phone']}  ⭐ {stats['with_score']}")
        self.stats_label.setText(txt)
        self.header.set_stats(txt)

    def generate_pair(self):
        filters = {}
        if self.filtro_checkbox.isChecked():
            filters["idade_min"] = self.idade_min_spin.value()
            filters["idade_max"] = self.idade_max_spin.value()
        if self.filtro_score_checkbox.isChecked():
            filters["score_min"] = self.score_min_spin.value()
            filters["score_max"] = self.score_max_spin.value()
        pair = self.db.get_random_pair(filters)
        if pair:
            self.current_pair = pair
            self.display_pair(pair)
            self._flash_result_fields()
            self.status_bar.showMessage("✅ Par gerado com sucesso!", 1500)
        else:
            for attr in ["nome_label","cpf_label","idade_label","nasc_label","telefone_label","score_label"]:
                lbl = getattr(self, attr, None)
                if lbl: lbl.setText(lbl.text().split(":")[0] + ":  —")
            self.current_pair = None
            self.status_bar.showMessage("❌ Nenhum registro encontrado com os filtros aplicados", 3000)

    def _flash_result_fields(self):
        """Flash verde rápido nos campos de resultado para feedback visual."""
        flash_qss = ("QLabel{color:#10b981;font-family:'Consolas','Cascadia Code',monospace;"
                     "font-size:13px;font-weight:500;background:#071a10;"
                     "border:1px solid rgba(16,185,129,0.4);border-radius:7px;padding:8px 12px;}")
        normal_qss = ("QLabel{color:#22d3ee;font-family:'Consolas','Cascadia Code',monospace;"
                      "font-size:13px;font-weight:500;background:#07080f;"
                      "border:1px solid rgba(6,182,212,0.09);border-radius:7px;padding:8px 12px;}")
        labels = [getattr(self, a, None) for a in
                  ["nome_label","cpf_label","idade_label","nasc_label","telefone_label","score_label"]]
        labels = [l for l in labels if l]
        for l in labels:
            l.setStyleSheet(flash_qss)
        QTimer.singleShot(350, lambda: [l.setStyleSheet(normal_qss) for l in labels if l])

    def display_pair(self, pair):
        def _set(attr, prefix, key):
            lbl = getattr(self, f"{attr}_label", None)
            if lbl:
                val = pair.get(key, "")
                lbl.setText(f"{prefix}  {val}" if val else f"{prefix}  —")
        _set("nome",  "👤  Nome:", "nome")
        _set("cpf",   "🆔  CPF:", "cpf")
        idade_lbl = getattr(self, "idade_label", None)
        if idade_lbl:
            v = pair.get("idade")
            idade_lbl.setText(f"🎂  Idade:  {v} anos" if v else "🎂  Idade:  —")
        _set("nasc",  "📅  Nasc.:", "nascimento")
        _set("telefone", "📞  Tel.:", "telefone")
        _set("score", "⭐  Score:", "score")
        self.update_field_visibility()

    def copy_field(self, field):
        if not self.current_pair:
            self.status_bar.showMessage("⚠️ Nenhum dado para copiar", 2000)
            return
        key_map = {"nome":"nome","cpf":"cpf","idade":"idade","nasc":"nascimento",
                   "telefone":"telefone","score":"score"}
        key = key_map.get(field, field)
        val = self.current_pair.get(key)
        if val:
            _set_clipboard_text_safe(str(val))
            self.status_bar.showMessage(f"✅ {key.capitalize()} copiado!", 1500)
            # Flash verde no label copiado
            lbl_attr = f"{field}_label"
            lbl = getattr(self, lbl_attr, None)
            if lbl:
                orig = lbl.styleSheet()
                flash = orig.replace("#22d3ee", "#10b981").replace("#07080f", "#071a10").replace(
                    "rgba(6,182,212,0.09)", "rgba(16,185,129,0.35)")
                lbl.setStyleSheet(flash)
                QTimer.singleShot(400, lambda: lbl.setStyleSheet(orig))

    def copy_result(self):
        if not self.current_pair:
            self.status_bar.showMessage("⚠️ Nenhum dado para copiar", 2000)
            return
        p = self.current_pair
        lines = []
        if self.mostrar_nome and p.get("nome"): lines.append(f"👤 Nome: {p['nome']}")
        if self.mostrar_cpf and p.get("cpf"):   lines.append(f"🆔 CPF: {p['cpf']}")
        if self.mostrar_idade and p.get("idade"): lines.append(f"🎂 Idade: {p['idade']} anos")
        if self.mostrar_data and p.get("nascimento"): lines.append(f"📅 Nascimento: {p['nascimento']}")
        if self.mostrar_telefone and p.get("telefone"): lines.append(f"📞 Telefone: {p['telefone']}")
        if self.mostrar_score and p.get("score"): lines.append(f"⭐ Score: {p['score']}")
        if lines:
            _set_clipboard_text_safe("\n".join(lines))
            self.status_bar.showMessage("✅ Todos os dados copiados!", 2000)

    def show_tools(self):
        idx = self._page_index_by_name("Ferramentas")
        if idx < 0:
            return
        self.main_tabs.setCurrentIndex(idx)
        self.sidebar.set_current(idx)
        self.header.set_title(self.tab_titles[idx] if idx < len(self.tab_titles) else "🛠️  Ferramentas")

    def show_tools_tab(self, tab_index):
        self.show_tools()
        if 0 <= tab_index < self.tools_tabs.count():
            self.tools_tabs.setCurrentIndex(tab_index)
        elif tab_index == 6:
            self.open_page_by_name("Config")

    def show_groups_dialog(self):
        GroupManagerDialog(self).exec_()

    def show_contas_dialog(self):
        GerenciadorContas(self).exec_()
        self.config_manager.load_config()
        self.refresh_database()

    def show_config_dialog(self):
        if ConfigDialog(self).exec_() == QDialog.Accepted:
            self.update_stats()

    def start_collection(self):
        config_manager = ConfigManager()
        conta_ativa = config_manager.get_conta_ativa()
        if not settings.is_configured and not conta_ativa:
            QMessageBox.warning(self, "Configuração", "Configure as credenciais primeiro!")
            self.show_config_dialog()
            return
        groups_file = BASE_DIR / "grupos.json"
        groups = [settings.default_group]
        if groups_file.exists():
            try:
                with open(groups_file, "r") as f:
                    groups = json.load(f)
            except (json.JSONDecodeError, IOError, PermissionError) as e:
                print(f"Aviso: {e}")
        if len(groups) > 1:
            reply = QMessageBox.question(self, "Coletar Dados",
                f"Você tem {len(groups)} grupos.\nGrupos: {', '.join(groups)}\n\nColetar de TODOS?",
                QMessageBox.Yes | QMessageBox.No | QMessageBox.Cancel)
            if reply == QMessageBox.Cancel: return
            if reply == QMessageBox.No: groups = [groups[0]]
        else:
            if QMessageBox.question(self, "Coletar Dados",
                "Receberá um código SMS.\nContinuar?",
                QMessageBox.Yes | QMessageBox.No) == QMessageBox.No:
                return
        # Padrao automatico: exige data de nascimento e ignora 60+ quando a
        # idade puder ser detectada. Score nao e obrigatorio.
        exigir_data = True
        filtrar_idosos = True
        idade_maxima = 59
        self.status_bar.showMessage(
            "Coleta automatica: exige data de nascimento, nao exige score e ignora 60+.",
            6000
        )
        self.progress_bar.setVisible(True); self.progress_bar.setRange(0,0)
        self.generate_btn.setEnabled(False)
        conta_id = conta_ativa["id"] if conta_ativa else None
        self.collector_thread = CollectorThread(
            groups=groups, filtrar_idosos=filtrar_idosos,
            idade_maxima=idade_maxima, exigir_data_nascimento=exigir_data,
            conta_id=conta_id)
        self.collector_thread.progress.connect(self.show_progress)
        self.collector_thread.error.connect(self.show_error)
        self.collector_thread.finished.connect(self.collection_finished)
        self.collector_thread.code_requested.connect(self.show_code_dialog)
        self.collector_thread.password_requested.connect(self.show_password_dialog)
        self.collector_thread.start()

    def show_code_dialog(self, phone):
        dlg = CodeInputDialog(phone, self)
        if dlg.exec_() == QDialog.Accepted and dlg.code:
            self.collector_thread.set_verification_code(dlg.code)
        else:
            self.show_error("Autenticação cancelada.")

    def show_password_dialog(self):
        dlg = PasswordInputDialog(self)
        if dlg.exec_() == QDialog.Accepted and dlg.password:
            self.collector_thread.set_password(dlg.password)
        else:
            self.show_error("Autenticação 2FA cancelada.")

    def show_progress(self, msg):
        self.status_bar.showMessage(msg)

    def show_error(self, err):
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        QMessageBox.critical(self, "Erro", f"Erro na coleta:\n{err}")

    def collection_finished(self, collected):
        self.progress_bar.setVisible(False)
        self.generate_btn.setEnabled(True)
        self.refresh_database()
        QMessageBox.information(self, "Sucesso", f"Coleta concluída!\n\n{collected} novos registros.")

    def show_data(self):
        DataViewDialog(self.db, self).exec_()

    def export_data(self):
        fp, _ = QFileDialog.getSaveFileName(self, "Salvar CSV", "dados_completo.csv", "CSV (*.csv)")
        if fp:
            if self.db.export_csv(fp, "completo"):
                QMessageBox.information(self, "Sucesso", f"Exportado:\n{fp}")
            else:
                QMessageBox.critical(self, "Erro", "Erro ao exportar")

    # ─── Eventos da janela ───────────────────────────────────
    def closeEvent(self, event):
        self._save_state()
        if (
            not getattr(self, "_force_quit", False)
            and hasattr(self, "_compact_widget")
            and self._compact_widget.isVisible()
        ):
            self.hide()
            event.ignore()
            return
        try:
            close_to_tray = bool(load_app_settings().get("close_to_tray", False))
        except Exception:
            close_to_tray = False
        if close_to_tray and hasattr(self, "tray_icon") and self.tray_icon.isVisible():
            self.hide()
            self.tray_icon.showMessage(
                "Telegram Collector Pro",
                "Minimizado para a bandeja. Use Sair no menu da bandeja para encerrar.",
                QSystemTrayIcon.Information,
                2000,
            )
            event.ignore()
            return
        if hasattr(self, "_compact_widget"):
            self._compact_widget.hide()
        if hasattr(self, "tray_icon"):
            self.tray_icon.hide()
        event.accept()
        self._force_quit = True
        QTimer.singleShot(0, QApplication.quit)

    def keyPressEvent(self, event):
        if event.key() == Qt.Key_F11:
            self.toggle_fullscreen()
        else:
            super().keyPressEvent(event)


def main():
    install_crash_logger()
    app = QApplication(sys.argv)
    app.setQuitOnLastWindowClosed(False)
    app.setStyle('Fusion')
    
    # Aplicar paleta escura
    palette = QPalette()
    palette.setColor(QPalette.Window, QColor(10, 14, 26))
    palette.setColor(QPalette.WindowText, QColor(241, 245, 249))
    palette.setColor(QPalette.Base, QColor(17, 24, 39))
    palette.setColor(QPalette.AlternateBase, QColor(15, 23, 42))
    palette.setColor(QPalette.ToolTipBase, QColor(30, 41, 59))
    palette.setColor(QPalette.ToolTipText, QColor(241, 245, 249))
    palette.setColor(QPalette.Text, QColor(241, 245, 249))
    palette.setColor(QPalette.Button, QColor(8, 145, 178))
    palette.setColor(QPalette.ButtonText, QColor(241, 245, 249))
    palette.setColor(QPalette.BrightText, QColor(34, 211, 238))
    palette.setColor(QPalette.Highlight, QColor(6, 182, 212))
    palette.setColor(QPalette.HighlightedText, QColor(10, 14, 26))
    app.setPalette(palette)
    
    window = SimpleApp()
    window.show()
    sys.exit(app.exec_())


if __name__ == '__main__':
    main()

