#!/usr/bin/env python3
"""Builders de paginas da janela principal.

Este mixin mantem a construcao visual fora do main_app.py sem mudar o fluxo do SimpleApp.
"""

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QTabWidget, QVBoxLayout, QWidget

from importlib.util import find_spec

from app.ui.crunchyroll_page import CRUNCHYROLL_AVAILABLE, CrunchyrollPageMixin
from app.ui.shell_widgets import TAB_TOP_QSS
from settings import BASE_DIR

PROFILE_DEFAULTS_AVAILABLE = find_spec("profile_defaults_widget") is not None


class MainPagesMixin(CrunchyrollPageMixin):
    def _build_pages(self):
        self.main_tabs.addTab(self._build_inicio_page(), "Início")
        self.main_tabs.addTab(self._build_gerador_page(), "Gerador")
        self.main_tabs.addTab(self._build_navegador_page(), "Navegador")
        self.main_tabs.addTab(self._build_ai_page(), "IA Local")
        if CRUNCHYROLL_AVAILABLE:
            self.main_tabs.addTab(self._build_crunchyroll_page(), "Crunchyroll")
        self.main_tabs.addTab(self._build_notas_page(), "Notas")
        self.main_tabs.addTab(self._build_config_page(), "Config")
        self.main_tabs.addTab(self._build_ferramentas_page(), "Ferramentas")
        self.tab_titles.append(self.TAB_TITLES["ferramentas"])

    def _build_inicio_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import AppDashboardWidget

        self.dashboard_page = AppDashboardWidget(
            db=self.db,
            browser_widget=getattr(self, "browser_widget", None),
            open_page=self.open_page_by_name,
            open_tool=self.show_tools_tab,
        )
        lay.addWidget(self.dashboard_page)
        return page

    def _build_gerador_page(self):
        from app.ui.generator_page import build_generator_page

        return build_generator_page(self)

    def _build_ferramentas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        lay.setSpacing(0)

        self.tools_tabs = QTabWidget()
        self.tools_tabs.setUsesScrollButtons(True)
        self.tools_tabs.setElideMode(Qt.ElideNone)
        self.tools_tabs.setStyleSheet("""
            QTabWidget::pane {
                border: none;
                background: transparent;
                margin-top: 0;
            }
            QTabBar {
                background: #07080f;
                border-bottom: 1px solid rgba(6,182,212,0.08);
            }
            QTabBar::tab {
                background: transparent;
                color: #475569;
                padding: 7px 11px;
                margin-right: 1px;
                border: none;
                border-bottom: 2px solid transparent;
                border-radius: 0;
                font-size: 11px;
                font-weight: 500;
                min-width: 60px;
            }
            QTabBar::tab:selected {
                color: #06b6d4;
                background: rgba(6,182,212,0.06);
                border-bottom: 2px solid #06b6d4;
                font-weight: 700;
            }
            QTabBar::tab:hover:!selected {
                color: #94a3b8;
                background: rgba(255,255,255,0.03);
            }
            QTabBar::scroller { width: 22px; }
            QTabBar QToolButton {
                background: #0d1525;
                border: 1px solid rgba(6,182,212,0.2);
                color: #06b6d4;
                border-radius: 4px;
                font-size: 12px;
            }
            QTabBar QToolButton:hover { background: rgba(6,182,212,0.18); }
        """)

        from app.features.tools.dialog import ToolsDialog
        from data_organizer import DataOrganizer
        from data_pro_widget import DataProWidget
        from extra_tools import GeradorFakeWidget, ValidadorWidget
        from performance_widget import PerformanceWidget
        from text_corrector_widget import TextCorrectorWidget

        tools_helper = ToolsDialog(self)
        self.tools_tabs.addTab(tools_helper.create_card_generator_tab(), "💳 Cartões")
        self.tools_tabs.addTab(tools_helper.create_cep_generator_tab(), "🏠 CEP")
        self.tools_tabs.addTab(tools_helper.create_account_formatter_tab(), "📧 Organizador")
        self.tools_tabs.addTab(DataOrganizer(), "🗂️ Formatar")
        self.tools_tabs.addTab(ValidadorWidget(), "✅ CPF/CNPJ")
        self.tools_tabs.addTab(GeradorFakeWidget(), "🎭 Fake")
        self.tools_tabs.addTab(PerformanceWidget(), "⚡ Desempenho")
        self.data_pro_tab = DataProWidget(self.db)
        self.tools_tabs.addTab(self.data_pro_tab, "🧹 Dados Pro")
        self.tools_tabs.addTab(TextCorrectorWidget(), "✍️ Português")

        lay.addWidget(self.tools_tabs)
        return page

    def _build_navegador_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)

        self.browser_tabs = QTabWidget()
        self.browser_tabs.setStyleSheet(TAB_TOP_QSS)
        from browser_widget import BrowserWidget

        self.browser_widget = BrowserWidget()
        if hasattr(self, "dashboard_page"):
            self.dashboard_page.browser_widget = self.browser_widget
            self.dashboard_page.browser_manager = self.browser_widget.browser_manager
        self.browser_tabs.addTab(self.browser_widget, "🌐 Navegador")
        if PROFILE_DEFAULTS_AVAILABLE:
            from profile_defaults_widget import ProfileDefaultsWidget

            config_dir = str(BASE_DIR / "browser_config")
            self.profile_defaults_tab = ProfileDefaultsWidget(config_dir)
            self.browser_tabs.addTab(self.profile_defaults_tab, "⚙️ Configurações")
        lay.addWidget(self.browser_tabs)
        return page

    def _build_ai_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from ai_assistant_widget import AIAssistantWidget

        self.ai_assistant_tab = AIAssistantWidget()
        lay.addWidget(self.ai_assistant_tab)
        return page






    def _build_notas_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from notepad_widget import NotepadWidget

        self.notepad_tab = NotepadWidget()
        lay.addWidget(self.notepad_tab)
        return page

    def _build_config_page(self):
        page = QWidget()
        page.setStyleSheet("background: #07080f;")
        lay = QVBoxLayout(page)
        lay.setContentsMargins(0, 0, 0, 0)
        from app_hub import GeneralSettingsWidget

        manager = getattr(getattr(self, "browser_widget", None), "browser_manager", None)
        self.general_settings_tab = GeneralSettingsWidget(manager)
        lay.addWidget(self.general_settings_tab)
        return page
