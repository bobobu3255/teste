﻿#!/usr/bin/env python3
"""
Browser Manager - Módulo de Orquestração do Navegador
Telegram Collector Pro v9.0 - Navegador Seguro

Este módulo orquestra a criação e gerenciamento das instâncias do navegador
com configurações anti-fingerprint.

Versão compatível com Python 3.13+ (usa Selenium puro)
"""

import os
import json
import shutil
import time
import subprocess
import sys
import copy
import urllib.parse
import zipfile
import hashlib
import socket
from pathlib import Path
from typing import Dict, Optional, List
from datetime import datetime

BASE_DIR = Path(__file__).resolve().parent

# Tentar importar undetected-chromedriver (preferência) ou selenium (fallback)
UNDETECTED_AVAILABLE = False
SELENIUM_AVAILABLE = False
SELENIUM_ERROR = ""

# Primeiro tentar undetected-chromedriver (melhor anti-detecção)
try:
    import undetected_chromedriver as uc
    UNDETECTED_AVAILABLE = True
except ImportError:
    pass
except Exception as e:
    print(f"Aviso: undetected-chromedriver disponível mas com erro: {e}")

# Fallback para selenium padrão
try:
    from selenium import webdriver
    from selenium.webdriver.chrome.service import Service
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.common.exceptions import (
        NoSuchElementException, 
        ElementNotInteractableException, 
        StaleElementReferenceException,
        WebDriverException,
        InvalidSessionIdException
    )
    SELENIUM_AVAILABLE = True
except ImportError as e:
    SELENIUM_ERROR = f"selenium não encontrado: {e}"
except Exception as e:
    SELENIUM_ERROR = f"Erro ao importar selenium: {e}"

from fingerprint_generator import FingerprintGenerator
from proxy_manager import ProxyManager, ProxyConfig

# Importar gerenciador de configurações padrão
try:
    from profile_defaults_manager import ProfileDefaultsManager
    DEFAULTS_MANAGER_AVAILABLE = True
except ImportError:
    DEFAULTS_MANAGER_AVAILABLE = False


BUILTIN_DEFAULT_FAVORITES = [
    {
        "id": "builtin_anime",
        "name": "anime",
        "url": (
            "https://sso.crunchyroll.com/pt-br/register?return_url=%2Fauthorize%3Fclient_id%3Dkmj7imhjt_q90lcbzzsj%26redirect_uri%3D"
            "https%253A%252F%252Fcrunchyroll.com%252Fpremium%252Fredirects%26response_type%3Dcookie%26state%3Dis_skip_freetrial"
            "%253Dtrue%2526ref%253Dnewweb_organic_header%2526return_url%253Dhttps%25253A%25252F%25252Fwww.crunchyroll.com"
            "%25252Fpt-br%25252Fvideos%25252Fpopular%2526search%253D%2525253Freferrer%2525253Dnewweb_organic_header"
            "%25252526return_url%2525253Dhttps%252525253A%252525252F%252525252Fwww.crunchyroll.com%252525252Fpt-br"
            "%252525252Fvideos%252525252Fpopular%2526selected_sku%253Dcr_fan_pack.1_month"
        ),
        "folder": "Fixados",
        "icon": "anime",
    },
    {
        "id": "builtin_anime_history",
        "name": "anime hist.",
        "url": "https://www.crunchyroll.com/payments/history",
        "folder": "Fixados",
        "icon": "history",
    },
    {
        "id": "builtin_hbo",
        "name": "hbo",
        "url": "https://auth.hbomax.com/create-account?flow=purchase",
        "folder": "Fixados",
        "icon": "hbo",
    },
    {
        "id": "builtin_outlook",
        "name": "outlook",
        "url": (
            "https://login.microsoftonline.com/common/oauth2/v2.0/authorize?client_id=9199bf20-a13f-4107-85dc-02114787ef48&"
            "scope=https%3A%2F%2Foutlook.office.com%2F.default%20openid%20profile%20offline_access&redirect_uri=https%3A%2F%2F"
            "outlook.live.com%2Fmail%2F&client-request-id=2d48915a-88a1-fcac-abdf-f89ee6aff401&response_mode=fragment&"
            "client_info=1&prompt=select_account&nonce=019b58d7-9ee5-7a69-abb5-44958cc4b3f7&state=eyJpZCI6IjAxOWI1OGQ3LTllZTUt"
            "N2JmNy1hMzgxLTQ5OTg0YTVjZTYwNCIsIm1ldGEiOnsiaW50ZXJhY3Rpb25UeXBlIjoicmVkaXJlY3QifX0%3D%7CaHR0cHM6Ly9vdXRsb29r"
            "LmxpdmUuY29tL21haWwvMC8_ZGVlcGxpbms9bWFpbCUyRjAlMkY&claims=%7B%22access_token%22%3A%7B%22xms_cc%22%3A%7B%22values"
            "%22%3A%5B%22CP1%22%5D%7D%7D%7D&x-client-SKU=msal.js.browser&x-client-VER=4.26.0&response_type=code&code_challenge="
            "kayrA5bxYnQ2BtwV5SQTEOr7kGEqG3GvELq0RfQXLJ0&code_challenge_method=S256&cobrandid=ab0455a0-8d03-46b9-b18b-df2f57b9e44c&fl=dob,flname,wld"
        ),
        "folder": "Fixados",
        "icon": "email",
    },
    {"id": "builtin_amazon", "name": "amazon", "url": "https://www.amazon.com.br/", "folder": "Fixados", "icon": "amazon"},
    {"id": "builtin_paramount", "name": "paramunt", "url": "https://www.paramountplus.com/br/?ftag=PPM-02-10aeh6j", "folder": "Fixados", "icon": "paramount"},
    {"id": "builtin_paramount_login", "name": "paramunt login", "url": "https://www.paramountplus.com/br/account/signin/", "folder": "Fixados", "icon": "paramount"},
    {"id": "builtin_paramount_plan", "name": "paramunt plano", "url": "https://www.paramountplus.com/br/account/signup/plan/", "folder": "Fixados", "icon": "paramount"},
    {
        "id": "builtin_prime",
        "name": "prime",
        "url": "https://www.primevideo.com/-/pt/region/na/offers/nonprimehomepage/ref=dv_web_force_root?language=pt",
        "folder": "Fixados",
        "icon": "prime",
    },
    {
        "id": "builtin_wallet",
        "name": "wallet",
        "url": "https://www.amazon.com.br/cpe/yourpayments/wallet?ref_=ya_d_c_pmt_mpo#",
        "folder": "Fixados",
        "icon": "wallet",
    },
    {"id": "builtin_emailtm", "name": "emailtm", "url": "https://mail.tm/pt/", "folder": "Fixados", "icon": "mail"},
]

LEGACY_DEFAULT_FAVORITE_IDS = {
    "anime001",
    "hbo001",
    "amazon001",
    "prime001",
    "aniprime001",
    "wallet001",
    "disney001",
    "outlook001",
}


class BrowserProfile:
    """Representa um perfil de navegação."""
    
    def __init__(
        self,
        name: str,
        fingerprint: Dict = None,
        proxy: str = None,
        auto_login: Dict = None,
        persist_data: bool = True,
        tags: List[str] = None,
        notes: str = "",
        compatibility_mode: bool = False,
        save_logins: bool = True,
        browser_mode: str = "auto",
        fingerprint_level: str = "Leve",
        address_data: Dict = None,
    ):
        """
        Inicializa um perfil de navegação.
        
        Args:
            name: Nome do perfil
            fingerprint: Configurações de fingerprint
            proxy: String do proxy (IP:Porta ou IP:Porta:User:Senha)
            auto_login: Configurações de auto-login {url: {user, password}}
            persist_data: Se True, mantém histórico, cookies e dados entre sessões
        """
        self.name = name
        self.fingerprint = fingerprint or {}
        self.proxy = proxy
        self.auto_login = auto_login or {}
        self.persist_data = persist_data  # Nova opção para persistência de dados
        self.tags = tags or []
        self.notes = notes or ""
        self.compatibility_mode = compatibility_mode
        self.save_logins = save_logins
        self.browser_mode = browser_mode or "auto"
        self.fingerprint_level = fingerprint_level or "Leve"
        self.address_data = address_data or {}
        self.created_at = datetime.now().isoformat()
        self.last_used = None
        self.id = fingerprint.get("id") if fingerprint else self._generate_id()
    
    def _generate_id(self) -> str:
        """Gera um ID único para o perfil."""
        import hashlib
        raw = f"{self.name}{datetime.now().timestamp()}"
        return hashlib.md5(raw.encode()).hexdigest()[:12]
    
    def to_dict(self) -> Dict:
        """Converte o perfil para dicionário."""
        return {
            "id": self.id,
            "name": self.name,
            "fingerprint": self.fingerprint,
            "proxy": self.proxy,
            "auto_login": self.auto_login,
            "persist_data": self.persist_data,
            "tags": self.tags,
            "notes": self.notes,
            "compatibility_mode": self.compatibility_mode,
            "save_logins": self.save_logins,
            "browser_mode": self.browser_mode,
            "fingerprint_level": self.fingerprint_level,
            "address_data": self.address_data,
            "created_at": self.created_at,
            "last_used": self.last_used,
        }
    
    @classmethod
    def from_dict(cls, data: Dict) -> "BrowserProfile":
        """Cria um perfil a partir de um dicionário."""
        profile = cls(
            name=data.get("name", "Sem Nome"),
            fingerprint=data.get("fingerprint", {}),
            proxy=data.get("proxy"),
            auto_login=data.get("auto_login", {}),
            persist_data=data.get("persist_data", True),
            tags=data.get("tags", []),
            notes=data.get("notes", ""),
            compatibility_mode=data.get("compatibility_mode", False),
            save_logins=data.get("save_logins", True),
            browser_mode=data.get("browser_mode", "auto"),
            fingerprint_level=data.get("fingerprint_level", "Leve"),
            address_data=data.get("address_data", {}),
        )
        profile.id = data.get("id", profile.id)
        profile.created_at = data.get("created_at", profile.created_at)
        profile.last_used = data.get("last_used")
        return profile


class BrowserManager:
    """
    Gerenciador de navegadores com perfis anti-fingerprint.
    Versão compatível com Python 3.13+ usando Selenium puro.
    """
    
    def __init__(self, profiles_dir: str = None):
        """
        Inicializa o gerenciador de navegadores.
        
        Args:
            profiles_dir: Diretório para armazenar perfis
        """
        self.profiles_dir = Path(profiles_dir) if profiles_dir else BASE_DIR / "browser_profiles"
        self.profiles_dir.mkdir(parents=True, exist_ok=True)
        
        self.extensions_dir = BASE_DIR / "browser_extensions"
        self.extensions_dir.mkdir(parents=True, exist_ok=True)
        
        self.global_extensions_dir = self.extensions_dir / "global"
        self.global_extensions_dir.mkdir(parents=True, exist_ok=True)
        
        self.fingerprint_generator = FingerprintGenerator()
        self.proxy_manager = ProxyManager(str(self.extensions_dir / "proxy"))
        
        # Gerenciador de configurações padrão (favoritos, extensões, senhas)
        self.config_dir = BASE_DIR / "browser_config"
        self.config_dir.mkdir(parents=True, exist_ok=True)
        self.logs_file = self.config_dir / "browser_logs.jsonl"
        
        if DEFAULTS_MANAGER_AVAILABLE:
            self.defaults_manager = ProfileDefaultsManager(str(self.config_dir), str(self.extensions_dir))
        else:
            self.defaults_manager = None
        
        # Perfis carregados
        self.profiles: Dict[str, BrowserProfile] = {}
        
        # Navegadores ativos
        self.active_browsers: Dict[str, any] = {}
        self.active_browser_modes: Dict[str, str] = {}
        self.active_debug_ports: Dict[str, int] = {}
        self.active_native_browser_names: Dict[str, str] = {}
        self.native_control_drivers: Dict[str, any] = {}
        
        # Carregar perfis existentes
        self._load_profiles()
        self._ensure_builtin_default_favorites()
    
    def _load_profiles(self):
        """Carrega perfis do disco."""
        profiles_file = self.profiles_dir / "profiles.json"
        
        if profiles_file.exists():
            try:
                with open(profiles_file, "r", encoding="utf-8") as f:
                    data = json.load(f)
                
                for profile_data in data.get("profiles", []):
                    profile = BrowserProfile.from_dict(profile_data)
                    self.profiles[profile.id] = profile
                    
            except Exception as e:
                print(f"Erro ao carregar perfis: {e}")

    def _ensure_builtin_default_favorites(self):
        """Garante que os favoritos fixados do projeto existam nos padrões."""
        if not self.defaults_manager:
            return

        favorites_manager = getattr(self.defaults_manager, "favorites", None)
        if not favorites_manager:
            return

        now = datetime.now().isoformat()
        favorites = favorites_manager.favorites
        original_count = len(favorites)
        favorites[:] = [fav for fav in favorites if fav.get("id") not in LEGACY_DEFAULT_FAVORITE_IDS]
        by_id = {fav.get("id"): fav for fav in favorites if fav.get("id")}
        by_name = {(fav.get("name") or "").strip().lower(): fav for fav in favorites if fav.get("name")}
        by_url = {fav.get("url"): fav for fav in favorites if fav.get("url")}
        changed = len(favorites) != original_count

        for builtin in BUILTIN_DEFAULT_FAVORITES:
            favorite = (
                by_id.get(builtin["id"])
                or by_name.get(builtin["name"].lower())
                or by_url.get(builtin["url"])
            )
            if favorite:
                for key in ("id", "name", "url", "folder", "icon"):
                    if favorite.get(key) != builtin.get(key):
                        favorite[key] = builtin.get(key)
                        changed = True
                if changed:
                    favorite["updated_at"] = now
            else:
                payload = copy.deepcopy(builtin)
                payload["added_at"] = now
                favorites.append(payload)
                by_id[payload["id"]] = payload
                by_name[payload["name"].lower()] = payload
                by_url[payload["url"]] = payload
                changed = True

        if changed:
            favorites_manager._save_favorites()
    
    def _save_profiles(self):
        """Salva perfis no disco."""
        profiles_file = self.profiles_dir / "profiles.json"
        
        data = {
            "version": "9.0",
            "profiles": [p.to_dict() for p in self.profiles.values()]
        }
        
        try:
            with open(profiles_file, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=2, ensure_ascii=False)
        except Exception as e:
            print(f"Erro ao salvar perfis: {e}")

    def log_event(self, event: str, profile_id: str = None, message: str = "", level: str = "info"):
        """Registra eventos simples do navegador para o painel de logs."""
        try:
            payload = {
                "time": datetime.now().isoformat(),
                "level": level,
                "event": event,
                "profile_id": profile_id,
                "message": message,
            }
            with open(self.logs_file, "a", encoding="utf-8") as f:
                f.write(json.dumps(payload, ensure_ascii=False) + "\n")
        except Exception:
            pass

    def get_recent_logs(self, limit: int = 80) -> List[Dict]:
        """Retorna os logs recentes do navegador."""
        if not self.logs_file.exists():
            return []
        try:
            lines = self.logs_file.read_text(encoding="utf-8").splitlines()[-limit:]
            logs = []
            for line in lines:
                try:
                    logs.append(json.loads(line))
                except Exception:
                    continue
            return logs
        except Exception:
            return []

    def _load_json_list(self, filename: str) -> List[Dict]:
        path = self.config_dir / filename
        if not path.exists():
            return []
        try:
            data = json.load(open(path, "r", encoding="utf-8"))
            return data if isinstance(data, list) else data.get("items", [])
        except Exception:
            return []

    def _save_json_list(self, filename: str, items: List[Dict]):
        path = self.config_dir / filename
        data = {"updated_at": datetime.now().isoformat(), "items": items}
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)

    def list_accounts(self) -> List[Dict]:
        return self._load_json_list("browser_accounts.json")

    def save_account(self, account: Dict) -> Dict:
        accounts = self.list_accounts()
        if not account.get("id"):
            account["id"] = hashlib.md5(f"{account.get('name')}{datetime.now()}".encode()).hexdigest()[:12]
            account["created_at"] = datetime.now().isoformat()
        account["updated_at"] = datetime.now().isoformat()

        replaced = False
        for i, existing in enumerate(accounts):
            if existing.get("id") == account["id"]:
                accounts[i] = account
                replaced = True
                break
        if not replaced:
            accounts.append(account)
        self._save_json_list("browser_accounts.json", accounts)
        self.log_event("account_saved", account.get("profile_id"), f"Conta salva: {account.get('name', '')}")
        return account

    def delete_account(self, account_id: str) -> bool:
        accounts = self.list_accounts()
        filtered = [acc for acc in accounts if acc.get("id") != account_id]
        if len(filtered) == len(accounts):
            return False
        self._save_json_list("browser_accounts.json", filtered)
        self.log_event("account_deleted", None, f"Conta removida: {account_id}")
        return True

    def list_tasks(self) -> List[Dict]:
        return self._load_json_list("browser_tasks.json")

    def save_task(self, task: Dict) -> Dict:
        tasks = self.list_tasks()
        if not task.get("id"):
            task["id"] = hashlib.md5(f"{task.get('title')}{datetime.now()}".encode()).hexdigest()[:12]
            task["created_at"] = datetime.now().isoformat()
            task.setdefault("done", False)
        task["updated_at"] = datetime.now().isoformat()

        replaced = False
        for i, existing in enumerate(tasks):
            if existing.get("id") == task["id"]:
                tasks[i] = task
                replaced = True
                break
        if not replaced:
            tasks.append(task)
        self._save_json_list("browser_tasks.json", tasks)
        self.log_event("task_saved", task.get("profile_id"), f"Tarefa salva: {task.get('title', '')}")
        return task

    def delete_task(self, task_id: str) -> bool:
        tasks = self.list_tasks()
        filtered = [task for task in tasks if task.get("id") != task_id]
        if len(filtered) == len(tasks):
            return False
        self._save_json_list("browser_tasks.json", filtered)
        self.log_event("task_deleted", None, f"Tarefa removida: {task_id}")
        return True

    def set_task_done(self, task_id: str, done: bool) -> bool:
        tasks = self.list_tasks()
        changed = False
        for task in tasks:
            if task.get("id") == task_id:
                task["done"] = done
                task["updated_at"] = datetime.now().isoformat()
                changed = True
                break
        if changed:
            self._save_json_list("browser_tasks.json", tasks)
            self.log_event("task_done" if done else "task_open", None, task_id)
        return changed
    
    def create_profile(
        self,
        name: str,
        fingerprint: Dict = None,
        proxy: str = None,
        country: str = "BR",
        persist_data: bool = True
    ) -> BrowserProfile:
        """
        Cria um novo perfil de navegação.
        
        Args:
            name: Nome do perfil
            fingerprint: Fingerprint customizado (opcional)
            proxy: String do proxy (opcional)
            country: País para gerar fingerprint (padrão: BR)
            persist_data: Se True, mantém histórico, cookies e dados entre sessões
            
        Returns:
            BrowserProfile criado
        """
        # Gerar fingerprint se não fornecido
        if not fingerprint:
            if country == "BR":
                fingerprint = self.fingerprint_generator.generate_brazilian_fingerprint()
            else:
                fingerprint = self.fingerprint_generator.generate_random_fingerprint(country)
        
        profile = BrowserProfile(
            name=name,
            fingerprint=fingerprint,
            proxy=proxy,
            persist_data=persist_data,
        )
        
        self.profiles[profile.id] = profile
        self._save_profiles()
        
        # Aplicar configurações padrão ao novo perfil
        self._apply_defaults_to_profile(profile.id)
        self.log_event("profile_created", profile.id, f"Perfil criado: {profile.name}")
        
        return profile
    
    def _apply_defaults_to_profile(self, profile_id: str) -> bool:
        """
        Aplica configurações padrão (favoritos, extensões) a um perfil.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            True se aplicado com sucesso
        """
        if not self.defaults_manager:
            print("[Browser] Gerenciador de configurações padrão não disponível")
            return False
        
        try:
            # Diretório de dados do perfil
            user_data_dir = self.profiles_dir / f"data_{profile_id}"
            user_data_dir.mkdir(parents=True, exist_ok=True)
            
            print(f"[Browser] Aplicando configurações padrão ao perfil {profile_id}")
            print(f"[Browser] Diretório do perfil: {user_data_dir}")
            
            # Aplicar favoritos padrão
            results = self.defaults_manager.apply_defaults_to_profile(user_data_dir)
            
            if results.get("favorites", False):
                print(f"[Browser] Favoritos aplicados com sucesso")
            else:
                print(f"[Browser] Falha ao aplicar favoritos")
            
            return results.get("favorites", False)
        except Exception as e:
            print(f"Erro ao aplicar configurações padrão: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _clear_profile_data(self, user_data_dir: Path):
        """
        Limpa dados do perfil (histórico, cookies, cache) mantendo favoritos e configurações.
        Usado quando persist_data é False.
        
        Args:
            user_data_dir: Diretório de dados do perfil
        """
        try:
            # Pastas a serem limpas (dados de navegação)
            folders_to_clear = [
                "Cache",
                "Code Cache",
                "GPUCache",
                "Service Worker",
                "Session Storage",
                "Local Storage",
                "IndexedDB",
                "File System",
                "blob_storage",
                "databases",
            ]
            
            # Arquivos a serem limpos
            files_to_clear = [
                "History",
                "History-journal",
                "Cookies",
                "Cookies-journal",
                "Web Data",
                "Web Data-journal",
                "Login Data",
                "Login Data-journal",
                "Visited Links",
            "Network Action Predictor",
            "Top Sites",
            "Top Sites-journal",
            "Current Session",
            "Current Tabs",
            "Last Session",
            "Last Tabs",
        ]
            
            default_dir = user_data_dir / "Default"
            if default_dir.exists():
                # Limpar pastas
                for folder in folders_to_clear:
                    folder_path = default_dir / folder
                    if folder_path.exists():
                        try:
                            shutil.rmtree(folder_path)
                        except Exception:
                            pass
                
                # Limpar arquivos
                for file in files_to_clear:
                    file_path = default_dir / file
                    if file_path.exists():
                        try:
                            file_path.unlink()
                        except Exception:
                            pass

                sessions_dir = default_dir / "Sessions"
                if sessions_dir.exists():
                    try:
                        shutil.rmtree(sessions_dir)
                    except Exception:
                        pass
            
            print(f"[Browser] Dados de navegação limpos para o perfil")
            
        except Exception as e:
            print(f"Erro ao limpar dados do perfil: {e}")
    
    def clear_profile_data(self, profile_id: str) -> bool:
        """
        Limpa dados de navegação de um perfil específico.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            True se limpou com sucesso
        """
        try:
            user_data_dir = self.profiles_dir / f"data_{profile_id}"
            if user_data_dir.exists():
                self._clear_profile_data(user_data_dir)
                return True
            return False
        except Exception as e:
            print(f"Erro ao limpar dados do perfil: {e}")
            return False
    
    def set_persist_data(self, profile_id: str, persist: bool) -> bool:
        """
        Define se o perfil deve manter dados entre sessões.
        
        Args:
            profile_id: ID do perfil
            persist: True para manter dados, False para limpar a cada sessão
            
        Returns:
            True se atualizado com sucesso
        """
        profile = self.profiles.get(profile_id)
        if not profile:
            return False
        
        profile.persist_data = persist
        self._save_profiles()
        return True
    
    def create_quick_profile(self, persist_data: bool = True) -> BrowserProfile:
        """
        Cria um perfil rápido com configurações aleatórias brasileiras.
        
        Returns:
            BrowserProfile criado
        """
        # Gerar nome aleatório
        import random
        adjectives = ["Ninja", "Shadow", "Ghost", "Stealth", "Phantom", "Silent", "Dark", "Swift"]
        nouns = ["Agent", "Runner", "Walker", "Hunter", "Shield", "Blade", "Storm", "Wolf"]
        name = f"{random.choice(adjectives)} {random.choice(nouns)} {random.randint(100, 999)}"
        
        return self.create_profile(name=name, country="BR", persist_data=persist_data)

    @staticmethod
    def normalize_navigation_target(target: str, default_url: str = "https://browserleaks.com/javascript") -> str:
        """Converte texto digitado em URL navegável ou busca do Google."""
        target = (target or "").strip()
        if not target:
            return default_url

        parsed = urllib.parse.urlparse(target)
        if parsed.scheme in ("http", "https", "chrome", "about", "file"):
            return target

        looks_like_domain = (
            " " not in target
            and (
                "." in target
                or target.startswith("localhost")
                or target.replace(":", "").replace("/", "").replace(".", "").isdigit()
            )
        )
        if looks_like_domain:
            if target.startswith("localhost") or target.replace(":", "").replace("/", "").replace(".", "").isdigit():
                return "http://" + target
            return "https://" + target

        return "https://www.google.com/search?q=" + urllib.parse.quote_plus(target)

    def clone_profile(self, profile_id: str, new_name: str = None, clone_data: bool = False) -> Optional[BrowserProfile]:
        """Clona configurações de um perfil para criar outro login isolado."""
        source = self.profiles.get(profile_id)
        if not source:
            return None

        profile = BrowserProfile(
            name=new_name or f"{source.name} Copy",
            fingerprint=copy.deepcopy(source.fingerprint),
            proxy=source.proxy,
            auto_login=copy.deepcopy(source.auto_login),
            persist_data=source.persist_data,
            tags=copy.deepcopy(getattr(source, "tags", [])),
            notes=getattr(source, "notes", ""),
            compatibility_mode=getattr(source, "compatibility_mode", False),
            save_logins=getattr(source, "save_logins", True),
            browser_mode=getattr(source, "browser_mode", "auto"),
            fingerprint_level=getattr(source, "fingerprint_level", "Leve"),
            address_data=copy.deepcopy(getattr(source, "address_data", {})),
        )
        profile.id = profile._generate_id()
        if isinstance(profile.fingerprint, dict):
            profile.fingerprint["id"] = profile.id

        self.profiles[profile.id] = profile
        self._save_profiles()
        self._apply_defaults_to_profile(profile.id)

        if clone_data:
            src_dir = self.profiles_dir / f"data_{profile_id}"
            dst_dir = self.profiles_dir / f"data_{profile.id}"
            if src_dir.exists() and not dst_dir.exists():
                try:
                    shutil.copytree(src_dir, dst_dir)
                except Exception as e:
                    print(f"Erro ao clonar dados do perfil: {e}")
        return profile

    def apply_defaults_to_all_profiles(self) -> Dict[str, bool]:
        """Aplica favoritos padrão aos dados de todos os perfis existentes."""
        results = {}
        for profile_id in list(self.profiles.keys()):
            results[profile_id] = self._apply_defaults_to_profile(profile_id)
        return results

    def get_default_extension_count(self) -> int:
        """Retorna quantas extensões padrão habilitadas serão carregadas no Chrome."""
        if not self.defaults_manager:
            return 0
        return len(self.defaults_manager.get_extension_paths_for_chrome())

    def get_default_favorite_count(self) -> int:
        """Retorna quantos favoritos padrão serão fixados nos perfis."""
        if not self.defaults_manager:
            return 0
        favorites = getattr(self.defaults_manager, "favorites", None)
        return len(favorites.get_favorites()) if favorites else 0

    def get_default_favorites(self) -> List[Dict]:
        """Retorna os favoritos padrão configurados."""
        if not self.defaults_manager:
            return []
        favorites = getattr(self.defaults_manager, "favorites", None)
        return favorites.get_favorites() if favorites else []

    def profile_has_default_favorites(self, profile_id: str) -> bool:
        """Confere se todos os favoritos padrão existem no perfil."""
        expected_urls = {fav.get("url") for fav in self.get_default_favorites() if fav.get("url")}
        if not expected_urls:
            return True

        bookmarks_file = self.profiles_dir / f"data_{profile_id}" / "Default" / "Bookmarks"
        if not bookmarks_file.exists():
            return False
        try:
            data = json.load(open(bookmarks_file, "r", encoding="utf-8"))
        except Exception:
            return False

        found_urls = set()
        stack = list(data.get("roots", {}).values())
        while stack:
            node = stack.pop()
            if isinstance(node, dict) and node.get("type") == "url" and node.get("url"):
                found_urls.add(node.get("url"))
            if isinstance(node, dict):
                stack.extend(node.get("children", []) or [])
        return expected_urls.issubset(found_urls)

    def get_profile_status(self, profile_id: str) -> Dict:
        """Retorna status resumido para a central de perfis."""
        profile = self.profiles.get(profile_id)
        if not profile:
            return {"label": "erro", "color": "#ef4444"}
        active = self.is_browser_active(profile_id)
        has_proxy = bool(profile.proxy)
        has_favorites = self.profile_has_default_favorites(profile_id)
        return {
            "active": active,
            "has_proxy": has_proxy,
            "has_favorites": has_favorites,
            "label": "aberto" if active else "fechado",
            "proxy_label": "com proxy" if has_proxy else "sem proxy",
            "favorites_label": "favoritos OK" if has_favorites else "sem favoritos",
            "color": "#10b981" if active else "#94a3b8",
        }

    def create_browser_backup(self) -> Optional[Path]:
        """Cria backup zip dos perfis, favoritos, extensões e configurações do navegador."""
        try:
            backup_dir = BASE_DIR / "backups" / "browser"
            backup_dir.mkdir(parents=True, exist_ok=True)
            backup_file = backup_dir / f"browser_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.zip"
            sources = [self.profiles_dir, self.config_dir, self.extensions_dir]

            with zipfile.ZipFile(backup_file, "w", zipfile.ZIP_DEFLATED) as zf:
                for source in sources:
                    if not source.exists():
                        continue
                    for path in source.rglob("*"):
                        if path.is_file():
                            zf.write(path, path.relative_to(BASE_DIR))

            self.log_event("backup_created", None, str(backup_file))
            return backup_file
        except Exception as e:
            self.log_event("backup_error", None, str(e), "error")
            return None
    
    def get_profile(self, profile_id: str) -> Optional[BrowserProfile]:
        """
        Obtém um perfil pelo ID.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            BrowserProfile ou None
        """
        return self.profiles.get(profile_id)
    
    def update_profile(
        self,
        profile_id: str,
        name: str = None,
        fingerprint: Dict = None,
        proxy: str = None,
        auto_login: Dict = None,
    ) -> Optional[BrowserProfile]:
        """
        Atualiza um perfil existente.
        
        Args:
            profile_id: ID do perfil
            name: Novo nome (opcional)
            fingerprint: Novo fingerprint (opcional)
            proxy: Novo proxy (opcional)
            auto_login: Novas configurações de auto-login (opcional)
            
        Returns:
            BrowserProfile atualizado ou None
        """
        profile = self.profiles.get(profile_id)
        if not profile:
            return None
        
        if name is not None:
            profile.name = name
        if fingerprint is not None:
            profile.fingerprint = fingerprint
        if proxy is not None:
            profile.proxy = proxy
        if auto_login is not None:
            profile.auto_login = auto_login
        
        self._save_profiles()
        return profile
    
    def delete_profile(self, profile_id: str) -> bool:
        """
        Remove um perfil.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            True se removido com sucesso
        """
        if profile_id not in self.profiles:
            return False
        
        # Fechar navegador se ativo
        if profile_id in self.active_browsers:
            self.close_browser(profile_id)
        
        # Remover dados do perfil
        user_data_dir = self.profiles_dir / f"data_{profile_id}"
        if user_data_dir.exists():
            try:
                shutil.rmtree(user_data_dir)
            except Exception as e:
                print(f"Erro ao remover dados do perfil: {e}")
        
        del self.profiles[profile_id]
        self._save_profiles()
        self.log_event("profile_deleted", profile_id, "Perfil removido")
        
        return True
    
    def list_profiles(self) -> List[BrowserProfile]:
        """
        Lista todos os perfis.
        
        Returns:
            Lista de BrowserProfile
        """
        return list(self.profiles.values())
    
    def _find_chrome_path(self) -> Optional[str]:
        """
        Encontra o caminho do Chrome instalado.
        
        Returns:
            Caminho do Chrome ou None
        """
        # Caminhos comuns do Chrome no Windows
        possible_paths = [
            r"C:\Program Files\Google\Chrome\Application\chrome.exe",
            r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
            os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe"),
        ]
        
        # Adicionar caminhos do Linux/Mac
        if sys.platform != "win32":
            possible_paths.extend([
                "/usr/bin/google-chrome",
                "/usr/bin/google-chrome-stable",
                "/usr/bin/chromium",
                "/usr/bin/chromium-browser",
                "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
            ])
        
        for path in possible_paths:
            if os.path.exists(path):
                return path
        
        return None

    def _find_native_browser(self, preferred: str = None) -> Optional[Dict[str, str]]:
        """Encontra navegador instalado para modo nativo."""
        preferred = (preferred or "auto").lower()
        candidates = [
            ("chrome", r"C:\Program Files\Google\Chrome\Application\chrome.exe"),
            ("chrome", r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe"),
            ("chrome", os.path.expanduser(r"~\AppData\Local\Google\Chrome\Application\chrome.exe")),
            ("edge", r"C:\Program Files\Microsoft\Edge\Application\msedge.exe"),
            ("edge", r"C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe"),
            ("edge", os.path.expanduser(r"~\AppData\Local\Microsoft\Edge\Application\msedge.exe")),
            ("firefox", r"C:\Program Files\Mozilla Firefox\firefox.exe"),
            ("firefox", r"C:\Program Files (x86)\Mozilla Firefox\firefox.exe"),
        ]
        if preferred and preferred != "auto":
            candidates = [item for item in candidates if item[0] == preferred] + [
                item for item in candidates if item[0] != preferred
            ]
        for name, path in candidates:
            if os.path.exists(path):
                if preferred in ("chrome", "edge", "firefox") and name != preferred:
                    continue
                return {"name": name, "path": path}
        commands = (("chrome", "chrome"), ("edge", "msedge"), ("firefox", "firefox"))
        if preferred and preferred != "auto":
            commands = tuple(item for item in commands if item[0] == preferred)
        for name, command in commands:
            found = shutil.which(command)
            if found:
                return {"name": name, "path": found}
        return None

    def _is_port_free(self, port: int) -> bool:
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as sock:
                sock.settimeout(0.15)
                return sock.connect_ex(("127.0.0.1", port)) != 0
        except OSError:
            return False

    def _pick_debug_port(self, profile_id: str) -> int:
        seed = int(hashlib.md5(profile_id.encode("utf-8")).hexdigest()[:4], 16)
        start = 9300 + (seed % 700)
        used = set(self.active_debug_ports.values())
        for offset in range(250):
            port = start + offset
            if port > 65500:
                port = 9300 + (port % 700)
            if port not in used and self._is_port_free(port):
                return port
        return start

    def _launch_native_chrome(self, profile: BrowserProfile, user_data_dir: Path, start_url: str = None, preferred_browser: str = None):
        """Abre navegador direto, sem Selenium, para sites que bloqueiam automação."""
        preferred_browser = preferred_browser or getattr(profile, "browser_mode", "auto")
        browser = self._find_native_browser(preferred_browser)
        if not browser:
            raise Exception("Nenhum navegador nativo encontrado. Instale Chrome, Edge ou Firefox.")

        screen = profile.fingerprint.get("screen", {})
        width = screen.get("width", 1366)
        height = screen.get("height", 768)
        locale = profile.fingerprint.get("locale", "pt-BR")
        target_url = self.normalize_navigation_target(start_url or "https://www.paramountplus.com/br/account/signin/")
        if "paramountplus.com" in target_url.lower():
            if "/account/user-flow" in target_url.lower() or "/f-upsell" in target_url.lower():
                target_url = "https://www.paramountplus.com/br/account/signin/"

        debug_port = None
        if browser["name"] == "firefox":
            firefox_profile_dir = user_data_dir / "FirefoxProfile"
            firefox_profile_dir.mkdir(parents=True, exist_ok=True)
            args = [
                browser["path"],
                "-profile",
                str(firefox_profile_dir),
                "-width",
                str(width),
                "-height",
                str(height),
                target_url,
            ]
        else:
            args = [
                browser["path"],
                f"--user-data-dir={user_data_dir}",
                f"--window-size={width},{height}",
                f"--lang={locale}",
                "--no-first-run",
                "--no-default-browser-check",
                "--disable-notifications",
                "--disable-session-crashed-bubble",
            ]
            debug_port = self._pick_debug_port(profile.id)
            args.append(f"--remote-debugging-port={debug_port}")
            args.append("--remote-allow-origins=*")
            if not getattr(profile, "save_logins", True):
                args.append("--disable-save-password-bubble")

        if profile.proxy and browser["name"] != "firefox":
            proxy_config = self.proxy_manager.parse_proxy_string(profile.proxy)
            if proxy_config and not proxy_config.requires_auth:
                args.append(f"--proxy-server=http://{proxy_config.host}:{proxy_config.port}")

        if browser["name"] != "firefox":
            args.append(target_url)
        process = subprocess.Popen(args, cwd=str(BASE_DIR))
        if debug_port:
            self.active_debug_ports[profile.id] = debug_port
            self.active_native_browser_names[profile.id] = browser["name"]
        self.log_event("native_browser_opened", profile.id, f"{browser['name']} nativo aberto: {target_url}")
        return process
    
    def create_browser(self, profile_id: str, start_url: str = None) -> Optional[any]:
        """
        Cria uma instância do navegador com o perfil especificado.
        Versão compatível com Python 3.13+ usando Selenium puro.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            Instância do driver ou None
        """
        if not SELENIUM_AVAILABLE:
            error_msg = "Selenium não está instalado.\n"
            error_msg += "Execute: pip install selenium\n"
            if SELENIUM_ERROR:
                error_msg += f"\nDetalhes: {SELENIUM_ERROR}"
            raise ImportError(error_msg)
        
        profile = self.profiles.get(profile_id)
        if not profile:
            raise ValueError(f"Perfil não encontrado: {profile_id}")

        # Garante favoritos/preferências no diretório exato que o Chrome vai abrir.
        self._apply_defaults_to_profile(profile_id)
        browser_mode = (getattr(profile, "browser_mode", "auto") or "auto").lower()
        fingerprint_level = (getattr(profile, "fingerprint_level", "Leve") or "Leve").lower()
        compatibility_mode = bool(getattr(profile, "compatibility_mode", False))
        if fingerprint_level == "streaming":
            compatibility_mode = True
        if start_url and any(domain in start_url.lower() for domain in ("paramountplus.com", "hbomax.com", "primevideo.com")):
            compatibility_mode = True
        
        # Atualizar último uso
        profile.last_used = datetime.now().isoformat()
        self._save_profiles()
        
        # Configurar opções do Chrome
        options = Options()
        
        # Diretório de dados do usuário (isolado por perfil)
        user_data_dir = self.profiles_dir / f"data_{profile_id}"
        user_data_dir.mkdir(parents=True, exist_ok=True)
        
        # Se persist_data for False, limpar dados anteriores (modo "incognito" persistente)
        if not profile.persist_data:
            self._clear_profile_data(user_data_dir)

        native_requested = browser_mode in ("chrome", "edge", "firefox")
        if native_requested or (compatibility_mode and start_url and "paramountplus.com" in start_url.lower()):
            if profile_id in self.active_browsers:
                self.close_browser(profile_id)
            process = self._launch_native_chrome(
                profile,
                user_data_dir,
                start_url,
                preferred_browser=browser_mode if native_requested else None,
            )
            self.active_browsers[profile_id] = process
            self.active_browser_modes[profile_id] = "native"
            self.log_event("native_mode", profile_id, f"Navegador nativo aberto ({browser_mode})")
            return process
        
        options.add_argument(f"--user-data-dir={user_data_dir}")
        
        # Configurar User-Agent
        if profile.fingerprint.get("user_agent"):
            options.add_argument(f"--user-agent={profile.fingerprint['user_agent']}")
        
        # Configurar resolução
        screen = profile.fingerprint.get("screen", {})
        width = screen.get("width", 1920)
        height = screen.get("height", 1080)
        options.add_argument(f"--window-size={width},{height}")
        
        # === CONFIGURAÇÕES ANTI-DETECÇÃO ===
        
        light_spoof = fingerprint_level in ("leve", "forte")
        strong_spoof = fingerprint_level == "forte"
        if not compatibility_mode and light_spoof:
            # Desabilitar flag de automação
            options.add_argument("--disable-blink-features=AutomationControlled")

            # Excluir switches que indicam automação
            options.add_experimental_option("excludeSwitches", ["enable-automation"])
            options.add_experimental_option("useAutomationExtension", False)

            # Desabilitar WebRTC para prevenir vazamento de IP
            options.add_argument("--disable-webrtc")
            options.add_argument("--disable-webrtc-hw-encoding")
            options.add_argument("--disable-webrtc-hw-decoding")
            options.add_argument("--disable-webrtc-multiple-routes")
            options.add_argument("--disable-webrtc-hw-vp8-encoding")
            options.add_argument("--enforce-webrtc-ip-permission-check")
            options.add_argument("--force-webrtc-ip-handling-policy=disable_non_proxied_udp")
        
        # Outras configurações
        options.add_argument("--disable-infobars")
        options.add_argument("--disable-dev-shm-usage")
        options.add_argument("--no-sandbox")
        options.add_argument("--disable-notifications")
        if not getattr(profile, "save_logins", True):
            options.add_argument("--disable-save-password-bubble")
        if not compatibility_mode and light_spoof:
            options.add_argument("--disable-popup-blocking")
        
        # Configurar idioma
        locale = profile.fingerprint.get("locale", "pt-BR")
        options.add_argument(f"--lang={locale}")
        
        # Configurar preferências
        prefs = {
            "intl.accept_languages": ",".join(profile.fingerprint.get("languages", ["pt-BR", "pt", "en"])),
            "profile.default_content_setting_values.notifications": 2,
            "credentials_enable_service": bool(getattr(profile, "save_logins", True)),
            "profile.password_manager_enabled": bool(getattr(profile, "save_logins", True)),
            "bookmark_bar.show_on_all_tabs": True,
            "browser.show_home_button": True,
        }
        if not compatibility_mode and light_spoof:
            prefs.update({
                "webrtc.ip_handling_policy": "disable_non_proxied_udp",
                "webrtc.multiple_routes_enabled": False,
                "webrtc.nonproxied_udp_enabled": False,
            })
        options.add_experimental_option("prefs", prefs)
        
        # Lista de extensões a carregar
        extensions_to_load = []
        
        # Configurar proxy
        if profile.proxy:
            proxy_config = self.proxy_manager.parse_proxy_string(profile.proxy)
            if proxy_config:
                if proxy_config.requires_auth:
                    # Criar extensão para proxy autenticado
                    ext_path = self.proxy_manager.create_proxy_extension_mv2(proxy_config)
                    if ext_path:
                        extensions_to_load.append(ext_path)
                else:
                    # Proxy sem autenticação
                    options.add_argument(f"--proxy-server=http://{proxy_config.host}:{proxy_config.port}")
        
        # Carregar extensões globais
        if not compatibility_mode and self.global_extensions_dir.exists():
            for ext_item in self.global_extensions_dir.iterdir():
                if ext_item.is_dir() or ext_item.suffix in [".crx", ".zip"]:
                    extensions_to_load.append(str(ext_item.absolute()))
        
        # Carregar extensões padrão do gerenciador de configurações
        if not compatibility_mode and self.defaults_manager:
            default_ext_paths = self.defaults_manager.get_extension_paths_for_chrome()
            extensions_to_load.extend(default_ext_paths)
        
        extension_dirs = []
        extension_files = []
        for ext_path in dict.fromkeys(extensions_to_load):
            path_obj = Path(ext_path)
            if path_obj.is_dir():
                extension_dirs.append(str(path_obj.absolute()))
            elif path_obj.suffix.lower() == ".crx":
                extension_files.append(str(path_obj.absolute()))

        # Pastas unpacked carregam via --load-extension. CRX carrega por add_extension.
        if extension_dirs:
            options.add_argument(f"--load-extension={','.join(extension_dirs)}")
        for ext_file in extension_files:
            try:
                options.add_extension(ext_file)
            except Exception as e:
                print(f"Aviso: não foi possível adicionar extensão {ext_file}: {e}")
        
        # Encontrar Chrome
        chrome_path = self._find_chrome_path()
        if chrome_path:
            options.binary_location = chrome_path
        
        # Criar driver - Tentar undetected-chromedriver primeiro (melhor anti-detecção)
        driver = None
        use_undetected = UNDETECTED_AVAILABLE
        
        if use_undetected:
            try:
                print("[Anti-Detect] Usando undetected-chromedriver...")
                
                # Configurar opções para undetected-chromedriver
                uc_options = uc.ChromeOptions()
                
                # Diretório de dados do usuário
                uc_options.add_argument(f"--user-data-dir={user_data_dir}")
                
                # User-Agent
                if profile.fingerprint.get("user_agent"):
                    uc_options.add_argument(f"--user-agent={profile.fingerprint['user_agent']}")
                
                # Resolução
                uc_options.add_argument(f"--window-size={width},{height}")
                
                # Idioma
                uc_options.add_argument(f"--lang={locale}")
                
                if not compatibility_mode and light_spoof:
                    # Desabilitar WebRTC
                    uc_options.add_argument("--disable-webrtc")
                    uc_options.add_argument("--force-webrtc-ip-handling-policy=disable_non_proxied_udp")
                
                # Outras configurações
                uc_options.add_argument("--disable-infobars")
                uc_options.add_argument("--disable-notifications")
                if not compatibility_mode and light_spoof:
                    uc_options.add_argument("--disable-popup-blocking")
                
                # Proxy (se configurado e sem autenticação)
                if profile.proxy:
                    proxy_config = self.proxy_manager.parse_proxy_string(profile.proxy)
                    if proxy_config and not proxy_config.requires_auth:
                        uc_options.add_argument(f"--proxy-server=http://{proxy_config.host}:{proxy_config.port}")

                if extension_dirs:
                    uc_options.add_argument(f"--load-extension={','.join(extension_dirs)}")
                for ext_file in extension_files:
                    try:
                        uc_options.add_extension(ext_file)
                    except Exception as e:
                        print(f"Aviso: não foi possível adicionar extensão {ext_file}: {e}")
                
                # Criar driver undetected
                driver = uc.Chrome(
                    options=uc_options,
                    use_subprocess=True,
                    version_main=None  # Auto-detectar versão do Chrome
                )
                
                print("[Anti-Detect] undetected-chromedriver iniciado com sucesso!")
                
            except Exception as e:
                print(f"[Anti-Detect] Falha no undetected-chromedriver: {e}")
                print("[Anti-Detect] Tentando Selenium padrão...")
                use_undetected = False
                driver = None
        
        # Fallback para Selenium padrão
        if not use_undetected or driver is None:
            try:
                print("[Browser] Usando Selenium padrão...")
                driver = webdriver.Chrome(options=options)
                print("[Browser] Selenium iniciado com sucesso!")
            except Exception as e:
                error_msg = str(e)
                if "chromedriver" in error_msg.lower() or "chrome" in error_msg.lower():
                    raise Exception(
                        "Erro ao iniciar o Chrome.\n\n"
                        "Verifique se:\n"
                        "1. O Google Chrome está instalado\n"
                        "2. O Chrome está atualizado\n"
                        "3. Você tem o Selenium 4.6+: pip install --upgrade selenium\n"
                        "4. Ou instale: pip install undetected-chromedriver\n\n"
                        f"Erro: {error_msg}"
                    )
                raise
        
        if not compatibility_mode and light_spoof:
            # Injetar scripts de spoofing (especialmente importante para Selenium padrão)
            self._inject_spoofing_scripts(driver, profile)

            # Injetar scripts adicionais de anti-detecção
            if strong_spoof:
                self._inject_advanced_antidetect(driver, profile)
        else:
            self.log_event("compatibility_mode", profile_id, "Modo compatibilidade ativo para streaming")
        
        # Armazenar referência
        self.active_browsers[profile_id] = driver
        self.active_browser_modes[profile_id] = "selenium"
        self.log_event("browser_opened", profile_id, f"Navegador aberto: {profile.name}")
        
        return driver
    
    def _inject_spoofing_scripts(self, driver, profile: BrowserProfile):
        """
        Injeta scripts de spoofing no navegador.
        
        Args:
            driver: Instância do driver
            profile: Perfil de navegação
        """
        fingerprint = profile.fingerprint
        
        # Obter script completo de spoofing
        spoof_script = self.fingerprint_generator.get_full_spoof_script(fingerprint)
        
        # Injetar script para ser executado em cada nova página
        try:
            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": spoof_script}
            )
        except Exception as e:
            print(f"Aviso: Não foi possível injetar scripts via CDP: {e}")
            # Fallback: executar script diretamente
            try:
                driver.execute_script(spoof_script)
            except Exception as script_err:
                print(f"Aviso: Fallback de script também falhou: {script_err}")
        
        # Remover propriedade webdriver
        try:
            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": "Object.defineProperty(navigator, 'webdriver', {get: () => undefined})"}
            )
        except Exception as webdriver_err:
            print(f"Aviso: Não foi possível remover propriedade webdriver: {webdriver_err}")
    
    def _inject_advanced_antidetect(self, driver, profile: BrowserProfile):
        """
        Injeta scripts avançados de anti-detecção.
        Inclui spoofing de AudioContext, fontes e outras APIs.
        
        Args:
            driver: Instância do driver
            profile: Perfil de navegação
        """
        fingerprint = profile.fingerprint
        
        # Script avançado de anti-detecção
        advanced_script = '''
        // ===== ANTI-DETECÇÃO AVANÇADA =====
        
        // 1. Spoofing de AudioContext (evita fingerprint por áudio)
        (function() {
            const originalAudioContext = window.AudioContext || window.webkitAudioContext;
            if (originalAudioContext) {
                const originalCreateAnalyser = originalAudioContext.prototype.createAnalyser;
                const originalCreateOscillator = originalAudioContext.prototype.createOscillator;
                const originalCreateGain = originalAudioContext.prototype.createGain;
                const originalCreateDynamicsCompressor = originalAudioContext.prototype.createDynamicsCompressor;
                
                // Adicionar ruído aleatório aos dados de áudio
                const addNoise = (data) => {
                    for (let i = 0; i < data.length; i++) {
                        data[i] = data[i] + (Math.random() * 0.0001 - 0.00005);
                    }
                    return data;
                };
                
                // Override getFloatFrequencyData
                const originalGetFloatFrequencyData = AnalyserNode.prototype.getFloatFrequencyData;
                AnalyserNode.prototype.getFloatFrequencyData = function(array) {
                    originalGetFloatFrequencyData.call(this, array);
                    addNoise(array);
                };
                
                // Override getByteFrequencyData
                const originalGetByteFrequencyData = AnalyserNode.prototype.getByteFrequencyData;
                AnalyserNode.prototype.getByteFrequencyData = function(array) {
                    originalGetByteFrequencyData.call(this, array);
                    for (let i = 0; i < array.length; i++) {
                        array[i] = Math.max(0, Math.min(255, array[i] + Math.floor(Math.random() * 2 - 1)));
                    }
                };
            }
        })();
        
        // 2. Spoofing de Fontes do Sistema
        (function() {
            // Lista de fontes comuns brasileiras/portuguesas
            const fakeFonts = [
                'Arial', 'Arial Black', 'Calibri', 'Cambria', 'Comic Sans MS',
                'Courier New', 'Georgia', 'Impact', 'Lucida Console', 'Lucida Sans Unicode',
                'Microsoft Sans Serif', 'Palatino Linotype', 'Segoe UI', 'Tahoma',
                'Times New Roman', 'Trebuchet MS', 'Verdana'
            ];
            
            // Adicionar variação aleatória
            const randomFonts = fakeFonts.slice(0, Math.floor(Math.random() * 5) + 12);
            
            // Override para document.fonts
            if (document.fonts && document.fonts.check) {
                const originalCheck = document.fonts.check.bind(document.fonts);
                document.fonts.check = function(font) {
                    const fontName = font.split(' ').pop().replace(/["']/g, '');
                    if (randomFonts.includes(fontName)) {
                        return true;
                    }
                    return originalCheck(font);
                };
            }
        })();
        
        // 3. Spoofing de Hardware Concurrency
        (function() {
            const cores = ''' + str(fingerprint.get('hardware_concurrency', 8)) + ''';
            Object.defineProperty(navigator, 'hardwareConcurrency', {
                get: () => cores
            });
        })();
        
        // 4. Spoofing de Device Memory
        (function() {
            const memory = ''' + str(fingerprint.get('device_memory', 8)) + ''';
            Object.defineProperty(navigator, 'deviceMemory', {
                get: () => memory
            });
        })();
        
        // 5. Spoofing de Connection (Network Information API)
        (function() {
            if (navigator.connection) {
                Object.defineProperty(navigator.connection, 'effectiveType', {
                    get: () => '4g'
                });
                Object.defineProperty(navigator.connection, 'downlink', {
                    get: () => Math.random() * 5 + 5  // 5-10 Mbps
                });
                Object.defineProperty(navigator.connection, 'rtt', {
                    get: () => Math.floor(Math.random() * 50) + 50  // 50-100ms
                });
            }
        })();
        
        // 6. Spoofing de Battery API
        (function() {
            if (navigator.getBattery) {
                navigator.getBattery = () => Promise.resolve({
                    charging: Math.random() > 0.5,
                    chargingTime: Infinity,
                    dischargingTime: Math.floor(Math.random() * 10000) + 5000,
                    level: Math.random() * 0.5 + 0.5,  // 50-100%
                    addEventListener: () => {},
                    removeEventListener: () => {}
                });
            }
        })();
        
        // 7. Remover rastros de automação
        (function() {
            // Remover propriedades do Selenium/ChromeDriver
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Array;
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Promise;
            delete window.cdc_adoQpoasnfa76pfcZLmcfl_Symbol;
            
            // Remover $cdc_ variables
            for (let prop in window) {
                if (prop.match(/[$]cdc_/)) {
                    delete window[prop];
                }
            }
            
            // Remover __webdriver_evaluate
            delete window.__webdriver_evaluate;
            delete window.__selenium_evaluate;
            delete window.__webdriver_script_function;
            delete window.__webdriver_script_func;
            delete window.__webdriver_script_fn;
            delete window.__fxdriver_evaluate;
            delete window.__driver_unwrapped;
            delete window.__webdriver_unwrapped;
            delete window.__driver_evaluate;
            delete window.__selenium_unwrapped;
            delete window.__fxdriver_unwrapped;
            
            // Remover document.$cdc_
            if (document) {
                for (let prop in document) {
                    if (prop.match(/[$]cdc_/)) {
                        delete document[prop];
                    }
                }
            }
        })();
        
        // 8. Spoofing de Permissions API
        (function() {
            const originalQuery = navigator.permissions.query;
            navigator.permissions.query = (parameters) => {
                if (parameters.name === 'notifications') {
                    return Promise.resolve({ state: 'prompt', onchange: null });
                }
                return originalQuery(parameters);
            };
        })();
        
        // 9. Spoofing de WebGL Vendor/Renderer (mais robusto)
        (function() {
            const getParameterOriginal = WebGLRenderingContext.prototype.getParameter;
            WebGLRenderingContext.prototype.getParameter = function(parameter) {
                if (parameter === 37445) {  // UNMASKED_VENDOR_WEBGL
                    return 'Google Inc. (Intel)';
                }
                if (parameter === 37446) {  // UNMASKED_RENDERER_WEBGL
                    return 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)';
                }
                return getParameterOriginal.call(this, parameter);
            };
            
            // Mesmo para WebGL2
            if (typeof WebGL2RenderingContext !== 'undefined') {
                const getParameter2Original = WebGL2RenderingContext.prototype.getParameter;
                WebGL2RenderingContext.prototype.getParameter = function(parameter) {
                    if (parameter === 37445) {
                        return 'Google Inc. (Intel)';
                    }
                    if (parameter === 37446) {
                        return 'ANGLE (Intel, Intel(R) UHD Graphics 620 Direct3D11 vs_5_0 ps_5_0, D3D11)';
                    }
                    return getParameter2Original.call(this, parameter);
                };
            }
        })();
        
        console.log('[Anti-Detect] Scripts avançados injetados com sucesso!');
        ''';
        
        try:
            driver.execute_cdp_cmd(
                "Page.addScriptToEvaluateOnNewDocument",
                {"source": advanced_script}
            )
        except Exception as e:
            print(f"Aviso: Não foi possível injetar scripts avançados via CDP: {e}")
            try:
                driver.execute_script(advanced_script)
            except Exception as adv_err:
                print(f"Aviso: Fallback de script avançado também falhou: {adv_err}")
    
    def navigate_to(self, profile_id: str, url: str) -> bool:
        """
        Navega para uma URL com o navegador do perfil.
        
        Args:
            profile_id: ID do perfil
            url: URL para navegar
            
        Returns:
            True se navegou com sucesso
        """
        driver = self.active_browsers.get(profile_id)
        if not driver:
            return False
        
        try:
            url = self.normalize_navigation_target(url)
            driver.get(url)
            
            # Verificar auto-login
            profile = self.profiles.get(profile_id)
            if profile and profile.auto_login:
                self._try_auto_login(driver, url, profile.auto_login)
            
            return True
            
        except Exception as e:
            print(f"Erro ao navegar: {e}")
            return False
    
    def _try_auto_login(self, driver, current_url: str, auto_login: Dict):
        """
        Tenta fazer auto-login se a URL corresponder.
        
        Args:
            driver: Instância do driver
            current_url: URL atual
            auto_login: Configurações de auto-login
        """
        for url_pattern, credentials in auto_login.items():
            if url_pattern in current_url:
                try:
                    # Aguardar página carregar
                    time.sleep(2)
                    
                    # Tentar encontrar campos de login comuns
                    username_selectors = [
                        "input[type='email']",
                        "input[type='text'][name*='user']",
                        "input[type='text'][name*='login']",
                        "input[type='text'][name*='email']",
                        "input[id*='user']",
                        "input[id*='login']",
                        "input[id*='email']",
                        "#username",
                        "#email",
                        "#login",
                    ]
                    
                    password_selectors = [
                        "input[type='password']",
                        "input[name*='pass']",
                        "input[id*='pass']",
                        "#password",
                    ]
                    
                    # Tentar preencher username
                    username_filled = False
                    for selector in username_selectors:
                        try:
                            elem = driver.find_element(By.CSS_SELECTOR, selector)
                            if elem.is_displayed():
                                elem.clear()
                                elem.send_keys(credentials.get("username", ""))
                                username_filled = True
                                break
                        except (NoSuchElementException, ElementNotInteractableException, StaleElementReferenceException):
                            continue
                    
                    # Tentar preencher password
                    password_filled = False
                    for selector in password_selectors:
                        try:
                            elem = driver.find_element(By.CSS_SELECTOR, selector)
                            if elem.is_displayed():
                                elem.clear()
                                elem.send_keys(credentials.get("password", ""))
                                password_filled = True
                                break
                        except (NoSuchElementException, ElementNotInteractableException, StaleElementReferenceException):
                            continue
                    
                    if username_filled and password_filled:
                        print(f"Auto-login preenchido para: {url_pattern}")
                        
                except Exception as e:
                    print(f"Erro no auto-login: {e}")

    def _attach_native_control_driver(self, profile_id: str):
        """Conecta o Selenium ao Chrome/Edge nativo aberto pelo app via porta local."""
        existing = self.native_control_drivers.get(profile_id)
        if existing:
            try:
                _ = existing.current_url
                return existing
            except Exception:
                self.native_control_drivers.pop(profile_id, None)

        port = self.active_debug_ports.get(profile_id)
        browser_name = self.active_native_browser_names.get(profile_id, "chrome")
        if not port or browser_name not in ("chrome", "edge"):
            return None

        last_error = None
        for _ in range(8):
            try:
                if browser_name == "edge":
                    options = webdriver.EdgeOptions()
                    options.add_experimental_option("debuggerAddress", f"127.0.0.1:{port}")
                    driver = webdriver.Edge(options=options)
                else:
                    options = Options()
                    options.add_experimental_option("debuggerAddress", f"127.0.0.1:{port}")
                    driver = webdriver.Chrome(options=options)
                self.native_control_drivers[profile_id] = driver
                return driver
            except Exception as e:
                last_error = e
                time.sleep(0.35)

        self.log_event("native_control_error", profile_id, str(last_error), "error")
        return None

    def fill_address_fields(self, profile_id: str, address_data: Dict) -> Dict:
        """
        Preenche campos de endereço na página aberta do perfil.

        Funciona em Selenium e também em Chrome/Edge nativo quando o navegador
        foi aberto pelo app com porta local de controle.
        """
        if not address_data:
            return {"ok": False, "filled": 0, "message": "Nenhum endereço salvo no perfil."}

        active_ref = self.active_browsers.get(profile_id)
        if not active_ref or not self.is_browser_active(profile_id):
            return {"ok": False, "filled": 0, "message": "Abra o navegador deste perfil antes de preencher."}

        if self.is_native_browser(profile_id):
            driver = self._attach_native_control_driver(profile_id)
            if not driver:
                return {
                    "ok": False,
                    "filled": 0,
                    "message": "Feche este navegador e abra de novo pelo app. A versão nova precisa abrir o Chrome com controle local para preencher a Paramount.",
                }
        else:
            driver = active_ref

        if not hasattr(driver, "execute_script"):
            return {"ok": False, "filled": 0, "message": "Este navegador não permite preenchimento automático."}

        normalized = {
            "cep": str(address_data.get("cep", "")).strip(),
            "cep_sem_ponto": str(address_data.get("cep", "")).replace("-", "").replace(".", "").strip(),
            "logradouro": str(address_data.get("logradouro", "")).strip(),
            "rua": str(address_data.get("rua") or address_data.get("logradouro", "")).strip(),
            "numero": str(address_data.get("numero", "")).strip(),
            "bairro": str(address_data.get("bairro", "")).strip(),
            "cidade": str(address_data.get("cidade", "")).strip(),
            "estado": str(address_data.get("estado", "")).strip(),
            "uf": str(address_data.get("uf", "")).strip().upper(),
            "complemento": str(address_data.get("complemento", "")).strip(),
        }
        normalized["endereco_completo"] = ", ".join(
            part for part in [
                normalized["logradouro"],
                normalized["numero"],
                normalized["bairro"],
                normalized["cidade"],
                normalized["uf"],
                normalized["cep"],
            ] if part
        )

        script = r"""
const address = arguments[0] || {};

function clean(s) {
  return (s || "")
    .toString()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase();
}

function fieldText(el) {
  const bits = [
    el.name, el.id, el.placeholder, el.getAttribute("aria-label"),
    el.getAttribute("autocomplete"), el.getAttribute("data-testid"),
    el.getAttribute("data-test"), el.getAttribute("title")
  ];
  if (el.labels) {
    Array.from(el.labels).forEach(label => bits.push(label.innerText));
  }
  const parent = el.closest("label, div, p, section");
  if (parent) bits.push(parent.innerText ? parent.innerText.slice(0, 160) : "");
  return clean(bits.filter(Boolean).join(" "));
}

function pickValue(el, text) {
  const type = clean(el.type || "");
  if (type === "password" || type === "email" || type === "tel" && !/cep|postal/.test(text)) return null;
  if (/cep|postal|zip|codigo postal/.test(text)) return address.cep || address.cep_sem_ponto;
  if (/logradouro|endereco|address line 1|address1|rua|street|avenida|av\.|road/.test(text)) return address.logradouro || address.rua;
  if (/numero|n[uú]mero|number|address number|num /.test(text)) return address.numero;
  if (/bairro|neighborhood|district|suburb/.test(text)) return address.bairro;
  if (/cidade|city|locality|municipio|munic[ií]pio/.test(text)) return address.cidade;
  if (/estado|state|province|provincia|prov[ií]ncia/.test(text)) return address.estado || address.uf;
  if (/(^|\s)uf($|\s)|unidade federativa|region/.test(text)) return address.uf || address.estado;
  if (/complemento|complement|address line 2|address2|apartamento|apto|suite/.test(text)) return address.complemento;
  if (/endereco completo|full address/.test(text)) return address.endereco_completo;
  return null;
}

function setNativeValue(el, value) {
  if (value === null || value === undefined || value === "") return false;
  const setter = Object.getOwnPropertyDescriptor(el.__proto__, "value")?.set;
  if (setter) setter.call(el, value);
  else el.value = value;
  el.dispatchEvent(new Event("input", { bubbles: true }));
  el.dispatchEvent(new Event("change", { bubbles: true }));
  el.dispatchEvent(new Event("blur", { bubbles: true }));
  return true;
}

function fillSelect(el, text) {
  let target = null;
  if (/estado|state|province|provincia|uf|region/.test(text)) {
    target = address.uf || address.estado;
  }
  if (!target) return false;
  const wanted = clean(target);
  const wantedState = clean(address.estado);
  const wantedUf = clean(address.uf);
  for (const opt of Array.from(el.options || [])) {
    const value = clean(opt.value);
    const label = clean(opt.textContent);
    if (value === wanted || label === wanted || value === wantedUf || label === wantedUf || value === wantedState || label === wantedState) {
      el.value = opt.value;
      el.dispatchEvent(new Event("input", { bubbles: true }));
      el.dispatchEvent(new Event("change", { bubbles: true }));
      return true;
    }
  }
  return false;
}

let filled = 0;
let names = [];
const fields = Array.from(document.querySelectorAll("input, textarea, select"));
for (const el of fields) {
  if (el.disabled || el.readOnly) continue;
  const style = window.getComputedStyle(el);
  if (style.display === "none" || style.visibility === "hidden") continue;
  const text = fieldText(el);
  let ok = false;
  if (el.tagName.toLowerCase() === "select") {
    ok = fillSelect(el, text);
  } else {
    const value = pickValue(el, text);
    ok = setNativeValue(el, value);
  }
  if (ok) {
    filled += 1;
    names.push((el.name || el.id || el.placeholder || el.tagName).toString().slice(0, 50));
  }
}
return { filled, fields: names };
"""
        try:
            result = driver.execute_script(script, normalized) or {}
            filled = int(result.get("filled", 0) or 0)
            self.log_event("address_autofill", profile_id, f"Endereço preenchido em {filled} campo(s)")
            return {
                "ok": filled > 0,
                "filled": filled,
                "fields": result.get("fields", []),
                "message": f"Preenchi {filled} campo(s) de endereço." if filled else "Não encontrei campos de endereço visíveis nesta página.",
            }
        except Exception as e:
            self.log_event("address_autofill_error", profile_id, str(e), "error")
            return {"ok": False, "filled": 0, "message": f"Erro ao preencher endereço: {e}"}
    
    def close_browser(self, profile_id: str) -> bool:
        """
        Fecha o navegador de um perfil.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            True se fechou com sucesso
        """
        driver = self.active_browsers.get(profile_id)
        if not driver:
            return False
        
        control_driver = self.native_control_drivers.pop(profile_id, None)
        if control_driver:
            try:
                control_driver.quit()
            except Exception:
                pass

        try:
            if self.active_browser_modes.get(profile_id) == "native":
                driver.terminate()
            else:
                driver.quit()
        except Exception as quit_err:
            print(f"Aviso: Erro ao fechar navegador: {quit_err}")
        
        self.active_browsers.pop(profile_id, None)
        self.active_browser_modes.pop(profile_id, None)
        self.active_debug_ports.pop(profile_id, None)
        self.active_native_browser_names.pop(profile_id, None)
        self.log_event("browser_closed", profile_id, "Navegador fechado")
        return True
    
    def is_browser_active(self, profile_id: str) -> bool:
        """
        Verifica se o navegador de um perfil está ativo.
        
        Args:
            profile_id: ID do perfil
            
        Returns:
            True se ativo
        """
        if profile_id not in self.active_browsers:
            return False
        
        driver = self.active_browsers[profile_id]
        try:
            if self.active_browser_modes.get(profile_id) == "native":
                if hasattr(driver, "poll"):
                    alive = driver.poll() is None
                    if not alive:
                        self.active_browsers.pop(profile_id, None)
                        self.active_browser_modes.pop(profile_id, None)
                        self.active_debug_ports.pop(profile_id, None)
                        self.active_native_browser_names.pop(profile_id, None)
                        self.native_control_drivers.pop(profile_id, None)
                    return alive
                self.active_browser_modes.pop(profile_id, None)
            return bool(driver.window_handles)
        except (WebDriverException, InvalidSessionIdException, AttributeError) as e:
            # Se falhar, remover da lista
            print(f"Aviso: Navegador não responde, removendo da lista: {e}")
            self.active_browsers.pop(profile_id, None)
            self.active_browser_modes.pop(profile_id, None)
            self.active_debug_ports.pop(profile_id, None)
            self.active_native_browser_names.pop(profile_id, None)
            self.native_control_drivers.pop(profile_id, None)
            return False

    def is_native_browser(self, profile_id: str) -> bool:
        return self.active_browser_modes.get(profile_id) == "native"
    
    def get_active_browsers(self) -> List[str]:
        """
        Lista IDs dos perfis com navegadores ativos.
        
        Returns:
            Lista de IDs
        """
        # Verificar quais ainda estão ativos
        active = []
        for profile_id in list(self.active_browsers.keys()):
            if self.is_browser_active(profile_id):
                active.append(profile_id)
        return active
    
    def cleanup(self):
        """Fecha todos os navegadores ativos."""
        for profile_id in list(self.active_browsers.keys()):
            self.close_browser(profile_id)
    
    def add_auto_login(
        self,
        profile_id: str,
        url: str,
        username: str,
        password: str
    ) -> bool:
        """
        Adiciona configuração de auto-login a um perfil.
        
        Args:
            profile_id: ID do perfil
            url: URL do site
            username: Nome de usuário
            password: Senha
            
        Returns:
            True se adicionado com sucesso
        """
        profile = self.profiles.get(profile_id)
        if not profile:
            return False
        
        profile.auto_login[url] = {
            "username": username,
            "password": password
        }
        
        self._save_profiles()
        return True
    
    def remove_auto_login(self, profile_id: str, url: str) -> bool:
        """
        Remove configuração de auto-login de um perfil.
        
        Args:
            profile_id: ID do perfil
            url: URL do site
            
        Returns:
            True se removido com sucesso
        """
        profile = self.profiles.get(profile_id)
        if not profile or url not in profile.auto_login:
            return False
        
        del profile.auto_login[url]
        self._save_profiles()
        return True


# Teste do módulo
if __name__ == "__main__":
    print("=== Teste do Browser Manager ===\n")
    
    if not SELENIUM_AVAILABLE:
        print("AVISO: Selenium não está instalado.")
        print("Execute: pip install selenium webdriver-manager")
        print("\nTestando apenas funcionalidades de perfil...\n")
    
    manager = BrowserManager()
    
    # Criar perfil rápido
    print("Criando perfil rápido...")
    profile = manager.create_quick_profile()
    print(f"Perfil criado: {profile.name}")
    print(f"ID: {profile.id}")
    print(f"User-Agent: {profile.fingerprint.get('user_agent', 'N/A')[:50]}...")
    screen = profile.fingerprint.get("screen", {})
    print(f"Resolução: {screen.get('width', 'N/A')}x{screen.get('height', 'N/A')}")
    print("=" * 50)
    
    # Criar perfil customizado
    print("\nCriando perfil customizado...")
    profile2 = manager.create_profile(
        name="Meu Perfil Seguro",
        proxy="192.168.1.1:8080:user:pass"
    )
    print(f"Perfil criado: {profile2.name}")
    print(f"Proxy: {profile2.proxy}")
    print("=" * 50)
    
    # Listar perfis
    print("\nPerfis salvos:")
    for p in manager.list_profiles():
        print(f"  - {p.name} (ID: {p.id})")
    
    print("=" * 50)
    
    # Testar auto-login
    print("\nAdicionando auto-login...")
    manager.add_auto_login(
        profile2.id,
        "https://example.com/login",
        "usuario",
        "senha123"
    )
    print("Auto-login adicionado!")
    print(f"Auto-logins salvos: {list(profile2.auto_login.keys())}")
    
    print("\nTeste concluído!")

