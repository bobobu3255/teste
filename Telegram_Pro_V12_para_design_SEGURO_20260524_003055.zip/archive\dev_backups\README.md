# Backups De Desenvolvimento

Esta pasta guarda snapshots antigos criados durante ajustes manuais.

Eles nao sao carregados pelo app em tempo normal. A ideia e deixar a raiz do projeto mais limpa sem apagar historico util para emergencia.
